package com.autotyper.pro;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Random;

public class AutoTypeService extends AccessibilityService {

    public static AutoTypeService instance;

    private volatile boolean isRunning = false;
    private Thread workerThread = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private int screenWidth = 1080;
    private int screenHeight = 2400;
    private Vibrator vibrator;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        vibrator = (Vibrator) getSystemService("vibrator");
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            screenWidth = dm.widthPixels;
            screenHeight = dm.heightPixels;
        } catch (Exception ignored) {
        }
        updateStatusUI("Trợ năng: Sẵn sàng", false);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
        stopTyping();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (!AppConfig.useVolumeKeyTrigger) {
            return super.onKeyEvent(event);
        }
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        if (action == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                vibrateFeedback(40);
                if (isTypingRunning()) {
                    stopTyping();
                } else {
                    startTyping();
                }
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                vibrateFeedback(25);
                DataManager.nextLine();
                updateStatusUI("Chuyển câu tiếp theo", isRunning);
                return true;
            }
        }
        return super.onKeyEvent(event);
    }

    public boolean isTypingRunning() {
        return isRunning;
    }

    public synchronized void startTyping() {
        if (isRunning) {
            return;
        }
        if (DataManager.getLineCount() == 0) {
            updateStatusUI("Danh sách ngôn đang trống!", false);
            return;
        }
        isRunning = true;
        updateStatusUI("Đang gõ ngôn...", true);
        workerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                runTypingLoop();
            }
        });
        workerThread.start();
    }

    public synchronized void stopTyping() {
        isRunning = false;
        if (workerThread != null) {
            workerThread.interrupt();
            workerThread = null;
        }
        updateStatusUI("Đã tạm dừng", false);
    }

    private void runTypingLoop() {
        while (isRunning) {
            int total = DataManager.getLineCount();
            if (total == 0) {
                break;
            }
            int currentIdx = DataManager.getCurrentIndex();
            String line = DataManager.getCurrentLine();
            if (line == null || line.isEmpty()) {
                DataManager.nextLine();
                continue;
            }
            AccessibilityNodeInfo inputNode = findActiveInputNode();
            if (inputNode == null) {
                updateStatusUI("Chạm vào ô chat để bắt đầu...", true);
                sleepQuietly(400);
                continue;
            }
            updateStatusUI("Gõ [" + (currentIdx + 1) + "/" + total + "]: " + line, true);
            try {
                inputNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                inputNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            } catch (Exception ignored) {
            }
            sleepQuietly(100);
            if (!simulateCleanHumanTyping(inputNode, line)) {
                break;
            }
            if (!isRunning) {
                break;
            }
            // KenZi Typer v3: nhập văn bản vào ô đang focus, không tự nhấn Gửi.
            // Người dùng tự quyết định khi nào gửi nội dung.
            DataManager.nextLine();
            if (isRunning) {
                updateStatusUI("Delay (" + (AppConfig.sendDelayMs / 1000.0d) + "s)...", true);
                sleepQuietly(AppConfig.sendDelayMs);
            }
            if (!AppConfig.infiniteLoop && DataManager.getCurrentIndex() == 0) {
                updateStatusUI("Đã gõ xong toàn bộ!", false);
                isRunning = false;
                break;
            }
        }
        isRunning = false;
        updateStatusUI("Sẵn sàng", false);
    }

    private boolean simulateCleanHumanTyping(AccessibilityNodeInfo node, String text) {
        StringBuilder sb = new StringBuilder();
        int len = text.length();
        for (int i = 0; i < len; i++) {
            if (!isRunning) {
                return false;
            }
            final char c = text.charAt(i);
            sb.append(c);
            if (AppConfig.showKeyPopupAnimation) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        AppConfig.notifyKeyPopup(c);
                    }
                });
            }
            boolean committedByKeyboard = false;
            try {
                // Prefer the selected KenZi Android IME: commit actual text into the focused editor.
                // If the IME is not active, retain the previous Accessibility fallback.
                committedByKeyboard = KenZiKeyboardService.commitCharacter(c);
                if (!committedByKeyboard) {
                    Bundle setArgs = new Bundle();
                    setArgs.putCharSequence(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                            sb.toString());
                    if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)) {
                        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs);
                    }
                    Bundle selArgs = new Bundle();
                    selArgs.putInt(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT,
                            sb.length());
                    selArgs.putInt(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT,
                            sb.length());
                    node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs);
                }
            } catch (Exception ignored) {
            }

            int delay = AppConfig.charSpeedMs;
            if (c == ' ') {
                delay = (int) (delay * 1.8f);
            } else if (c == '=' || c == ')') {
                delay = (int) (delay * 1.3f);
            } else if (c == '!' || c == '?' || c == '.' || c == ',') {
                delay = (int) (delay * 1.5f);
            }
            if (AppConfig.humanJitter) {
                delay = Math.max(25, delay + (random.nextInt(31) - 15));
            }
            sleepQuietly(delay);
        }
        return true;
    }

    public Point getKeyCoordinate(char c) {
        char lower = Character.toLowerCase(c);
        int kbHeight = (int) (screenHeight * 0.36d);
        int kbTop = screenHeight - kbHeight;

        int digitIdx = "1234567890".indexOf(c);
        if (digitIdx >= 0) {
            int x = (int) ((screenWidth / 10) * (digitIdx + 0.5f));
            int y = kbTop + (int) (kbHeight * 0.08f);
            return new Point(x, y);
        }

        int row1Idx = "qwertyuiop".indexOf(lower);
        if (row1Idx >= 0) {
            int x = (int) ((screenWidth / 10) * (row1Idx + 0.5f));
            int y = kbTop + (int) (kbHeight * 0.22f);
            return new Point(x, y);
        }

        int row2Idx = "asdfghjkl".indexOf(lower);
        if (row2Idx >= 0) {
            int x = (int) ((screenWidth / 9) * (row2Idx + 0.5f));
            int y = kbTop + (int) (kbHeight * 0.46f);
            return new Point(x, y);
        }

        int row3Idx = "zxcvbnm".indexOf(lower);
        if (row3Idx >= 0) {
            int startX = (int) (screenWidth * 0.12f);
            int keyWidth = ((int) (screenWidth * 0.76f)) / 7;
            int x = startX + (int) ((row3Idx + 0.5f) * keyWidth);
            int y = kbTop + (int) (kbHeight * 0.7f);
            return new Point(x, y);
        }

        if (c == ')') {
            return new Point((int) (screenWidth * 0.94f), kbTop + (int) (kbHeight * 0.12f));
        }
        if (c == '(') {
            return new Point((int) (screenWidth * 0.84f), kbTop + (int) (kbHeight * 0.12f));
        }
        if (c == '=') {
            return new Point((int) (screenWidth * 0.88f), kbTop + (int) (kbHeight * 0.46f));
        }
        if (c == '^') {
            return new Point((int) (screenWidth * 0.55f), kbTop + (int) (kbHeight * 0.12f));
        }
        if (c == '!' || c == '?') {
            return new Point((int) (screenWidth * 0.15f), kbTop + (int) (kbHeight * 0.7f));
        }
        if (c == '.' || c == ',') {
            return new Point((int) (screenWidth * 0.75f), kbTop + (int) (kbHeight * 0.9f));
        }
        if (c == ' ') {
            return new Point(screenWidth / 2, kbTop + (int) (kbHeight * 0.9f));
        }
        return new Point(screenWidth / 2, kbTop + (int) (kbHeight * 0.5f));
    }

    private AccessibilityNodeInfo findActiveInputNode() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) {
                return null;
            }
            AccessibilityNodeInfo inputFocus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (inputFocus != null && isEditableNode(inputFocus)) {
                return inputFocus;
            }
            AccessibilityNodeInfo a11yFocus = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
            if (a11yFocus != null && isEditableNode(a11yFocus)) {
                return a11yFocus;
            }
            return scanForEditableNode(root);
        } catch (Exception e) {
            return null;
        }
    }

    private AccessibilityNodeInfo scanForEditableNode(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        try {
            if (isEditableNode(node)) {
                return node;
            }
            int childCount = node.getChildCount();
            for (int i = 0; i < childCount; i++) {
                AccessibilityNodeInfo found = scanForEditableNode(node.getChild(i));
                if (found != null) {
                    return found;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean isEditableNode(AccessibilityNodeInfo node) {
        if (node == null) {
            return false;
        }
        try {
            if (node.isEditable()) {
                return true;
            }
            CharSequence cls = node.getClassName();
            if (cls != null) {
                String lower = cls.toString().toLowerCase();
                return lower.contains("edittext")
                        || lower.contains("textinput")
                        || lower.contains("textedit")
                        || lower.contains("searchautocomplete")
                        || lower.contains("rcttextinput");
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean clickSendButton() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) {
                return false;
            }
            String[] labels = new String[] {
                "Gửi", "Send", "gửi", "send", "Đăng", "Post", "Chat", "Gửi tin nhắn", "Send message"
            };
            for (String label : labels) {
                List<AccessibilityNodeInfo> matches = root.findAccessibilityNodeInfosByText(label);
                if (matches != null && !matches.isEmpty()) {
                    for (AccessibilityNodeInfo match : matches) {
                        if (clickNodeOrParent(match)) {
                            return true;
                        }
                    }
                }
            }
            return scanAndClickByDescription(root);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean clickSendButtonFallback() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) {
                return false;
            }
            return scanAndClickByDescription(root);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean scanAndClickByDescription(AccessibilityNodeInfo node) {
        if (node == null) {
            return false;
        }
        try {
            CharSequence desc = node.getContentDescription();
            if (desc != null) {
                String lowerDesc = desc.toString().toLowerCase();
                if (lowerDesc.contains("send")
                        || lowerDesc.contains("gửi")
                        || lowerDesc.contains("submit")
                        || lowerDesc.contains("post")) {
                    if (clickNodeOrParent(node)) {
                        return true;
                    }
                }
            }
            String viewId = node.getViewIdResourceName();
            if (viewId != null) {
                String lowerId = viewId.toString().toLowerCase();
                if (lowerId.contains("send_button")
                        || lowerId.contains("btn_send")
                        || lowerId.contains("composer_send")
                        || lowerId.contains("button_send")
                        || lowerId.contains("send_icon")) {
                    if (clickNodeOrParent(node)) {
                        return true;
                    }
                }
            }
            int childCount = node.getChildCount();
            for (int i = 0; i < childCount; i++) {
                if (scanAndClickByDescription(node.getChild(i))) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo curr = node;
        while (curr != null) {
            try {
                if (curr.isClickable()) {
                    return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                }
                curr = curr.getParent();
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }

    private void updateStatusUI(final String status, final boolean running) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                AppConfig.notifyStatus(
                        status,
                        DataManager.getCurrentIndex(),
                        DataManager.getLineCount(),
                        running);
            }
        });
    }

    private void vibrateFeedback(long ms) {
        try {
            if (vibrator != null) {
                vibrator.vibrate(ms);
            }
        } catch (Exception ignored) {
        }
    }

    private void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
