# Danh sách tweak của KenZi Booster

Tổng cộng **106 tweak** trong **9 danh mục**.

Ký hiệu mức độ:
- `AN TOÀN` — chỉ đổi tham số hiển thị/hiệu năng nhẹ, hoàn tác được ngay.
- `CẦN CẨN THẬN` — thay đổi hệ thống, có thể ảnh hưởng pin hoặc một số app.
- `NGUY HIỂM` — sẽ hiện hộp thoại cảnh báo bắt buộc trước khi bật (gỡ OTA, tắt thermal, đổi governor, reboot...).

Quyền cần thiết: `ROOT` chỉ chạy được với root; `SHIZUKU` chạy được với cả root lẫn Shizuku; `ROOT / Shizuku` là cả hai.

---

## Hiệu năng (21)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Animation mượt 0.5x** | Giảm tốc độ animation toàn hệ thống xuống 0.5 để phản hồi nhanh hơn. | An toàn | ROOT / Shizuku | `perf.anim_05` |
| 2 | **Animation chuẩn 1.0x** | Đưa toàn bộ animation về tốc độ mặc định của hệ thống. | An toàn | ROOT / Shizuku | `perf.anim_10` |
| 3 | **Tắt hoàn toàn animation** | Cực nhanh nhưng giao diện mất chuyển động, có thể gây vẻ giật khi mở app. | Cần cẩn thận | ROOT / Shizuku | `perf.anim_off` |
| 4 | **Slow motion 2.0x** | Hiệu ứng chuyển động chậm, hợp quay video màn hình. | An toàn | ROOT / Shizuku | `perf.anim_slow` |
| 5 | **Ép vẽ bằng GPU** | Đổi renderer HWUI sang OpenGL/Skia để giảm tải CPU khi vẽ giao diện. | Cần cẩn thận | ROOT | `perf.hwui_gpu` |
| 6 | **Tăng ngân sách CPU cho giao diện** | Cho phép tầng giao diện dùng nhiều CPU hơn, mượt hơn nhưng tốn pin. | Cần cẩn thận | ROOT | `perf.hwui_cpu` |
| 7 | **Tăng bộ nhớ heap cho app** _(Cần khởi động lại để có hiệu lực.)_ | Cho phép app dùng heap lớn hơn, giảm khả năng bị OOM khi mở nhiều tab. | Cần cẩn thận | ROOT | `perf.heap_size` |
| 8 | **Heap khởi tạo lớn hơn** | Giảm số lần cấp phát bộ nhớ, hỗ trợ app nặng. | An toàn | ROOT | `perf.heap_start` |
| 9 | **Tối ưu swap** | Giảm xu hướng swap trang bộ nhớ để ứng dụng chạy nhanh hơn. | Cần cẩn thận | ROOT | `perf.swappiness` |
| 10 | **Bật nén bộ nhớ chủ động** | Cho phép hệ thống nén bộ nhớ để giảm RAM thực. | Cần cẩn thận | ROOT | `perf.compact` |
| 11 | **Giải phóng cache RAM** | Đẩy dữ liệu cache ra đĩa, RAM trống ngay. Sẽ chậm trong vài giây. | Cần cẩn thận | ROOT | `perf.drop_caches` |
| 12 | **Tối ưu thuật toán zram** | Đổi thuật toán nén zram sang zstd, giảm I/O và nhiệt. | Cần cẩn thận | ROOT | `perf.zram` |
| 13 | **Biên dịch app nền** | Chạy dex2oat cho toàn bộ app để mở app nhanh hơn, tốn pin lúc chạy. | Cần cẩn thận | ROOT | `perf.dex2oat` |
| 14 | **Bỏ kiểm tra dex** | Tắt bước xác minh dex giúp cài app nhanh hơn, giảm rủi ro bảo mật. | Nguy hiểm | ROOT | `perf.dex_filter` |
| 15 | **Nới lmk_adj** | Giảm khả năng hệ thống tự giết app nền, giữ nhiều app hơn trong RAM. | Cần cẩn thận | ROOT | `perf.lmk_adj` |
| 16 | **CPU governor: Performance** | Ép CPU chạy ở xung nhịp cao nhất. Mượt hơn nhưng nóng và tụt pin. | Cần cẩn thận | ROOT | `perf.gov_performance` |
| 17 | **CPU governor: Schedutil** | Cân bằng giữa hiệu năng và thời lượng pin. | An toàn | ROOT | `perf.gov_schedutil` |
| 18 | **CPU governor: Powersave** | Tiết kiệm pin tối đa, máy sẽ nguội hơn nhưng chậm hơn. | An toàn | ROOT | `perf.gov_powersave` |
| 19 | **Kéo dài thời gian chạy nền** | Cho phép service nền sống lâu hơn, ít bị hệ thống dọn. | Cần cẩn thận | ROOT / Shizuku | `perf.bg_service` |
| 20 | **Tắt dịch vụ logd** | Tắt ghi log hệ thống, giảm I/O. Rất khó gỡ lỗi khi xảy ra sự cố. | Nguy hiểm | ROOT | `perf.logd_off` |
| 21 | **Nới lowmemory_kill** | Cho phép hệ thống giết nhiều app hơn khi thiếu RAM. Có thể làm app bị tắt đột ngột. | Nguy hiểm | ROOT | `perf.lowmem_kill` |

## Hệ thống (22)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Tắt Wi-Fi** | Tắt hoàn toàn adapter Wi-Fi để tiết kiệm pin. | An toàn | ROOT / Shizuku | `sys.wifi_off` |
| 2 | **Tắt Bluetooth** | Tắt Bluetooth, tiết kiệm pin khi không dùng. | An toàn | ROOT / Shizuku | `sys.bt_off` |
| 3 | **Tắt dữ liệu di động** | Không còn mạng di động. Chỉ dùng khi cần tiết kiệm tuyệt đối. | Nguy hiểm | ROOT / Shizuku | `sys.data_off` |
| 4 | **Tắt NFC** | Tắt mạch NFC, không dùng được thanh toán/chạm. | Cần cẩn thận | ROOT / Shizuku | `sys.nfc_off` |
| 5 | **Tắt định vị** | Tắt toàn bộ định vị. Các app bản đồ, GPS sẽ không hoạt động. | Nguy hiểm | ROOT / Shizuku | `sys.location_off` |
| 6 | **Tắt dịch vụ in** | Tắt Print Spooler, tiết kiệm tài nguyên nền. | An toàn | ROOT / Shizuku | `sys.print_off` |
| 7 | **Tắt ADB** | Tắt giao diện gỡ lỗi USB. Cần bật lại qua cài đặt nhà phát triển nếu cần. | Cần cẩn thận | ROOT / Shizuku | `sys.adb_off` |
| 8 | **ADB qua Wi-Fi (cổng 5555)** | Mở cổng ADB 5555. Rất nguy hiểm nếu mạng không an toàn. | Nguy hiểm | ROOT | `sys.adb_tcp` |
| 9 | **Bật chế độ tối** | Chuyển hệ thống sang giao diện tối. | An toàn | ROOT / Shizuku | `sys.dark_mode` |
| 10 | **Bật chế độ sáng** | Chuyển hệ thống sang giao diện sáng. | An toàn | ROOT / Shizuku | `sys.light_mode` |
| 11 | **Tăng cỡ chữ 1.15x** | Chữ lớn hơn, dễ đọc hơn. | An toàn | ROOT / Shizuku | `sys.font_scale` |
| 12 | **Đặt mật độ màn hình 420** | Ép dpi màn hình, giao diện gọn hơn trên màn hình lớn. | Cần cẩn thận | ROOT / Shizuku | `sys.density_420` |
| 13 | **Ẩn thanh điều hướng** | Ẩn thanh điều hướng để có thêm không gian. Vuốt từ cạnh để hiện lại. | Cần cẩn thận | ROOT / Shizuku | `sys.immersive` |
| 14 | **Ép SystemUI nền tối** | Giao diện hệ thống luôn dùng bảng màu tối. | Cần cẩn thận | ROOT / Shizuku | `sys.sysui_dark` |
| 15 | **Chọn mic tai nghe** | Ép dùng mic có dây thay vì mic ngoài. | An toàn | ROOT / Shizuku | `sys.headset_mic` |
| 16 | **Tắt tự động điền** | Không gợi ý mật khẩu/thẻ khi gõ. | An toàn | ROOT / Shizuku | `sys.autofill_off` |
| 17 | **Tắt màn hình sau 10 phút** | Tăng thời gian chờ tắt màn hình, tiết kiệm thao tác mở khóa. | An toàn | ROOT / Shizuku | `sys.screen_off_10m` |
| 18 | **Đóng app ngay khi thoát** | Giảm số app tồn đọng trong bộ nhớ, nhưng vào app lại chậm hơn. | Cần cẩn thận | ROOT / Shizuku | `sys.finish_activities` |
| 19 | **Ẩn hộp thoại lỗi** | Không hiện popup lỗi của hệ thống, giao diện gọn hơn. | An toàn | ROOT / Shizuku | `sys.hide_errors` |
| 20 | **Đóng băng app không dùng** | Vô hiệu hoá các app không cần thiết để tiết kiệm tài nguyên. | Nguy hiểm | ROOT / Shizuku | `sys.pkg_freeze` |
| 21 | **Mở cài đặt nhà phát triển** | Mở nhanh màn hình cài đặt nhà phát triển để bật ADB. | An toàn | ROOT / Shizuku | `sys.app_dev_settings` |
| 22 | **Khôi phục animation gốc** | Đưa toàn bộ thông số animation về mặc định 1.0. | An toàn | ROOT / Shizuku | `sys.reset_anim_def` |

## Hiển thị (9)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Sáng tối đa** | Đặt độ sáng màn hình ở mức tối đa (ngoài giới hạn cảm biến ánh sáng). | Cần cẩn thận | ROOT / Shizuku | `disp.max_brightness` |
| 2 | **Tối gần như tắt** | Độ sáng gần như 0 để dùng khi lái xe ban đêm. | Nguy hiểm | ROOT / Shizuku | `disp.min_brightness` |
| 3 | **Tắt rung phản hồi** | Tắt haptic khi chạm, giao diện phản hồi nhanh hơn. | An toàn | ROOT / Shizuku | `disp.haptic_off` |
| 4 | **Tắt rung khi có cuộc gọi** | Không rung khi có cuộc gọi đến. | An toàn | ROOT / Shizuku | `disp.vibrate_ring_off` |
| 5 | **Ép tần số quét 120Hz** _(Chỉ có tác dụng nếu màn hình hỗ trợ 120Hz.)_ | Buộc màn hình luôn chạy ở 120Hz nếu máy hỗ trợ. Tốn pin hơn. | Cần cẩn thận | ROOT / Shizuku | `disp.refresh_120` |
| 6 | **Tắt bộ lọc màu** | Tắt chế độ dành cho người mù màu, màu sẽ chuẩn hơn. | An toàn | ROOT / Shizuku | `disp.daltonizer_off` |
| 7 | **Tắt màn hình sau 15 giây** | Tiết kiệm pin tối đa khi để máy ngoài. | An toàn | ROOT / Shizuku | `disp.screen_off_min` |
| 8 | **Tắt tự động cảm biến sáng** | Độ sáng không tự thay đổi theo môi trường nữa. | Cần cẩn thận | ROOT / Shizuku | `disp.brightness_auto_off` |
| 9 | **Bật reflection hiệu ứng nước** | Hiệu ứng phản chiếu mới trên Android 12+, một số máy sẽ lag nhẹ. | Cần cẩn thận | ROOT | `disp.force_ms_reflect` |

## Mạng (10)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **DNS bảo mật Cloudflare** | Dùng DoH của Cloudflare qua Private DNS, chặn DNS lợi dụng. | An toàn | ROOT / Shizuku | `net.doh_cloudflare` |
| 2 | **DNS bảo mật Google** | Dùng Private DNS của Google (dns.google). | An toàn | ROOT / Shizuku | `net.doh_google` |
| 3 | **Tắt Private DNS** | Dùng DNS mặc định của nhà mạng. Nhanh hơn nhưng dễ bị chặn quảng cáo. | Cần cẩn thận | ROOT / Shizuku | `net.dns_off` |
| 4 | **Giảm tần quét Wi-Fi** | WIFI_SCAN_INTERVAL 5 phút, giảm hao pin do quét kênh. | An toàn | ROOT / Shizuku | `net.wifi_scan_slow` |
| 5 | **Tắt tiết kiệm pin Wi-Fi** | Giữ kết nối ổn định, hạn chế độ rớt kết nối. | An toàn | ROOT / Shizuku | `net.wifi_powersave_off` |
| 6 | **Bật TCP Fast Open** | Rút ngắn thời gian bắt tay TCP, tải web nhanh hơn. | Cần cẩn thận | ROOT | `net.tcp_fastopen` |
| 7 | **Tăng bộ đệm mạng** | Tăng bộ đệm TCP, hữu ích khi tải/nhận dữ liệu lớn. | Cần cẩn thận | ROOT | `net.rmem_max` |
| 8 | **Khởi động dịch vụ quản lý mạng** | Nạp lại netpolicy để áp dụng cấu hình mạng mới. | An toàn | ROOT / Shizuku | `net.netpolicy` |
| 9 | **Ưu tiên băng tần 5GHz** | Ưu tiên kết nối 5GHz khi router hỗ trợ. | Cần cẩn thận | ROOT | `net.wifi_toggle_5g` |
| 10 | **Bật tiết kiệm dữ liệu** | Hạn chế dữ liệu nền của các app. | An toàn | ROOT / Shizuku | `net.data_saver` |

## Âm thanh (6)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Tăng âm lượng tối đa** | Đẩy âm lượng media lên mức tối đa (có thể gây rách âm). | Cần cẩn thận | ROOT / Shizuku | `aud.vol_boost` |
| 2 | **Âm lượng về mặc định** | Đưa âm lượng media về mức chuẩn 7/15. | An toàn | ROOT / Shizuku | `aud.vol_normal` |
| 3 | **Bật chế độ không làm phiền** | Tắt thông báo và chuông, chỉ giữ cuộc gọi quan trọng. | An toàn | ROOT / Shizuku | `aud.dnd_on` |
| 4 | **Bật âm thanh không gian** | Kích hoạt hiệu ứng âm thanh không gian nếu thiết bị hỗ trợ. | An toàn | ROOT / Shizuku | `aud.spatial` |
| 5 | **Giảm nhiễu mic** | Bật chế độ khử nhiễu khi gọi điện. | An toàn | ROOT / Shizuku | `aud.mic_noise` |
| 6 | **Âm lượng báo thức tối đa** | Đặt âm lượng báo thức ở mức cao nhất. | An toàn | ROOT / Shizuku | `aud.alarm_max` |

## Pin & nhiệt (8)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Giới hạn sạc 80%** _(Cần kernel hỗ trợ charge_control_end_threshold.)_ | Giữ pin ở 80% để kéo dài tuổi thọ pin. Chỉ máy hỗ trợ mới có tác dụng. | Cần cẩn thận | ROOT | `bat.charge_limit_80` |
| 2 | **Giới hạn sạc 70%** | Giữ pin ở 70%, tối đa tuổi thọ pin. | Cần cẩn thận | ROOT | `bat.charge_limit_70` |
| 3 | **Sạc đầy 100%** | Gỡ giới hạn sạc, cho phép sạc đầy. | An toàn | ROOT | `bat.charge_full` |
| 4 | **Bỏ qua cảnh báo nhiệt** | Buộc hệ thống coi như máy luôn mát. CỰC KỲ NGUY HIỂM, có thể cháy máy. | Nguy hiểm | ROOT / Shizuku | `bat.thermal_override` |
| 5 | **Ghi log nhiệt độ chi tiết** | Bật log nhiệt độ để theo dõi nhiệt. | An toàn | ROOT | `bat.thermal_verbose` |
| 6 | **Tăng dòng sạc tối đa** | Ghi đè giới hạn dòng sạc. Nguy hiểm với pin và mạch sạc. | Nguy hiểm | ROOT | `bat.charge_current_max` |
| 7 | **Tạm dừng GC khi app nền** | Cho phép app bị đóng băng để giảm nhiệt, có thể gây treo app. | Nguy hiểm | ROOT | `bat.gc_frozen` |
| 8 | **Giảm sáng khi màn hình tắt** | Hạ độ sáng nền trong lúc chờ để tiết kiệm pin. | An toàn | ROOT / Shizuku | `bat.idle_brightness` |

## Riêng tư (8)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Tắt theo dõi sử dụng** | Từ chối quyền theo dõi sử dụng để bảo vệ dữ liệu cá nhân. | An toàn | ROOT / Shizuku | `sec.usage_stats` |
| 2 | **Tắt báo lỗi người dùng** | Vô hiệu hoá module phản hồi lỗi của Google. | An toàn | ROOT / Shizuku | `sec.feedback_off` |
| 3 | **Tắt quảng cáo cá nhân** | Yêu cầu hệ thống tắt ID quảng cáo nếu thiết bị hỗ trợ. | An toàn | ROOT / Shizuku | `sec.ad_id` |
| 4 | **Chặn chụp màn hình** | Cấm chụp/screenrecord màn hình trên toàn hệ thống. | Cần cẩn thận | ROOT / Shizuku | `sec.screenshot` |
| 5 | **Chặn app chạy nền** | Cấm các app chạy nền để tăng riêng tư và tiết kiệm pin. | Cần cẩn thận | ROOT / Shizuku | `sec.appop_bg` |
| 6 | **Thêm vào danh sách miễn nhiễm** | Cho phép app thường dùng không bị Doze giết. | An toàn | ROOT / Shizuku | `sec.deviceidle_whitelist` |
| 7 | **Dọn cache toàn hệ thống** | Xoá cache của mọi app, giải phóng dung lượng. | An toàn | ROOT / Shizuku | `sec.clear_app_cache` |
| 8 | **Ẩn nội dung thông báo** | Không hiển thị nội dung thông báo trên màn hình khoá. | An toàn | ROOT / Shizuku | `sec.hide_content` |

## Dọn dẹp (9)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Dọn cache app** | Dọn cache toàn bộ ứng dụng đã cài. | An toàn | ROOT / Shizuku | `cln.cache` |
| 2 | **Xoá log hệ thống** | Xoá file log và dropbox để giải phóng dung lượng. | Cần cẩn thận | ROOT | `cln.logs` |
| 3 | **Dọn thư mục tạm** | Xoá file tạm trong /data/local/tmp. | Cần cẩn thận | ROOT | `cln.temp` |
| 4 | **Giết toàn bộ app nền** | Dừng tất cả app chạy nền ngay lập tức, RAM trống tức thì. | Cần cẩn thận | ROOT / Shizuku | `cln.kill_bg` |
| 5 | **Reset đồ hoạ SurfaceFlinger** | Xoá bộ nhớ đệm GPU, sửa lỗi vỡ hình/kéo thả app. | Cần cẩn thận | ROOT | `cln.gfx_reset` |
| 6 | **Biên dịch lại toàn bộ dex** | Tối ưu lại bytecode cho app, mở nhanh hơn nhưng mất thời gian và pin. | Cần cẩn thận | ROOT | `cln.rebuild_dex` |
| 7 | **Reset dex tối ưu** | Xoá dex tối ưu, app phải biên dịch lại. Có thể làm app chậm lúc đầu. | Nguy hiểm | ROOT | `cln.reset_dex` |
| 8 | **Xuất báo cáo bộ nhớ** | Ghi log bộ nhớ hệ thống vào logcat để phân tích. | An toàn | ROOT | `cln.meminfo` |
| 9 | **Dọn cache Dalvik** | Xoá cache biên dịch Dalvik, giải phóng dung lượng. | Cần cẩn thận | ROOT | `cln.dalvik_cleanup` |

## Nâng cao (13)

| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |
|---|-----|-------|--------|-------|----------|
| 1 | **Khởi động lại SystemUI** | Tắt và mở lại SystemUI để sửa giao diện bị lỗi. Màn hình chớp vài giây. | Cần cẩn thận | ROOT | `adv.sysui_restart` |
| 2 | **Khởi động lại launcher** | Khởi động lại màn hình chính, sửa lỗi treo launcher. | Cần cẩn thận | ROOT | `adv.launcher_restart` |
| 3 | **Tắt app bất kỳ (nhập package)** | Nhập tên package để vô hiệu hoá app, ví dụ com.facebook.ganesa. | Nguy hiểm | ROOT / Shizuku | `adv.disable_app` |
| 4 | **Đặt system property (nhập key=value)** | Ghi đè thuộc tính hệ thống. Sai key có thể gây lỗi hệ thống. | Nguy hiểm | ROOT | `adv.sysprop` |
| 5 | **Chạy lệnh shell tuỳ ý** | Chạy bất kỳ lệnh nào với quyền root. Cực kỳ nguy hiểm. | Nguy hiểm | ROOT | `adv.raw_shell` |
| 6 | **Giả lập mức pin** | Giả mức pin trong hệ thống, hữu ích khi test app. | Cần cẩn thận | ROOT / Shizuku | `adv.fake_battery` |
| 7 | **Tắt kiểm tra cập nhật OTA** | Vô hiệu hoá trình cập nhật hệ thống qua mạng. | Nguy hiểm | ROOT / Shizuku | `adv.disable_ota` |
| 8 | **Dừng dịch vụ cập nhật** | Tắt updater đang chạy mà không vô hiệu hoá gói cài đặt. | Cần cẩn thận | ROOT | `adv.ota_stop` |
| 9 | **Khởi động lại máy** | Reboot ngay lập tức để áp dụng các thay đổi sâu. | Nguy hiểm | ROOT | `adv.reboot` |
| 10 | **Khởi động lại vào Recovery** | Vào chế độ recovery. Chỉ dùng khi bạn biết chắc mình đang làm gì. | Nguy hiểm | ROOT | `adv.reboot_recovery` |
| 11 | **Khởi động lại bootloader** | Vào bootloader/fastboot. Rất dễ làm brick máy nếu sai thao tác. | Nguy hiểm | ROOT | `adv.reboot_bootloader` |
| 12 | **Reset cấu hình GPS** | Xoá dữ liệu vị trí đã lưu định vị chính xác hơn. | An toàn | ROOT / Shizuku | `adv.gps_reset` |
| 13 | **Khôi phục mặc định nhà máy** | Tắt toàn bộ tweak đang bật và hoàn tác các thay đổi. | Cần cẩn thận | ROOT / Shizuku | `adv.restore_defaults` |

---

## Lệnh thực thi chi tiết

Bảng dưới liểu kỹ từng lệnh shell mà tweak thực thi (chạy qua `su -c` với ROOT, qua shell của Shizuku với Shizuku).

### `perf.anim_05` — Animation mượt 0.5x
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5`
- Hoàn tác: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`

### `perf.anim_10` — Animation chuẩn 1.0x
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`

### `perf.anim_off` — Tắt hoàn toàn animation
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0`
- Hoàn tác: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`

### `perf.anim_slow` — Slow motion 2.0x
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global window_animation_scale 2.0; settings put global transition_animation_scale 2.0; settings put global animator_duration_scale 2.0`
- Hoàn tác: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`

### `perf.hwui_gpu` — Ép vẽ bằng GPU
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `setprop debug.hwui.renderer skiagl`
- Hoàn tác: `setprop debug.hwui.renderer skiagl`

### `perf.hwui_cpu` — Tăng ngân sách CPU cho giao diện
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `setprop debug.hwui.target_cpu_time_percent 200`
- Hoàn tác: `setprop debug.hwui.target_cpu_time_percent 50`

### `perf.heap_size` — Tăng bộ nhớ heap cho app
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `setprop dalvik.vm.heapgrowthlimit 512m; setprop dalvik.vm.heapsize 1024m`
- Hoàn tác: `setprop dalvik.vm.heapgrowthlimit 256m; setprop dalvik.vm.heapsize 512m`
- Lưu ý: Cần khởi động lại để có hiệu lực.

### `perf.heap_start` — Heap khởi tạo lớn hơn
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `setprop dalvik.vm.heapstartsize 16m`
- Hoàn tác: `setprop dalvik.vm.heapstartsize 8m`

### `perf.swappiness` — Tối ưu swap
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `sysctl -w vm.swappiness 60`
- Hoàn tác: `sysctl -w vm.swappiness 100`

### `perf.compact` — Bật nén bộ nhớ chủ động
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `echo 1 > /sys/vm/compaction/proact 2>/dev/null || true`
- Hoàn tác: `echo 0 > /sys/vm/compaction/proact 2>/dev/null || true`

### `perf.drop_caches` — Giải phóng cache RAM
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `sync; echo 3 > /proc/sys/vm/drop_caches`
- Hoàn tác: `echo 1 > /proc/sys/vm/drop_caches`

### `perf.zram` — Tối ưu thuật toán zram
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `echo zstd > /sys/module/zram/parameters/comp_algorithm 2>/dev/null || echo lz4 > /sys/module/zram/parameters/comp_algorithm`
- Hoàn tác: `echo lz4 > /sys/module/zram/parameters/comp_algorithm 2>/dev/null || true`

### `perf.dex2oat` — Biên dịch app nền
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `cmd package bg-dexopt-job`
- Hoàn tác: `echo "" > /dev/null`

### `perf.dex_filter` — Bỏ kiểm tra dex
- Danh mục: Hiệu năng | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `setprop dalvik.vm.dex2oat-filter-mode verify`
- Hoàn tác: `setprop dalvik.vm.dex2oat-filter-mode none`

### `perf.lmk_adj` — Nới lmk_adj
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `setprop persist.sys.lmk_tuning.level 900 2>/dev/null || true`
- Hoàn tác: `setprop persist.sys.lmk_tuning.level 0 2>/dev/null || true`

### `perf.gov_performance` — CPU governor: Performance
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > $f 2>/dev/null; done`
- Hoàn tác: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > $f 2>/dev/null; done`

### `perf.gov_schedutil` — CPU governor: Schedutil
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > $f 2>/dev/null; done`
- Hoàn tác: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo powersave > $f 2>/dev/null; done`

### `perf.gov_powersave` — CPU governor: Powersave
- Danh mục: Hiệu năng | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo powersave > $f 2>/dev/null; done`
- Hoàn tác: `for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > $f 2>/dev/null; done`

### `perf.bg_service` — Kéo dài thời gian chạy nền
- Danh mục: Hiệu năng | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `device_config put activity_manager bg_service_empty_timeout 60000`
- Hoàn tác: `device_config delete activity_manager bg_service_empty_timeout`

### `perf.logd_off` — Tắt dịch vụ logd
- Danh mục: Hiệu năng | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `stop logd; setprop persist.logd.logpersistd.enable false`
- Hoàn tác: `start logd; setprop persist.logd.logpersistd.enable true`

### `perf.lowmem_kill` — Nới lowmemory_kill
- Danh mục: Hiệu năng | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `echo 1200 > /sys/module/lowmemory_kill/parameters/adj 2>/dev/null || true`
- Hoàn tác: `echo 1000 > /sys/module/lowmemory_kill/parameters/adj 2>/dev/null || true`

### `sys.wifi_off` — Tắt Wi-Fi
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `svc wifi disable`
- Hoàn tác: `svc wifi enable`

### `sys.bt_off` — Tắt Bluetooth
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `svc bluetooth disable`
- Hoàn tác: `svc bluetooth enable`

### `sys.data_off` — Tắt dữ liệu di động
- Danh mục: Hệ thống | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `svc data disable`
- Hoàn tác: `svc data enable`

### `sys.nfc_off` — Tắt NFC
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `svc nfc disable`
- Hoàn tác: `svc nfc enable`

### `sys.location_off` — Tắt định vị
- Danh mục: Hệ thống | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure location_mode 0; svc location disable`
- Hoàn tác: `settings put secure location_mode 3; svc location enable`

### `sys.print_off` — Tắt dịch vụ in
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `svc print disable`
- Hoàn tác: `svc print enable`

### `sys.adb_off` — Tắt ADB
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global adb_enabled 0`
- Hoàn tác: `settings put global adb_enabled 1`

### `sys.adb_tcp` — ADB qua Wi-Fi (cổng 5555)
- Danh mục: Hệ thống | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `setprop service.adb.tcp.port 5555; stop adbd; start adbd`
- Hoàn tác: `setprop service.adb.tcp.port -1; stop adbd; start adbd`

### `sys.dark_mode` — Bật chế độ tối
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd uimode night yes`
- Hoàn tác: `cmd uimode night no`

### `sys.light_mode` — Bật chế độ sáng
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd uimode night no`
- Hoàn tác: `cmd uimode night yes`

### `sys.font_scale` — Tăng cỡ chữ 1.15x
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system font_scale 1.15`
- Hoàn tác: `settings put system font_scale 1.0`

### `sys.density_420` — Đặt mật độ màn hình 420
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `wm density 420`
- Hoàn tác: `wm density reset`

### `sys.immersive` — Ẩn thanh điều hướng
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global policy_control immersive.navigation=*`
- Hoàn tác: `settings put global policy_control null`

### `sys.sysui_dark` — Ép SystemUI nền tối
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `cmd overlay enable-exclusive com.android.systemui.theme.dark`
- Hoàn tác: `cmd overlay disable-exclusive com.android.systemui.theme.dark`

### `sys.headset_mic` — Chọn mic tai nghe
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure headset_mic analog`
- Hoàn tác: `settings put secure headset_mic default`

### `sys.autofill_off` — Tắt tự động điền
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure autofill_service ""`
- Hoàn tác: `settings put secure autofill_service com.google.android.marvin.talkback`

### `sys.screen_off_10m` — Tắt màn hình sau 10 phút
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_off_timeout 600000`
- Hoàn tác: `settings put system screen_off_timeout 30000`

### `sys.finish_activities` — Đóng app ngay khi thoát
- Danh mục: Hệ thống | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global always_finish_activities 1`
- Hoàn tác: `settings put global always_finish_activities 0`

### `sys.hide_errors` — Ẩn hộp thoại lỗi
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure hide_error_dialogs 1`
- Hoàn tác: `settings put secure hide_error_dialogs 0`

### `sys.pkg_freeze` — Đóng băng app không dùng
- Danh mục: Hệ thống | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `pm disable-user --user 0 com.google.android.apps.messaging`
- Hoàn tác: `pm enable --user 0 com.google.android.apps.messaging`

### `sys.app_dev_settings` — Mở cài đặt nhà phát triển
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS`
- Hoàn tác: `am start -a android.settings.SETTINGS`

### `sys.reset_anim_def` — Khôi phục animation gốc
- Danh mục: Hệ thống | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`
- Hoàn tác: `settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0`

### `disp.max_brightness` — Sáng tối đa
- Danh mục: Hiển thị | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_brightness_mode 0; settings put system screen_brightness 255`
- Hoàn tác: `settings put system screen_brightness_mode 1`

### `disp.min_brightness` — Tối gần như tắt
- Danh mục: Hiển thị | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_brightness_mode 0; settings put system screen_brightness 1`
- Hoàn tác: `settings put system screen_brightness_mode 1`

### `disp.haptic_off` — Tắt rung phản hồi
- Danh mục: Hiển thị | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system haptic_feedback_enabled 0`
- Hoàn tác: `settings put system haptic_feedback_enabled 1`

### `disp.vibrate_ring_off` — Tắt rung khi có cuộc gọi
- Danh mục: Hiển thị | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system vibrate_when_ringing 0`
- Hoàn tác: `settings put system vibrate_when_ringing 1`

### `disp.refresh_120` — Ép tần số quét 120Hz
- Danh mục: Hiển thị | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system peak_refresh_rate 120.0; settings put system min_refresh_rate 120.0`
- Hoàn tác: `settings put system peak_refresh_rate 0.0; settings put system min_refresh_rate 0.0`
- Lưu ý: Chỉ có tác dụng nếu màn hình hỗ trợ 120Hz.

### `disp.daltonizer_off` — Tắt bộ lọc màu
- Danh mục: Hiển thị | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure daltonizer_enabled 0; settings put secure accessibility_daltonizer_enabled 0`
- Hoàn tác: `settings put secure daltonizer_enabled 1`

### `disp.screen_off_min` — Tắt màn hình sau 15 giây
- Danh mục: Hiển thị | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_off_timeout 15000`
- Hoàn tác: `settings put system screen_off_timeout 30000`

### `disp.brightness_auto_off` — Tắt tự động cảm biến sáng
- Danh mục: Hiển thị | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_brightness_mode 0`
- Hoàn tác: `settings put system screen_brightness_mode 1`

### `disp.force_ms_reflect` — Bật reflection hiệu ứng nước
- Danh mục: Hiển thị | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `settings put global enable_display_cutout_protection 1; setprop debug.sf.enable_systrace 0`
- Hoàn tác: `settings put global enable_display_cutout_protection 0`

### `net.doh_cloudflare` — DNS bảo mật Cloudflare
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global private_dns_mode hostname; settings put global private_dns_specifier cloudflare-dns.com`
- Hoàn tác: `settings put global private_dns_mode off`

### `net.doh_google` — DNS bảo mật Google
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global private_dns_mode hostname; settings put global private_dns_specifier dns.google`
- Hoàn tác: `settings put global private_dns_mode off`

### `net.dns_off` — Tắt Private DNS
- Danh mục: Mạng | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global private_dns_mode off`
- Hoàn tác: `settings put global private_dns_mode hostname`

### `net.wifi_scan_slow` — Giảm tần quét Wi-Fi
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global wifi_scan_interval 300000`
- Hoàn tác: `settings put global wifi_scan_interval 240000`

### `net.wifi_powersave_off` — Tắt tiết kiệm pin Wi-Fi
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global wifi_power_save 0`
- Hoàn tác: `settings put global wifi_power_save 1`

### `net.tcp_fastopen` — Bật TCP Fast Open
- Danh mục: Mạng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `sysctl -w net.ipv4.tcp_fastopen 3; sysctl -w net.ipv6.tcp_fastopen 3`
- Hoàn tác: `sysctl -w net.ipv4.tcp_fastopen 1; sysctl -w net.ipv6.tcp_fastopen 1`

### `net.rmem_max` — Tăng bộ đệm mạng
- Danh mục: Mạng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `sysctl -w net.core.rmem_max 16777216; sysctl -w net.core.wmem_max 16777216`
- Hoàn tác: `sysctl -w net.core.rmem_max 212992; sysctl -w net.core.wmem_max 212992`

### `net.netpolicy` — Khởi động dịch vụ quản lý mạng
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd netpolicy reload`
- Hoàn tác: `cmd netpolicy list`

### `net.wifi_toggle_5g` — Ưu tiên băng tần 5GHz
- Danh mục: Mạng | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `cmd wifi set-wifi-enabled enabled 2>/dev/null || svc wifi enable`
- Hoàn tác: `svc wifi enable`

### `net.data_saver` — Bật tiết kiệm dữ liệu
- Danh mục: Mạng | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd netpolicy set restrict-background true`
- Hoàn tác: `cmd netpolicy set restrict-background false`

### `aud.vol_boost` — Tăng âm lượng tối đa
- Danh mục: Âm thanh | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `cmd media_session volume --stream 3 --set 15`
- Hoàn tác: `cmd media_session volume --stream 3 --set 7`

### `aud.vol_normal` — Âm lượng về mặc định
- Danh mục: Âm thanh | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd media_session volume --stream 3 --set 7`
- Hoàn tác: `cmd media_session volume --stream 3 --set 7`

### `aud.dnd_on` — Bật chế độ không làm phiền
- Danh mục: Âm thanh | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd notification set_dnd on`
- Hoàn tác: `cmd notification set_dnd off`

### `aud.spatial` — Bật âm thanh không gian
- Danh mục: Âm thanh | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global enable_spatial 1`
- Hoàn tác: `settings put global enable_spatial 0`

### `aud.mic_noise` — Giảm nhiễu mic
- Danh mục: Âm thanh | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure noise_suppression 1`
- Hoàn tác: `settings put secure noise_suppression 0`

### `aud.alarm_max` — Âm lượng báo thức tối đa
- Danh mục: Âm thanh | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd media_session volume --stream 4 --set 15`
- Hoàn tác: `cmd media_session volume --stream 4 --set 6`

### `bat.charge_limit_80` — Giới hạn sạc 80%
- Danh mục: Pin & nhiệt | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `echo 80 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`
- Hoàn tác: `echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`
- Lưu ý: Cần kernel hỗ trợ charge_control_end_threshold.

### `bat.charge_limit_70` — Giới hạn sạc 70%
- Danh mục: Pin & nhiệt | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `echo 70 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`
- Hoàn tác: `echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`

### `bat.charge_full` — Sạc đầy 100%
- Danh mục: Pin & nhiệt | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`
- Hoàn tác: `echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true`

### `bat.thermal_override` — Bỏ qua cảnh báo nhiệt
- Danh mục: Pin & nhiệt | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `dumpsys thermalservice override-status 0`
- Hoàn tác: `dumpsys thermalservice reset`

### `bat.thermal_verbose` — Ghi log nhiệt độ chi tiết
- Danh mục: Pin & nhiệt | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `setprop persist.sys.thermal.enable 1; setprop persist.vendor.thermal.verbose 1`
- Hoàn tác: `setprop persist.sys.thermal.enable 0`

### `bat.charge_current_max` — Tăng dòng sạc tối đa
- Danh mục: Pin & nhiệt | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `echo 2000000 > /sys/class/power_supply/battery/charge_control_max_current 2>/dev/null || true`
- Hoàn tác: `echo 0 > /sys/class/power_supply/battery/charge_control_max_current 2>/dev/null || true`

### `bat.gc_frozen` — Tạm dừng GC khi app nền
- Danh mục: Pin & nhiệt | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `setprop dalvik.vm.frozen 1 2>/dev/null || true`
- Hoàn tác: `setprop dalvik.vm.frozen 0 2>/dev/null || true`

### `bat.idle_brightness` — Giảm sáng khi màn hình tắt
- Danh mục: Pin & nhiệt | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put system screen_brightness_mode 0; settings put system screen_brightness 26`
- Hoàn tác: `settings put system screen_brightness_mode 1`

### `sec.usage_stats` — Tắt theo dõi sử dụng
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `cmd appops set com.google.android.apps.nexuslauncher GET_USAGE_STATS ignore 2>/dev/null || true`
- Hoàn tác: `cmd appops set com.google.android.apps.nexuslauncher GET_USAGE_STATS default 2>/dev/null || true`

### `sec.feedback_off` — Tắt báo lỗi người dùng
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `pm disable-user --user 0 com.google.android.feedback`
- Hoàn tác: `pm enable --user 0 com.google.android.feedback`

### `sec.ad_id` — Tắt quảng cáo cá nhân
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put global limit_ad_tracking 1 2>/dev/null || true`
- Hoàn tác: `settings put global limit_ad_tracking 0 2>/dev/null || true`

### `sec.screenshot` — Chặn chụp màn hình
- Danh mục: Riêng tư | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure screenshot_disabled 1 2>/dev/null || true`
- Hoàn tác: `settings put secure screenshot_disabled 0 2>/dev/null || true`

### `sec.appop_bg` — Chặn app chạy nền
- Danh mục: Riêng tư | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `cmd appops set RUN_IN_BACKGROUND ignore 2>/dev/null || cmd appops set RUN_IN_BACKGROUND reject 2>/dev/null || true`
- Hoàn tác: `cmd appops set RUN_IN_BACKGROUND default 2>/dev/null || true`

### `sec.deviceidle_whitelist` — Thêm vào danh sách miễn nhiễm
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `dumpsys deviceidle whitelist +com.zenmate.app 2>/dev/null || true`
- Hoàn tác: `dumpsys deviceidle whitelist -com.zenmate.app 2>/dev/null || true`

### `sec.clear_app_cache` — Dọn cache toàn hệ thống
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `pm trim-caches 999999999999`
- Hoàn tác: `echo "" > /dev/null`

### `sec.hide_content` — Ẩn nội dung thông báo
- Danh mục: Riêng tư | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `settings put secure lock_screen_allow_private_notifications 0`
- Hoàn tác: `settings put secure lock_screen_allow_private_notifications 1`

### `cln.cache` — Dọn cache app
- Danh mục: Dọn dẹp | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `pm trim-caches 999999999999`
- Hoàn tác: `echo "" > /dev/null`

### `cln.logs` — Xoá log hệ thống
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `rm -rf /data/log/* /data/system/dropbox/* /data/anr/* 2>/dev/null || true`
- Hoàn tác: `echo "" > /dev/null`

### `cln.temp` — Dọn thư mục tạm
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `rm -rf /data/local/tmp/* 2>/dev/null || true`
- Hoàn tác: `echo "" > /dev/null`

### `cln.kill_bg` — Giết toàn bộ app nền
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `am kill-all`
- Hoàn tác: `echo "" > /dev/null`

### `cln.gfx_reset` — Reset đồ hoạ SurfaceFlinger
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `dumpsys SurfaceFlinger --latency-clear 2>/dev/null || service call SurfaceFlinger 1013`
- Hoàn tác: `echo "" > /dev/null`

### `cln.rebuild_dex` — Biên dịch lại toàn bộ dex
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `cmd package compile -m speed -f -a`
- Hoàn tác: `echo "" > /dev/null`

### `cln.reset_dex` — Reset dex tối ưu
- Danh mục: Dọn dẹp | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `cmd package compile --reset`
- Hoàn tác: `cmd package compile -m speed -a`

### `cln.meminfo` — Xuất báo cáo bộ nhớ
- Danh mục: Dọn dẹp | Mức độ: An toàn | Quyền: ROOT
- Áp dụng: `dumpsys meminfo > /data/local/tmp/kenzi_meminfo.txt 2>/dev/null || true`
- Hoàn tác: `rm -f /data/local/tmp/kenzi_meminfo.txt`

### `cln.dalvik_cleanup` — Dọn cache Dalvik
- Danh mục: Dọn dẹp | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `rm -rf /data/dalvik-cache/* 2>/dev/null || true`
- Hoàn tác: `echo "" > /dev/null`

### `adv.sysui_restart` — Khởi động lại SystemUI
- Danh mục: Nâng cao | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `am force-stop com.android.systemui; sleep 1; am start -n com.android.systemui/.SystemUIService 2>/dev/null || true`
- Hoàn tác: `am force-stop com.android.systemui; sleep 1; am start -n com.android.systemui/.SystemUIService 2>/dev/null || true`

### `adv.launcher_restart` — Khởi động lại launcher
- Danh mục: Nâng cao | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `am force-stop com.google.android.apps.nexuslauncher 2>/dev/null || true`
- Hoàn tác: `am start -a android.intent.action.MAIN -c android.intent.category.HOME`

### `adv.disable_app` — Tắt app bất kỳ (nhập package)
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Ô nhập: `PACKAGE`
- Áp dụng: `pm disable-user --user 0 {pkg}`
- Hoàn tác: `pm enable --user 0 {pkg}`

### `adv.sysprop` — Đặt system property (nhập key=value)
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT
- Ô nhập: `SYSPROP`
- Áp dụng: `setprop {key}`
- Hoàn tác: `echo "" > /dev/null`

### `adv.raw_shell` — Chạy lệnh shell tuỳ ý
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT
- Ô nhập: `RAW`
- Áp dụng: `{cmd}`
- Hoàn tác: `echo "" > /dev/null`

### `adv.fake_battery` — Giả lập mức pin
- Danh mục: Nâng cao | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `dumpsys battery set level 50; dumpsys battery set status 2`
- Hoàn tác: `dumpsys battery reset`

### `adv.disable_ota` — Tắt kiểm tra cập nhật OTA
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT / Shizuku
- Áp dụng: `for p in com.google.android.gms com.android.systemupdater com.android.carrierconfig; do pm disable-user --user 0 $p 2>/dev/null; done; true`
- Hoàn tác: `for p in com.google.android.gms com.android.systemupdater com.android.carrierconfig; do pm enable --user 0 $p 2>/dev/null; done; true`

### `adv.ota_stop` — Dừng dịch vụ cập nhật
- Danh mục: Nâng cao | Mức độ: Cần cẩn thận | Quyền: ROOT
- Áp dụng: `pkill -f updater 2>/dev/null; pkill -f com.google.android.gms.unstable 2>/dev/null; true`
- Hoàn tác: `echo "" > /dev/null`

### `adv.reboot` — Khởi động lại máy
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `svc power reboot || reboot`
- Hoàn tác: `echo "" > /dev/null`

### `adv.reboot_recovery` — Khởi động lại vào Recovery
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `svc power reboot recovery || reboot recovery`
- Hoàn tác: `echo "" > /dev/null`

### `adv.reboot_bootloader` — Khởi động lại bootloader
- Danh mục: Nâng cao | Mức độ: Nguy hiểm | Quyền: ROOT
- Áp dụng: `svc power reboot bootloader || reboot bootloader`
- Hoàn tác: `echo "" > /dev/null`

### `adv.gps_reset` — Reset cấu hình GPS
- Danh mục: Nâng cao | Mức độ: An toàn | Quyền: ROOT / Shizuku
- Áp dụng: `pm clear com.android.location.fused 2>/dev/null || true`
- Hoàn tác: `echo "" > /dev/null`

### `adv.restore_defaults` — Khôi phục mặc định nhà máy
- Danh mục: Nâng cao | Mức độ: Cần cẩn thận | Quyền: ROOT / Shizuku
- Áp dụng: `__RESTORE_ALL__`
- Hoàn tác: `echo "" > /dev/null`
