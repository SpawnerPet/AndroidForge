# Changelog

## 1.2.0 (versionCode 120) — bản phát hành đầu tiên

### Tính năng
- **106 tweak nội bộ** trong 9 danh mục: Hiệu năng, Hệ thống, Hiển thị, Mạng, Âm thanh, Pin & nhiệt, Riêng tư, Dọn dẹp, Nâng cao.
- **Chặn app khi không có ROOT/Shizuku** — màn hình Gate với nút mở Shizuku, mở Root Manager và kiểm tra lại quyền.
- **Phân quyền theo tính năng** — ROOT mở toàn bộ; Shizuku chỉ mở nhóm tương thích ADB shell, các mục còn lại hiển thị biểu tượng khoá.
- **Cảnh báo bắt buộc** trước khi bật 19 tweak mức `DANGER`.
- **Tự cập nhật** qua `manifest.json`: tải & cài APK (root/Shizuku ưu tiên `pm install -r -d`), đồng thời nạp thêm tweak từ xa vào registry.
- **Khôi phục mặc định** — chạy lệnh hoàn tác của toàn bộ tweak đang bật.
- Màn hình **Máy** (thông tin phần cứng) và **Quyền** (trạng thái quyền ứng dụng theo từng permission).

### Giao diện
- Liquid glass: bề mặt kính trong mở, viền hairline, dải phản xạ ánh sáng, bo góc tròn.
- Nền tự chuyển màu tự nhiên qua 4 màu chủ đạo — phẳng, không gradient.
- Bảng màu: Aqua `#7DF9E6`, Sky `#6EA8FF`, Violet `#B48CFF`, Ember `#FF8A6B`.
- Chuyển động tối thiểu (`tween` 160–260ms), không ripple, không hiệu ứng nặng.

### Kỹ thuật
- Kotlin 2.0.21, Jetpack Compose (BOM 2024.10.01), Material 3, ViewModel + StateFlow.
- `dev.rikka.shizuku:api:13.1.5`, phát hiện root qua `su -c id`, nhận diện Magisk/KernelSU/APatch/SuperSU.
- minSdk 26, targetSdk 35, đã ký v2 (keystore `keystore.jks`).
