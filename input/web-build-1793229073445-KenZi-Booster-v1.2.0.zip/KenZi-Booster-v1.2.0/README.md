# KenZi Booster — Công cụ tăng hiệu năng Android bằng Root / Shizuku

**Made by KenZi (Tài bá khí)**

| | |
|---|---|
| Package | `com.kenzi.booster` |
| Phiên bản | 1.2.0 (versionCode 120) |
| Yêu cầu | Android 8.0+ (minSdk 26), targetSdk 35 |
| Ngôn ngữ | Kotlin + Jetpack Compose (Material 3) |
| Tổng tweak | **106** tweak nội bộ + tweak từ xa qua manifest |

---

## 1. Tính năng chính

### 1.1 Chặn app khi không có quyền
Ứng dụng **không vào được** nếu máy không có ROOT và cũng không có Shizuku.
Màn hình chặn (Gate) hiển thị logo, thương hiệu "Made by KenZi (Tài bá khí)" và 3 nút:
- **Mở Shizuku** – mở app Shizuku để cấp quyền ADB.
- **Mở Root Manager** – mở Magisk / KernelSU / APatch / SuperSU (tự dò theo `/data/adb/*`).
- **Kiểm tra lại quyền** – dò lại `su -c id` và `Shizuku.pingBinder()`.

### 1.2 Phân quyền theo tính năng
| Quyền | Mở khoá |
|---|---|
| **ROOT** | Toàn bộ tweak, kể cả các tweak nguy hiểm (sysprop, kernel, gỡ OTA, khôi phục…). |
| **SHIZUKU** | Chỉ các tweak an toàn tương thích ADB shell (`settings put`, `cmd`, `dumpsys`, `wm`, `pm`…). Các tweak yêu cầu ROOT sẽ bị khoá và hiển thị biểu tượng khoá. |

Mỗi tweak có trường `access ∈ {ROOT, SHIZUKU, BOTH}`; UI tự động khoá các mục không phù hợp với quyền hiện có.

### 1.3 Cảnh báo trước khi bật tính năng nguy hiểm
Mọi tweak mức `DANGER` (19 tweak: gỡ OTA, ép thermal, đổi governor CPU, tắt bảo mật, xoá app, reboot, cài prop tùy ý…) sẽ **bắt buộc** hiện hộp thoại cảnh báo với nội dung tác động trước khi lệnh được gửi đi. Không thể bật bằng thao tác một chạm.

### 1.4 Giao diện Liquid Glass
- Nền **tự chuyển màu tự nhiên**: một infinite transition đi qua 4 màu chủ đạo, **phẳng, không gradient** (nội suy màu tuyến tính giữa 2 màu).
- Bề mặt "kính": nền trong mở, viền hairline 1dp, dải phản xạ ánh sáng ở mép trên.
- Bo góc tròn xuyên suốt (14dp → 28dp).
- **Không ripple**, không hiệu ứng nặng: mọi chuyển động dùng `tween` 160–260ms, chỉ dùng `animateFloatAsState`/`animateColorAsState`.
- Bảng màu 4 màu chính: **Aqua `#7DF9E6`**, **Sky `#6EA8FF`**, **Violet `#B48CFF`**, **Ember `#FF8A6B`**.

### 1.5 4 màn hình
| Tab | Nội dung |
|---|---|
| **Tweak** | Danh sách 106 tweak, ô tìm kiếm, lọc theo 9 danh mục, huy hiệu mức độ, trạng thái bật/tắt, tiến trình đang chạy. |
| **Máy** | Thông tin phần cứng: SoC, nhân CPU, RAM, lưu trữ, pin, kernel, SELinux, GPU, tần số màn hình, thời gian chạy máy, tên thiết bị. |
| **Quyền** | Trạng thái ROOT / Shizuku, root manager đang dùng, danh sách quyền Android của app kèm trạng thái **đã cấp / chưa cấp**, mở nhanh Shizuku & Root Manager. |
| **Cài đặt** | Chế độ tối, nền chuyển màu động, cấu hình tự cập nhật, khôi phục mặc định, thông tin ứng dụng & API (version, versionCode, package, endpoint, manifest URL, build type, số tweak đang bật). |

### 1.6 Tự cập nhật + tweak từ xa
Ứng dụng đọc `manifest.json` từ URL cấu hình (mặc định trong **Cài đặt**):
1. Nếu `versionCode` mới > hiện tại → tải APK và cài (ưu tiên `pm install -r -d` qua root/Shizuku, không có thì mở trình cài đặt hệ thống qua FileProvider).
2. Danh sách `tweaks` trong manifest được **ghép thêm vào registry nội bộ** — cho phép phát hành tweak mới (cả nhẹ lẫn nguy hiểm) mà không cần build lại APK. Xem `docs/manifest.example.json`.

### 1.7 Khôi phục mặc định
Nút **"Khôi phục mặc định nhà máy"** chạy lệnh hoàn tác (`revert`) của toàn bộ tweak đang bật theo thứ tự ngược lại.

---

## 2. Cài đặt

### 2.1 Yêu cầu
- Máy đã **root** (Magisk / KernelSU / APatch / SuperSU) **hoặc** có **Shizuku** đang chạy.
- Android 8.0 trở lên.

### 2.2 Cài từ APK
```
KenZi-Booster-v1.2.0.apk
```
- Cài trực tiếp: mở file APK → cho phép "Cài ứng dụng không xác định" → Cài đặt.
- Hoặc adb:
```bash
adb install -r KenZi-Booster-v1.2.0.apk
```
- Với root, có thể cài im lặng:
```bash
adb push KenZi-Booster-v1.2.0.apk /data/local/tmp/
adb shell su -c "pm install -r /data/local/tmp/KenZi-Booster-v1.2.0.apk"
```

### 2.3 Cấp quyền
- **Root**: mở app, hệ thống hỏi "Cấp quyền cho KenZi Booster?" → chọn **Cấp**. Sau đó bấm "Kiểm tra lại quyền".
- **Shizuku**: mở app Shizuku → khởi động bằng Wireless debugging (Android 11+) hoặc `adb shell` → quay lại KenZi Booster → "Kiểm tra lại quyền".

---

## 3. Danh sách tweak

Có **106 tweak** nội bộ. Bảng đầy đủ (mô tả, mức độ, quyền, mã, lệnh shell áp dụng/hoàn tác) nằm ở:

- [`docs/TWEAKS.md`](docs/TWEAKS.md) — bảng chi tiết + lệnh thực thi từng tweak.
- [`docs/tweaks.json`](docs/tweaks.json) — dữ liệu dạng máy đọc được (sinh tự động từ `TweakRegistry.kt`).

Phân bố:
| Danh mục | Số lượng | | Mức độ | Số lượng | | Quyền | Số lượng |
|---|---|---|---|---|---|---|---|
| Hiệu năng | 21 | | An toàn | 45 | | ROOT | 42 |
| Hệ thống | 22 | | Cần cẩn thận | 42 | | ROOT / Shizuku | 64 |
| Hiển thị | 9 | | Nguy hiểm | 19 | | | |
| Mạng | 10 | | | | | | |
| Âm thanh | 6 | | | | | | |
| Pin & nhiệt | 8 | | | | | | |
| Riêng tư | 8 | | | | | | |
| Dọn dẹp | 9 | | | | | | |
| Nâng cao | 13 | | | | | | |

Một số tweak nổi bật:

**Hiệu năng** — Animation 0.5x/1.0x/2.0x/tắt, ép HWUI renderer, tăng ngân sách CPU cho UI, tăng heap Dalvik, tối ưu GC, tắt app nền, tối ưu cảm ứng, thay đổi CPU governor (performance / schedutil / powersave)...

**Pin & nhiệt** — Ép thermal override (nguy hiểm), hạ mức nhiệt tối đa, giảm độ sáng tự động, tắt fast charging, tối ưu wakelock, cắt băng thông...

**Nâng cao** — Gỡ OTA, đặt system property tùy ý, chạy shell lệnh tùy ý, gỡ/ẩn app theo package name, reboot / reboot recovery / bootloader, khôi phục mặc định.

---

## 4. Tự cập nhật & manifest

Xem [`docs/manifest.example.json`](docs/manifest.example.json). Cấu trúc:

```json
{
  "versionCode": 121,
  "versionName": "1.2.1",
  "changelog": "Thêm 3 tweak mới, sửa lỗi treo khi tắt animation",
  "apkUrl": "https://.../KenZi-Booster-v1.2.1.apk",
  "tweaks": [
    {
      "id": "net.dns_cloudflare",
      "name": "DNS Cloudflare (nhẹ)",
      "desc": "Đổi DNS toàn hệ thống sang 1.1.1.1",
      "category": "NETWORK",
      "risk": "SAFE",
      "access": "BOTH",
      "apply": "settings put global private_dns_mode hostname; settings put global private_dns_specifier one.one.one.one",
      "revert": "settings put global private_dns_mode off"
    },
    {
      "id": "adv.disable_verify",
      "name": "Tắt xác minh APK (nguy hiểm)",
      "desc": "Cho phép cài app ký bằng chứng thứ bất kỳ",
      "category": "ADVANCED",
      "risk": "DANGER",
      "access": "ROOT",
      "apply": "settings put global package_verifier_enable 0"
    }
  ]
}
```

Giá trị hợp lệ:
- `category`: `PERFORMANCE | SYSTEM | DISPLAY | NETWORK | AUDIO | BATTERY | PRIVACY | CLEANUP | ADVANCED`
- `risk`: `SAFE | CAUTION | DANGER`
- `access`: `ROOT | SHIZUKU | BOTH`
- `inputKind` (tuỳ chọn): `PACKAGE | SYSPROP | RAW` — khi có, app sẽ hỏi người dùng nhập giá trị trước khi chạy.

Trong app: **Cài đặt → Cập nhật tự động** → dán URL manifest → **Lưu URL** → **Kiểm tra cập nhật**.

---

## 5. Build lại từ mã nguồn

```bash
export ANDROID_HOME=$ANDROID_SDK_ROOT
./gradlew :app:assembleRelease
```
Kết quả: `app/build/outputs/apk/release/app-release.apk`

### Ký APK
File `keystore.properties` ở thư mục gốc (đã có sẵn trong gói này):
```properties
storeFile=keystore.jks
storePassword=kenzi2026
keyAlias=kenzi
keyPassword=kenzi2026
```
Tạo keystore mới nếu muốn dùng khóa riêng:
```bash
keytool -genkeypair -v -keystore keystore.jks -alias kenzi \
  -keyalg RSA -keysize 2048 -validity 10950
```
> APK đã ký sẵn trong gói. Nếu bạn đổi keystore, người dùng phải gỡ cài app cũ trước khi cài bản mới (khác chữ ký).

### Cấu trúc mã nguồn
```
kenzi/
├── app/src/main/java/com/kenzi/booster/
│   ├── MainActivity.kt              # Điều hướng 4 tab, bottom bar glass, toast
│   ├── core/
│   │   ├── Models.kt                # Tweak, Risk, Access, TweakCategory, Privilege
│   │   ├── ShellRunner.kt           # Chạy lệnh qua root / Shizuku / plain
│   │   ├── PrivilegeManager.kt      # Dò root, dò Shizuku, quyền đã cấp
│   │   ├── TweakRegistry.kt         # 106 tweak nội bộ
│   │   ├── DeviceInfo.kt            # Thu thập thông tin máy
│   │   ├── UpdateManager.kt         # Manifest, tải & cài APK
│   │   ├── Prefs.kt                 # SharedPreferences
│   │   └── AppViewModel.kt          # State + logic
│   └── ui/
│       ├── theme/Theme.kt           # 4 màu chủ đạo, nền chuyển màu
│       ├── components/Glass.kt      # AnimatedBackdrop, GlassSurface, GlassButton
│       ├── components/Widgets.kt    # TweakRow, RiskBadge, InfoRow, StatTile
│       └── screens/                 # Gate, Tweaks, Device, Permissions, Settings
├── docs/
├── tools/                           # Script sinh tài liệu từ TweakRegistry.kt
├── keystore.jks / keystore.properties
└── build.gradle.kts / settings.gradle.kts / gradle.properties
```

---

## 6. Lưu ý an toàn

- Mọi tweak đều thay đổi cấu hình hệ thống — hãy chỉ bật những gì bạn hiểu.
- Luôn dùng nút **Khôi phục mặc định** nếu máy bị lỗi sau khi tweak.
- Có thể flash lại ROM (không wipe data) để trở về trạng thái sạch.
- KenZi Booster không thu thập dữ liệu, không gửi thông tin máy lên máy chủ. Kết nối mạng chỉ dùng cho chức năng tự cập nhật.

---

**Made by KenZi (Tài bá khí)**
