#!/usr/bin/env python3
"""Trích xuất danh sách tweak từ TweakRegistry.kt để sinh tài liệu."""
import json
import re
from collections import Counter

SRC = "/workspace/kenzi/app/src/main/java/com/kenzi/booster/core/TweakRegistry.kt"
OUT = "/workspace/kenzi/docs/tweaks.json"

text = open(SRC, encoding="utf-8").read()
body = text[text.index("val ALL: List<Tweak> = listOf("):]

# Mỗi tweak bắt đầu bằng một dòng có dấu "t(" ở cấp thụt lồng listOf
chunks = body.split("\n        t(")
chunks = [c for c in chunks[1:] if c.strip()]

PAT_ID = re.compile(r'^\s*"([a-z0-9_.]+)"\s*,\s*"((?:[^"\\]|\\.)*)"\s*,\s*"((?:[^"\\]|\\.)*)"', re.S)
PAT_CAT = re.compile(r"TweakCategory\.([A-Z_]+)")
PAT_RISK = re.compile(r"Risk\.([A-Z_]+)")
PAT_ACC = re.compile(r"Access\.([A-Z_]+)")
PAT_APPLY = re.compile(r'apply\s*=\s*"((?:[^"\\]|\\.)*)"')
PAT_REVERT = re.compile(r'revert\s*=\s*"((?:[^"\\]|\\.)*)"')
PAT_INPUT = re.compile(r'input\s*=\s*InputKind\.([A-Z_]+)')
PAT_NOTE = re.compile(r'note\s*=\s*"((?:[^"\\]|\\.)*)"')
PAT_LABEL = re.compile(r'label\s*=\s*"((?:[^"\\]|\\.)*)"')


def unescape(s):
    return (s.replace('\\"', '"').replace("\\$", "$").replace("\\\\", "\\")
             .replace("\\n", "\n").replace("\\t", "\t"))


tweaks = []
for c in chunks:
    m = PAT_ID.match(c)
    if not m:
        continue
    cat = PAT_CAT.search(c)
    risk = PAT_RISK.search(c)
    acc = PAT_ACC.search(c)
    ap = PAT_APPLY.search(c)
    rv = PAT_REVERT.search(c)
    inp = PAT_INPUT.search(c)
    note = PAT_NOTE.search(c)
    lb = PAT_LABEL.search(c)
    tweaks.append({
        "id": m.group(1),
        "name": unescape(m.group(2)),
        "desc": unescape(m.group(3)),
        "category": cat.group(1) if cat else "SYSTEM",
        "risk": risk.group(1) if risk else "SAFE",
        "access": acc.group(1) if acc else "BOTH",
        "apply": unescape(ap.group(1)) if ap else "",
        "revert": unescape(rv.group(1)) if rv else "",
        "input": inp.group(1) if inp else "",
        "label": unescape(lb.group(1)) if lb else "",
        "note": unescape(note.group(1)) if note else "",
    })

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(tweaks, f, ensure_ascii=False, indent=2)

print("Tong so tweak:", len(tweaks))
print("Danh muc:", dict(Counter(t["category"] for t in tweaks)))
print("Muc do:", dict(Counter(t["risk"] for t in tweaks)))
print("Quyen:", dict(Counter(t["access"] for t in tweaks)))
ids = [t["id"] for t in tweaks]
assert len(ids) == len(set(ids)), "trung id: " + str([i for i in ids if ids.count(i) > 1])
print("Khong trung id. OK")
