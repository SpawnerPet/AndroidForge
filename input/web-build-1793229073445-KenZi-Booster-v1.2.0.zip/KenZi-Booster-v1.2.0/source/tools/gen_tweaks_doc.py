#!/usr/bin/env python3
"""Sinh docs/TWEAKS.md từ docs/tweaks.json."""
import json

CAT_VI = {
    "PERFORMANCE": "Hiệu năng",
    "SYSTEM": "Hệ thống",
    "DISPLAY": "Hiển thị",
    "NETWORK": "Mạng",
    "AUDIO": "Âm thanh",
    "BATTERY": "Pin & nhiệt",
    "PRIVACY": "Riêng tư",
    "CLEANUP": "Dọn dẹp",
    "ADVANCED": "Nâng cao",
}
RISK_VI = {
    "SAFE": "An toàn",
    "CAUTION": "Cần cẩn thận",
    "DANGER": "Nguy hiểm",
}
ACC_VI = {
    "ROOT": "ROOT",
    "SHIZUKU": "Shizuku",
    "BOTH": "ROOT / Shizuku",
}

data = json.load(open("/workspace/kenzi/docs/tweaks.json", encoding="utf-8"))

lines = []
lines.append("# Danh sách tweak của KenZi Booster\n")
lines.append(f"Tổng cộng **{len(data)} tweak** trong "
             f"**{len({t['category'] for t in data})} danh mục**.\n")
lines.append("Ký hiệu mức độ:")
lines.append("- `AN TOÀN` — chỉ đổi tham số hiển thị/hiệu năng nhẹ, hoàn tác được ngay.")
lines.append("- `CẦN CẨN THẬN` — thay đổi hệ thống, có thể ảnh hưởng pin hoặc một số app.")
lines.append("- `NGUY HIỂM` — sẽ hiện hộp thoại cảnh báo bắt buộc trước khi bật "
             "(gỡ OTA, tắt thermal, đổi governor, reboot...).\n")
lines.append("Quyền cần thiết: `ROOT` chỉ chạy được với root; "
             "`SHIZUKU` chạy được với cả root lẫn Shizuku; "
             "`ROOT / Shizuku` là cả hai.\n")
lines.append("---\n")

by_cat = {}
for t in data:
    by_cat.setdefault(t["category"], []).append(t)

order = ["PERFORMANCE", "SYSTEM", "DISPLAY", "NETWORK", "AUDIO", "BATTERY",
         "PRIVACY", "CLEANUP", "ADVANCED"]
for cat in order:
    items = by_cat.get(cat, [])
    if not items:
        continue
    lines.append(f"## {CAT_VI.get(cat, cat)} ({len(items)})\n")
    lines.append("| # | Tên | Mô tả | Mức độ | Quyền | Mã tweak |")
    lines.append("|---|-----|-------|--------|-------|----------|")
    for i, t in enumerate(items, 1):
        note = f" _({t['note']})_" if t["note"] else ""
        lines.append(
            f"| {i} | **{t['name']}**{note} | {t['desc']} | "
            f"{RISK_VI.get(t['risk'], t['risk'])} | "
            f"{ACC_VI.get(t['access'], t['access'])} | `{t['id']}` |"
        )
    lines.append("")

lines.append("---\n")
lines.append("## Lệnh thực thi chi tiết\n")
lines.append("Bảng dưới liểu kỹ từng lệnh shell mà tweak thực thi "
             "(chạy qua `su -c` với ROOT, qua shell của Shizuku với Shizuku).\n")
for t in data:
    lines.append(f"### `{t['id']}` — {t['name']}")
    lines.append(f"- Danh mục: {CAT_VI.get(t['category'], t['category'])} | "
                 f"Mức độ: {RISK_VI.get(t['risk'], t['risk'])} | "
                 f"Quyền: {ACC_VI.get(t['access'], t['access'])}")
    if t["input"]:
        lines.append(f"- Ô nhập: `{t['input']}`")
    if t["apply"]:
        lines.append(f"- Áp dụng: `{t['apply']}`")
    if t["revert"]:
        lines.append(f"- Hoàn tác: `{t['revert']}`")
    if t["note"]:
        lines.append(f"- Lưu ý: {t['note']}")
    lines.append("")

open("/workspace/kenzi/docs/TWEAKS.md", "w", encoding="utf-8").write("\n".join(lines))
print("Da sinh docs/TWEAKS.md voi", len(data), "tweak")
