package com.kenzi.booster.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kenzi.booster.core.PrivilegeManager
import com.kenzi.booster.ui.components.GlassButton
import com.kenzi.booster.ui.components.GlassButtonRow
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.components.InfoRow
import com.kenzi.booster.ui.theme.KenZiPalette

/**
 * Cổng kiểm soát: nếu không có Root hoặc Shizuku thì không vào được ứng dụng.
 */
@Composable
fun GateScreen(
    state: PrivilegeManager.PrivilegeState,
    onRetry: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenRootManager: () -> Unit
) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(32.dp),
            tintAlpha = 0.14f
        ) {
            Column(
                modifier = Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoxIcon(state.unlocked, scale)
                Spacer(Modifier.height(18.dp))
                Text(
                    "KenZi Booster",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Made by KenZi (Tài bá khí)",
                    style = MaterialTheme.typography.labelLarge,
                    color = KenZiPalette.Aqua
                )
                Spacer(Modifier.height(16.dp))

                if (state.unlocked) {
                    Text(
                        if (state.rootAvailable)
                            "Đã nhận quyền ROOT - mở khoá toàn bộ tính năng."
                        else
                            "Đã nhận quyền SHIZUKU - mở khoá nhóm tính năng phù hợp.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = KenZiPalette.Aqua,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))
                    GlassButton(
                        text = "Vào ứng dụng",
                        accent = KenZiPalette.Aqua,
                        modifier = Modifier.fillMaxWidth()
                    ) { onRetry() }
                } else {
                    Text(
                        "Ứng dụng cần quyền ROOT hoặc SHIZUKU để hoạt động.\n" +
                                "Khi chưa có quyền, ứng dụng sẽ không cho vào giao diện chính.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))

                    GlassSurface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        tintAlpha = 0.06f
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Block, contentDescription = null,
                                    tint = KenZiPalette.Ember, modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "ROOT: chưa phát hiện",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Block, contentDescription = null,
                                    tint = KenZiPalette.Ember, modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "SHIZUKU: chưa phát hiện",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "Hướng dẫn: cài Magisk/KernelSU và mở ứng dụng một lần để cấp quyền, " +
                                        "hoặc mở Shizuku và bật ADB với wireless debugging.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    GlassButtonRow {
                        GlassButton(
                            text = "Mở Shizuku",
                            accent = KenZiPalette.Sky,
                            modifier = Modifier.weight(1f)
                        ) { onOpenShizuku() }
                        GlassButton(
                            text = "Mở Root Manager",
                            accent = KenZiPalette.Violet,
                            modifier = Modifier.weight(1f)
                        ) { onOpenRootManager() }
                    }
                    Spacer(Modifier.height(12.dp))
                    GlassButton(
                        text = if (state.probing) "Đang kiểm tra quyền..." else "Kiểm tra lại quyền",
                        accent = KenZiPalette.Aqua,
                        modifier = Modifier.fillMaxWidth()
                    ) { onRetry() }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        GlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            tintAlpha = 0.05f
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                InfoRow("Trạng thái quét", if (state.probing) "Đang quét..." else "Đã quét xong")
                InfoRow(
                    "Quản lý Root",
                    if (state.rootAvailable) state.rootManager.label else "Không có"
                )
                state.lastError?.let { InfoRow("Lỗi", it, valueColor = KenZiPalette.Ember) }
            }
        }
    }
}

@Composable
private fun BoxIcon(unlocked: Boolean, scale: Float) {
    val c = if (unlocked) KenZiPalette.Aqua else KenZiPalette.Ember
    Box(
        modifier = Modifier
            .size(78.dp)
            .scale(scale)
            .clip(RoundedCornerShape(26.dp))
            .background(c.copy(alpha = 0.14f))
            .border(1.dp, c.copy(alpha = 0.45f), RoundedCornerShape(26.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (unlocked) Icons.Filled.Security else Icons.Filled.Block,
            contentDescription = null,
            tint = c,
            modifier = Modifier.size(38.dp)
        )
    }
}
