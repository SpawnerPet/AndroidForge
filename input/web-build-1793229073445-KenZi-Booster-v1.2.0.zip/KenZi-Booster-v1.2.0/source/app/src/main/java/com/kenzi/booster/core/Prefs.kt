package com.kenzi.booster.core

import android.content.Context
import android.content.SharedPreferences

/** Lưu trạng thái tweak đã bật và tuỳ chọn giao diện. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.getSharedPreferences("kenzi_booster", Context.MODE_PRIVATE)

    var darkTheme: Boolean
        get() = sp.getBoolean("dark_theme", true)
        set(v) = sp.edit().putBoolean("dark_theme", v).apply()

    var glassBlur: Boolean
        get() = sp.getBoolean("glass_blur", true)
        set(v) = sp.edit().putBoolean("glass_blur", v).apply()

    var animatedBackground: Boolean
        get() = sp.getBoolean("animated_bg", true)
        set(v) = sp.edit().putBoolean("animated_bg", v).apply()

    var lastUpdateCheck: Long
        get() = sp.getLong("last_update_check", 0L)
        set(v) = sp.edit().putLong("last_update_check", v).apply()

    var updateUrl: String
        get() = sp.getString("update_url", DEFAULT_UPDATE_URL) ?: DEFAULT_UPDATE_URL
        set(v) = sp.edit().putString("update_url", v).apply()

    fun enabledTweaks(): Set<String> =
        sp.getStringSet("enabled_tweaks", emptySet())?.toSet() ?: emptySet()

    fun setTweakEnabled(id: String, enabled: Boolean) {
        val cur = enabledTweaks().toMutableSet()
        if (enabled) cur.add(id) else cur.remove(id)
        sp.edit().putStringSet("enabled_tweaks", cur).apply()
    }

    fun clearEnabled() {
        sp.edit().remove("enabled_tweaks").apply()
    }

    fun remoteTweaksJson(): String = sp.getString("remote_tweaks", "") ?: ""

    fun setRemoteTweaks(json: String) {
        sp.edit().putString("remote_tweaks", json).apply()
    }

    companion object {
        const val DEFAULT_UPDATE_URL =
            "https://raw.githubusercontent.com/kenzi-booster/kenzi-booster-update/main/manifest.json"
    }
}
