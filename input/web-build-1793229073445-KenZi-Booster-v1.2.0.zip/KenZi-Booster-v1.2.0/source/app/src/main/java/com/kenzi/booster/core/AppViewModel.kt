package com.kenzi.booster.core

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class UiTweakState(
    val tweaks: List<Tweak> = TweakRegistry.ALL,
    val enabled: Set<String> = emptySet(),
    val busy: Set<String> = emptySet(),
    val lastResult: String? = null
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context = app.applicationContext
    val prefs = Prefs(ctx)

    private val _ui = MutableStateFlow(UiTweakState())
    val ui: StateFlow<UiTweakState> = _ui.asStateFlow()

    private val _device = MutableStateFlow<DeviceInfo?>(null)
    val device: StateFlow<DeviceInfo?> = _device.asStateFlow()

    private val _permissions = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val permissions: StateFlow<List<Pair<String, String>>> = _permissions.asStateFlow()

    private val _update = MutableStateFlow(UpdateManager.UpdateState())
    val update: StateFlow<UpdateManager.UpdateState> = _update.asStateFlow()

    private val _toast = Channel<String>(Channel.BUFFERED)
    val toast = _toast.receiveAsFlow()

    val privilegeState: StateFlow<PrivilegeManager.PrivilegeState> = PrivilegeManager.state

    init {
        loadRemoteTweaks()
        refreshPrivileges()
        refreshDeviceInfo()
        refreshPermissions()
        viewModelScope.launch { checkUpdate(silent = true) }
    }

    // ---------- Đặc quyền ----------

    fun refreshPrivileges() = viewModelScope.launch {
        PrivilegeManager.refresh(ctx)
        refreshPermissions()
    }

    fun openShizuku() = viewModelScope.launch {
        if (!PrivilegeManager.openShizuku(ctx)) _toast.send("Không tìm thấy ứng dụng Shizuku")
    }

    fun openRootManager() = viewModelScope.launch {
        if (!PrivilegeManager.openRootManager(ctx)) _toast.send("Không tìm thấy ứng dụng quản lý Root")
    }

    // ---------- Tweak ----------

    private fun loadRemoteTweaks() {
        val raw = prefs.remoteTweaksJson()
        if (raw.isBlank()) return
        try {
            val arr = JSONArray(raw)
            val remote = mutableListOf<Tweak>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val cat = TweakCategory.entries.firstOrNull { it.name == o.optString("category") }
                    ?: TweakCategory.ADVANCED
                val risk = Risk.entries.firstOrNull { it.name == o.optString("risk") } ?: Risk.CAUTION
                val acc = Access.entries.firstOrNull { it.name == o.optString("access") } ?: Access.BOTH
                remote += Tweak(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    desc = o.optString("desc"),
                    category = cat,
                    risk = risk,
                    access = acc,
                    applyCmd = o.optString("apply").ifBlank { null },
                    revertCmd = o.optString("revert").ifBlank { null },
                    remote = true
                )
            }
            _ui.value = _ui.value.copy(tweaks = TweakRegistry.ALL + remote)
        } catch (_: Throwable) {
        }
    }

    fun isEnabled(id: String): Boolean = _ui.value.enabled.contains(id)

    fun setTweakEnabled(tweak: Tweak, enabled: Boolean, input: String? = null) {
        viewModelScope.launch {
            val priv = PrivilegeManager.state.value.effective
            if (!tweak.allowed(priv)) {
                _toast.send("Tính năng này cần quyền ${if (tweak.access == Access.ROOT) "ROOT" else "SHIZUKU/ROOT"}")
                return@launch
            }
            _ui.value = _ui.value.copy(busy = _ui.value.busy + tweak.id)
            val cmd = if (enabled) tweak.applyCmd else tweak.revertCmd
            if (cmd == null) {
                prefs.setTweakEnabled(tweak.id, enabled)
                _ui.value = _ui.value.copy(
                    enabled = _ui.value.enabled.toMutableSet().apply {
                        if (enabled) add(tweak.id) else remove(tweak.id)
                    },
                    busy = _ui.value.busy - tweak.id
                )
                _toast.send(if (enabled) "Đã bật: ${tweak.name}" else "Đã tắt: ${tweak.name}")
                return@launch
            }

            if (tweak.id == "adv.restore_defaults") {
                restoreAll(priv)
                return@launch
            }

            val finalCmd = buildCommand(tweak, cmd, input)
            val res = ShellRunner.run(finalCmd, priv ?: Privilege.PLAIN)
            if (res.ok) {
                prefs.setTweakEnabled(tweak.id, enabled)
                _ui.value = _ui.value.copy(
                    enabled = _ui.value.enabled.toMutableSet().apply {
                        if (enabled) add(tweak.id) else remove(tweak.id)
                    },
                    busy = _ui.value.busy - tweak.id
                )
                _toast.send(if (enabled) "Đã áp dụng: ${tweak.name}" else "Đã hoàn tác: ${tweak.name}")
            } else {
                _ui.value = _ui.value.copy(busy = _ui.value.busy - tweak.id)
                _toast.send("Thất bại: ${res.error ?: res.output.take(160)}")
            }
        }
    }

    private fun buildCommand(tweak: Tweak, cmd: String, input: String?): String {
        val value = (input ?: "").trim()
        return when (tweak.inputKind) {
            InputKind.PACKAGE -> cmd.replace("{pkg}", value)
            InputKind.SYSPROP -> cmd.replace("{key}", value)
            InputKind.RAW -> cmd.replace("{cmd}", value)
            null -> cmd
        }
    }

    private suspend fun restoreAll(priv: Privilege?) {
        val enabled = _ui.value.enabled.toList()
        var okCount = 0
        for (id in enabled) {
            val t = _ui.value.tweaks.firstOrNull { it.id == id } ?: continue
            val revert = t.revertCmd ?: continue
            if (t.id == "adv.restore_defaults") continue
            val res = ShellRunner.run(revert, priv ?: Privilege.PLAIN)
            if (res.ok) okCount++
        }
        prefs.clearEnabled()
        _ui.value = _ui.value.copy(enabled = emptySet())
        _toast.send("Đã hoàn tác $okCount/${enabled.size} thay đổi")
    }

    fun restoreDefaults() = viewModelScope.launch { restoreAll(PrivilegeManager.state.value.effective) }

    // ---------- Thông tin máy & quyền ----------

    fun refreshDeviceInfo() = viewModelScope.launch {
        _device.value = DeviceInfoCollector.collect(ctx)
    }

    fun refreshPermissions() = viewModelScope.launch {
        val list = PrivilegeManager.grantedSpecialPermissions(ctx)
        _permissions.value = list
    }

    // ---------- Cập nhật ----------

    fun checkUpdate(silent: Boolean = false) = viewModelScope.launch {
        _update.value = _update.value.copy(checking = true, message = null)
        try {
            val manifest = UpdateManager.fetchManifest(prefs.updateUrl)
            prefs.lastUpdateCheck = System.currentTimeMillis()
            val remoteJson = JSONArray()
            manifest.tweaks.forEach { t ->
                remoteJson.put(
                    JSONObject().apply {
                        put("id", t.id)
                        put("name", t.name)
                        put("desc", t.desc)
                        put("category", t.category.name)
                        put("risk", t.risk.name)
                        put("access", t.access.name)
                        put("apply", t.applyCmd ?: "")
                        put("revert", t.revertCmd ?: "")
                    }
                )
            }
            if (manifest.tweaks.isNotEmpty()) {
                prefs.setRemoteTweaks(remoteJson.toString())
                loadRemoteTweaks()
            }
            val cur = UpdateManager.currentVersionCode(ctx)
            val hasUpdate = manifest.versionCode > cur
            _update.value = _update.value.copy(
                checking = false,
                updateAvailable = hasUpdate,
                manifest = manifest,
                remoteTweakCount = manifest.tweaks.size,
                message = if (hasUpdate)
                    "Có bản cập nhật ${manifest.versionName}" else "Bạn đang dùng bản mới nhất"
            )
            if (!silent && !hasUpdate) _toast.send("Đã là bản mới nhất (${manifest.versionName})")
        } catch (t: Throwable) {
            _update.value = _update.value.copy(
                checking = false,
                message = "Không kiểm tra được: ${t.message ?: "lỗi mạng"}"
            )
            if (!silent) _toast.send("Không tải được manifest cập nhật")
        }
    }

    fun setUpdateUrl(url: String) {
        prefs.updateUrl = url.trim()
        viewModelScope.launch { _toast.send("Đã lưu URL cập nhật") }
    }

    fun downloadAndInstall() = viewModelScope.launch {
        val manifest = _update.value.manifest ?: return@launch
        if (manifest.apkUrl.isBlank()) {
            _toast.send("Manifest không có đường dẫn APK")
            return@launch
        }
        _update.value = _update.value.copy(downloading = true, message = "Đang tải bản cập nhật...")
        try {
            val file = File(ctx.cacheDir, "kenzi_update.apk")
            withContext(Dispatchers.IO) { UpdateManager.downloadApk(manifest.apkUrl, file) }
            val ok = UpdateManager.installApk(ctx, file, PrivilegeManager.state.value.effective)
            _update.value = _update.value.copy(
                downloading = false,
                installed = ok,
                message = if (ok) "Đã cài bản cập nhật" else "Không cài được, hãy cài thủ công"
            )
            _toast.send(if (ok) "Cập nhật thành công" else "Cài đặt thất bại")
        } catch (t: Throwable) {
            _update.value = _update.value.copy(downloading = false, message = "Lỗi: ${t.message}")
            _toast.send("Tải cập nhật thất bại")
        }
    }

    fun notify(msg: String) = viewModelScope.launch { _toast.send(msg) }
}
