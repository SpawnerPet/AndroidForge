package com.kenzi.booster.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/**
 * Quản lý trạng thái đặc quyền của ứng dụng.
 * ROOT -> mở khoá toàn bộ tính năng.
 * SHIZUKU -> chỉ mở khoá nhóm tính năng phù hợp quyền shell.
 * Không có gì -> ứng dụng bị chặn, không vào được giao diện chính.
 */
object PrivilegeManager {

    private val _state = MutableStateFlow(PrivilegeState())
    val state: StateFlow<PrivilegeState> = _state.asStateFlow()

    private val mutex = Mutex()

    data class PrivilegeState(
        val rootAvailable: Boolean = false,
        val rootManager: RootManager = RootManager.UNKNOWN,
        val shizukuAvailable: Boolean = false,
        val shizukuVersion: Int = -1,
        val probing: Boolean = true,
        val lastError: String? = null
    ) {
        /** Quyền tối đa đang dùng được. */
        val effective: Privilege?
            get() = when {
                rootAvailable -> Privilege.ROOT
                shizukuAvailable -> Privilege.SHIZUKU
                else -> null
            }

        val unlocked: Boolean get() = effective != null
    }

    private fun detectRootManager(): RootManager = when {
        File("/data/adb/magisk").exists() -> RootManager.MAGISK
        File("/data/adb/ksu").exists() || File("/data/adb/ksud").exists() -> RootManager.KERNELSU
        File("/data/adb/apatch").exists() -> RootManager.APATCH
        File("/system/app/Superuser.apk").exists() || File("/system/xbin/su").exists() -> RootManager.SUPERSU
        else -> RootManager.UNKNOWN
    }

    suspend fun refresh(context: Context) = mutex.withLock {
        _state.value = _state.value.copy(probing = true)
        val (rootOk, rootOut) = ShellRunner.probeRoot()
        val rootMgr = if (rootOk) detectRootManager() else RootManager.UNKNOWN
        val shizukuOk = ShellRunner.probeShizuku()
        _state.value = PrivilegeState(
            rootAvailable = rootOk,
            rootManager = rootMgr,
            shizukuAvailable = shizukuOk,
            probing = false,
            lastError = if (!rootOk && !shizukuOk) "Không tìm thấy Root hoặc Shizuku" else null
        )
    }

    /** Mở ứng dụng Shizuku để người dùng khởi động dịch vụ. */
    fun openShizuku(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return true
        }
        return try {
            context.startActivity(
                Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(android.net.Uri.parse("package:moe.shizuku.privileged.api"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** Mở ứng dụng quản lý Root (Magisk/KernelSU/APatch) nếu tìm thấy. */
    fun openRootManager(context: Context): Boolean {
        val candidates = listOf(
            "com.topjohnwu.magisk",
            "me.weishu.kernelsu",
            "me.bmax.apatch",
            "eu.chainfire.supersu"
        )
        for (pkg in candidates) {
            val i = context.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return true
            }
        }
        return false
    }

    /** Danh sách quyền đặc biệt của hệ thống mà app đã được cấp. */
    fun grantedSpecialPermissions(context: Context): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val pm = context.packageManager
            val pkg = context.packageName
            val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            val granted = info.requestedPermissions?.toList().orEmpty()
            for (p in granted) {
                val state = try {
                    if (pm.checkPermission(p, pkg) == PackageManager.PERMISSION_GRANTED) "Đã cấp" else "Chưa cấp"
                } catch (_: Throwable) {
                    "Không xác định"
                }
                out += p to state
            }
        } catch (_: Throwable) {
        }
        return out
    }
}
