package com.kenzi.booster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kenzi.booster.core.AppViewModel
import com.kenzi.booster.core.PrivilegeManager
import com.kenzi.booster.ui.components.AnimatedBackdrop
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.screens.DeviceScreen
import com.kenzi.booster.ui.screens.GateScreen
import com.kenzi.booster.ui.screens.PermissionsScreen
import com.kenzi.booster.ui.screens.SettingsScreen
import com.kenzi.booster.ui.screens.TweaksScreen
import com.kenzi.booster.ui.theme.KenZiPalette
import com.kenzi.booster.ui.theme.KenZiTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: AppViewModel = viewModel()
            var dark by remember { mutableStateOf(vm.prefs.darkTheme) }
            KenZiTheme(darkTheme = dark) {
                AppRoot(
                    vm = vm,
                    dark = dark,
                    onToggleDark = {
                        dark = it
                        vm.prefs.darkTheme = it
                    }
                )
            }
        }
    }
}

private enum class Tab(val title: String, val icon: ImageVector, val accent: Color) {
    TWEAKS("Tweak", Icons.Filled.Bolt, KenZiPalette.Aqua),
    DEVICE("Máy", Icons.Filled.Devices, KenZiPalette.Sky),
    PERMS("Quyền", Icons.Filled.Security, KenZiPalette.Violet),
    SETTINGS("Cài đặt", Icons.Filled.Settings, KenZiPalette.Ember)
}

@Composable
private fun AppRoot(vm: AppViewModel, dark: Boolean, onToggleDark: (Boolean) -> Unit) {
    val privState by vm.privilegeState.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val device by vm.device.collectAsStateWithLifecycle()
    val permissions by vm.permissions.collectAsStateWithLifecycle()
    val update by vm.update.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(Tab.TWEAKS) }
    var toast by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        vm.toast.collect { msg ->
            toast = msg
            delay(2600)
            toast = null
        }
    }

    AnimatedBackdrop(dark = dark, animate = vm.prefs.animatedBackground) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (!privState.unlocked) {
                GateScreen(
                    state = privState,
                    onRetry = { vm.refreshPrivileges() },
                    onOpenShizuku = { vm.openShizuku() },
                    onOpenRootManager = { vm.openRootManager() }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1f)) {
                        when (tab) {
                            Tab.TWEAKS -> TweaksScreen(
                                tweaks = ui.tweaks,
                                enabled = ui.enabled,
                                busy = ui.busy,
                                privilege = privState.effective,
                                onToggle = { t, on, input -> vm.setTweakEnabled(t, on, input) }
                            )

                            Tab.DEVICE -> DeviceScreen(
                                device = device,
                                onRefresh = { vm.refreshDeviceInfo() }
                            )

                            Tab.PERMS -> PermissionsScreen(
                                state = privState,
                                permissions = permissions,
                                onRefresh = { vm.refreshPrivileges() },
                                onOpenShizuku = { vm.openShizuku() },
                                onOpenRootManager = { vm.openRootManager() }
                            )

                            Tab.SETTINGS -> SettingsScreen(
                                darkTheme = dark,
                                animatedBackground = vm.prefs.animatedBackground,
                                update = update,
                                updateUrl = vm.prefs.updateUrl,
                                appVersion = "1.2.0",
                                versionCode = 120,
                                enabledCount = ui.enabled.size,
                                lastCheck = vm.prefs.lastUpdateCheck,
                                onToggleDark = onToggleDark,
                                onToggleAnimated = { vm.prefs.animatedBackground = it },
                                onSaveUpdateUrl = { vm.setUpdateUrl(it) },
                                onCheckUpdate = { vm.checkUpdate() },
                                onDownloadUpdate = { vm.downloadAndInstall() },
                                onRestoreDefaults = { vm.restoreDefaults() }
                            )
                        }
                    }

                    BottomBar(
                        current = tab,
                        onSelect = { tab = it },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
            }

            // Thông báo nhanh
            AnimatedVisibility(
                visible = toast != null,
                enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 2 },
                exit = fadeOut(tween(160)) + slideOutVertically(tween(200)) { it / 2 },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 92.dp, start = 20.dp, end = 20.dp)
            ) {
                toast?.let {
                    GlassSurface(shape = RoundedCornerShape(18.dp), tintAlpha = 0.2f) {
                        Text(
                            it,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(
    current: Tab,
    onSelect: (Tab) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassSurface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        tintAlpha = 0.16f
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tab.entries.forEach { t ->
                val selected = t == current
                val scale by animateFloatAsState(
                    1f, tween(220), if (selected) 1.06f else 1f, "tabScale"
                )
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(t) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        t.icon,
                        contentDescription = t.title,
                        tint = if (selected) t.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .size(22.dp)
                            .then(
                                Modifier
                            )
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        t.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) t.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
