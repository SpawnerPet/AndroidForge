package com.kenzi.booster.core

/**
 * Danh mục gốc của các tweak nội bộ.
 * Mỗi tweak gồm lệnh áp dụng và lệnh hoàn tác (nếu có).
 * Các lệnh đều được chạy qua `su -c` (ROOT) hoặc shell của Shizuku (SHIZUKU).
 */
object TweakRegistry {

    private fun t(
        id: String,
        name: String,
        desc: String,
        cat: TweakCategory,
        risk: Risk = Risk.SAFE,
        access: Access = Access.BOTH,
        apply: String? = null,
        revert: String? = null,
        input: InputKind? = null,
        label: String? = null,
        hint: String? = null,
        note: String? = null
    ) = Tweak(id, name, desc, cat, risk, access, apply, revert, input, label, hint, false, note)

    val ALL: List<Tweak> = listOf(

        // ============ HIỆU NĂNG ============
        t(
            "perf.anim_05", "Animation mượt 0.5x",
            "Giảm tốc độ animation toàn hệ thống xuống 0.5 để phản hồi nhanh hơn.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.BOTH,
            apply = "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5",
            revert = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
        ),
        t(
            "perf.anim_10", "Animation chuẩn 1.0x",
            "Đưa toàn bộ animation về tốc độ mặc định của hệ thống.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.BOTH,
            apply = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
        ),
        t(
            "perf.anim_off", "Tắt hoàn toàn animation",
            "Cực nhanh nhưng giao diện mất chuyển động, có thể gây vẻ giật khi mở app.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.BOTH,
            apply = "settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0",
            revert = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
        ),
        t(
            "perf.anim_slow", "Slow motion 2.0x",
            "Hiệu ứng chuyển động chậm, hợp quay video màn hình.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.BOTH,
            apply = "settings put global window_animation_scale 2.0; settings put global transition_animation_scale 2.0; settings put global animator_duration_scale 2.0",
            revert = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
        ),
        t(
            "perf.hwui_gpu", "Ép vẽ bằng GPU",
            "Đổi renderer HWUI sang OpenGL/Skia để giảm tải CPU khi vẽ giao diện.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "setprop debug.hwui.renderer skiagl",
            revert = "setprop debug.hwui.renderer skiagl"
        ),
        t(
            "perf.hwui_cpu", "Tăng ngân sách CPU cho giao diện",
            "Cho phép tầng giao diện dùng nhiều CPU hơn, mượt hơn nhưng tốn pin.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "setprop debug.hwui.target_cpu_time_percent 200",
            revert = "setprop debug.hwui.target_cpu_time_percent 50"
        ),
        t(
            "perf.heap_size", "Tăng bộ nhớ heap cho app",
            "Cho phép app dùng heap lớn hơn, giảm khả năng bị OOM khi mở nhiều tab.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "setprop dalvik.vm.heapgrowthlimit 512m; setprop dalvik.vm.heapsize 1024m",
            revert = "setprop dalvik.vm.heapgrowthlimit 256m; setprop dalvik.vm.heapsize 512m",
            note = "Cần khởi động lại để có hiệu lực."
        ),
        t(
            "perf.heap_start", "Heap khởi tạo lớn hơn",
            "Giảm số lần cấp phát bộ nhớ, hỗ trợ app nặng.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.ROOT,
            apply = "setprop dalvik.vm.heapstartsize 16m",
            revert = "setprop dalvik.vm.heapstartsize 8m"
        ),
        t(
            "perf.swappiness", "Tối ưu swap",
            "Giảm xu hướng swap trang bộ nhớ để ứng dụng chạy nhanh hơn.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "sysctl -w vm.swappiness 60",
            revert = "sysctl -w vm.swappiness 100"
        ),
        t(
            "perf.compact", "Bật nén bộ nhớ chủ động",
            "Cho phép hệ thống nén bộ nhớ để giảm RAM thực.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "echo 1 > /sys/vm/compaction/proact 2>/dev/null || true",
            revert = "echo 0 > /sys/vm/compaction/proact 2>/dev/null || true"
        ),
        t(
            "perf.drop_caches", "Giải phóng cache RAM",
            "Đẩy dữ liệu cache ra đĩa, RAM trống ngay. Sẽ chậm trong vài giây.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "sync; echo 3 > /proc/sys/vm/drop_caches",
            revert = "echo 1 > /proc/sys/vm/drop_caches"
        ),
        t(
            "perf.zram", "Tối ưu thuật toán zram",
            "Đổi thuật toán nén zram sang zstd, giảm I/O và nhiệt.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "echo zstd > /sys/module/zram/parameters/comp_algorithm 2>/dev/null || echo lz4 > /sys/module/zram/parameters/comp_algorithm",
            revert = "echo lz4 > /sys/module/zram/parameters/comp_algorithm 2>/dev/null || true"
        ),
        t(
            "perf.dex2oat", "Biên dịch app nền",
            "Chạy dex2oat cho toàn bộ app để mở app nhanh hơn, tốn pin lúc chạy.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "cmd package bg-dexopt-job",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "perf.dex_filter", "Bỏ kiểm tra dex",
            "Tắt bước xác minh dex giúp cài app nhanh hơn, giảm rủi ro bảo mật.",
            TweakCategory.PERFORMANCE, Risk.DANGER, Access.ROOT,
            apply = "setprop dalvik.vm.dex2oat-filter-mode verify",
            revert = "setprop dalvik.vm.dex2oat-filter-mode none"
        ),
        t(
            "perf.lmk_adj", "Nới lmk_adj",
            "Giảm khả năng hệ thống tự giết app nền, giữ nhiều app hơn trong RAM.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "setprop persist.sys.lmk_tuning.level 900 2>/dev/null || true",
            revert = "setprop persist.sys.lmk_tuning.level 0 2>/dev/null || true"
        ),
        t(
            "perf.gov_performance", "CPU governor: Performance",
            "Ép CPU chạy ở xung nhịp cao nhất. Mượt hơn nhưng nóng và tụt pin.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.ROOT,
            apply = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > \$f 2>/dev/null; done",
            revert = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > \$f 2>/dev/null; done"
        ),
        t(
            "perf.gov_schedutil", "CPU governor: Schedutil",
            "Cân bằng giữa hiệu năng và thời lượng pin.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.ROOT,
            apply = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > \$f 2>/dev/null; done",
            revert = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo powersave > \$f 2>/dev/null; done"
        ),
        t(
            "perf.gov_powersave", "CPU governor: Powersave",
            "Tiết kiệm pin tối đa, máy sẽ nguội hơn nhưng chậm hơn.",
            TweakCategory.PERFORMANCE, Risk.SAFE, Access.ROOT,
            apply = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo powersave > \$f 2>/dev/null; done",
            revert = "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > \$f 2>/dev/null; done"
        ),
        t(
            "perf.bg_service", "Kéo dài thời gian chạy nền",
            "Cho phép service nền sống lâu hơn, ít bị hệ thống dọn.",
            TweakCategory.PERFORMANCE, Risk.CAUTION, Access.BOTH,
            apply = "device_config put activity_manager bg_service_empty_timeout 60000",
            revert = "device_config delete activity_manager bg_service_empty_timeout"
        ),
        t(
            "perf.logd_off", "Tắt dịch vụ logd",
            "Tắt ghi log hệ thống, giảm I/O. Rất khó gỡ lỗi khi xảy ra sự cố.",
            TweakCategory.PERFORMANCE, Risk.DANGER, Access.ROOT,
            apply = "stop logd; setprop persist.logd.logpersistd.enable false",
            revert = "start logd; setprop persist.logd.logpersistd.enable true"
        ),
        t(
            "perf.lowmem_kill", "Nới lowmemory_kill",
            "Cho phép hệ thống giết nhiều app hơn khi thiếu RAM. Có thể làm app bị tắt đột ngột.",
            TweakCategory.PERFORMANCE, Risk.DANGER, Access.ROOT,
            apply = "echo 1200 > /sys/module/lowmemory_kill/parameters/adj 2>/dev/null || true",
            revert = "echo 1000 > /sys/module/lowmemory_kill/parameters/adj 2>/dev/null || true"
        ),

        // ============ HỆ THỐNG ============
        t(
            "sys.wifi_off", "Tắt Wi-Fi",
            "Tắt hoàn toàn adapter Wi-Fi để tiết kiệm pin.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "svc wifi disable",
            revert = "svc wifi enable"
        ),
        t(
            "sys.bt_off", "Tắt Bluetooth",
            "Tắt Bluetooth, tiết kiệm pin khi không dùng.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "svc bluetooth disable",
            revert = "svc bluetooth enable"
        ),
        t(
            "sys.data_off", "Tắt dữ liệu di động",
            "Không còn mạng di động. Chỉ dùng khi cần tiết kiệm tuyệt đối.",
            TweakCategory.SYSTEM, Risk.DANGER, Access.BOTH,
            apply = "svc data disable",
            revert = "svc data enable"
        ),
        t(
            "sys.nfc_off", "Tắt NFC",
            "Tắt mạch NFC, không dùng được thanh toán/chạm.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "svc nfc disable",
            revert = "svc nfc enable"
        ),
        t(
            "sys.location_off", "Tắt định vị",
            "Tắt toàn bộ định vị. Các app bản đồ, GPS sẽ không hoạt động.",
            TweakCategory.SYSTEM, Risk.DANGER, Access.BOTH,
            apply = "settings put secure location_mode 0; svc location disable",
            revert = "settings put secure location_mode 3; svc location enable"
        ),
        t(
            "sys.print_off", "Tắt dịch vụ in",
            "Tắt Print Spooler, tiết kiệm tài nguyên nền.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "svc print disable",
            revert = "svc print enable"
        ),
        t(
            "sys.adb_off", "Tắt ADB",
            "Tắt giao diện gỡ lỗi USB. Cần bật lại qua cài đặt nhà phát triển nếu cần.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "settings put global adb_enabled 0",
            revert = "settings put global adb_enabled 1"
        ),
        t(
            "sys.adb_tcp", "ADB qua Wi-Fi (cổng 5555)",
            "Mở cổng ADB 5555. Rất nguy hiểm nếu mạng không an toàn.",
            TweakCategory.SYSTEM, Risk.DANGER, Access.ROOT,
            apply = "setprop service.adb.tcp.port 5555; stop adbd; start adbd",
            revert = "setprop service.adb.tcp.port -1; stop adbd; start adbd"
        ),
        t(
            "sys.dark_mode", "Bật chế độ tối",
            "Chuyển hệ thống sang giao diện tối.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "cmd uimode night yes",
            revert = "cmd uimode night no"
        ),
        t(
            "sys.light_mode", "Bật chế độ sáng",
            "Chuyển hệ thống sang giao diện sáng.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "cmd uimode night no",
            revert = "cmd uimode night yes"
        ),
        t(
            "sys.font_scale", "Tăng cỡ chữ 1.15x",
            "Chữ lớn hơn, dễ đọc hơn.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put system font_scale 1.15",
            revert = "settings put system font_scale 1.0"
        ),
        t(
            "sys.density_420", "Đặt mật độ màn hình 420",
            "Ép dpi màn hình, giao diện gọn hơn trên màn hình lớn.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "wm density 420",
            revert = "wm density reset"
        ),
        t(
            "sys.immersive", "Ẩn thanh điều hướng",
            "Ẩn thanh điều hướng để có thêm không gian. Vuốt từ cạnh để hiện lại.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "settings put global policy_control immersive.navigation=*",
            revert = "settings put global policy_control null"
        ),
        t(
            "sys.sysui_dark", "Ép SystemUI nền tối",
            "Giao diện hệ thống luôn dùng bảng màu tối.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "cmd overlay enable-exclusive com.android.systemui.theme.dark",
            revert = "cmd overlay disable-exclusive com.android.systemui.theme.dark"
        ),
        t(
            "sys.headset_mic", "Chọn mic tai nghe",
            "Ép dùng mic có dây thay vì mic ngoài.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put secure headset_mic analog",
            revert = "settings put secure headset_mic default"
        ),
        t(
            "sys.autofill_off", "Tắt tự động điền",
            "Không gợi ý mật khẩu/thẻ khi gõ.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put secure autofill_service \"\"",
            revert = "settings put secure autofill_service com.google.android.marvin.talkback"
        ),
        t(
            "sys.screen_off_10m", "Tắt màn hình sau 10 phút",
            "Tăng thời gian chờ tắt màn hình, tiết kiệm thao tác mở khóa.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put system screen_off_timeout 600000",
            revert = "settings put system screen_off_timeout 30000"
        ),
        t(
            "sys.finish_activities", "Đóng app ngay khi thoát",
            "Giảm số app tồn đọng trong bộ nhớ, nhưng vào app lại chậm hơn.",
            TweakCategory.SYSTEM, Risk.CAUTION, Access.BOTH,
            apply = "settings put global always_finish_activities 1",
            revert = "settings put global always_finish_activities 0"
        ),
        t(
            "sys.hide_errors", "Ẩn hộp thoại lỗi",
            "Không hiện popup lỗi của hệ thống, giao diện gọn hơn.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put secure hide_error_dialogs 1",
            revert = "settings put secure hide_error_dialogs 0"
        ),
        t(
            "sys.pkg_freeze", "Đóng băng app không dùng",
            "Vô hiệu hoá các app không cần thiết để tiết kiệm tài nguyên.",
            TweakCategory.SYSTEM, Risk.DANGER, Access.BOTH,
            apply = "pm disable-user --user 0 com.google.android.apps.messaging",
            revert = "pm enable --user 0 com.google.android.apps.messaging"
        ),
        t(
            "sys.app_dev_settings", "Mở cài đặt nhà phát triển",
            "Mở nhanh màn hình cài đặt nhà phát triển để bật ADB.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS",
            revert = "am start -a android.settings.SETTINGS"
        ),
        t(
            "sys.reset_anim_def", "Khôi phục animation gốc",
            "Đưa toàn bộ thông số animation về mặc định 1.0.",
            TweakCategory.SYSTEM, Risk.SAFE, Access.BOTH,
            apply = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0",
            revert = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0"
        ),

        // ============ HIỂN THỊ ============
        t(
            "disp.max_brightness", "Sáng tối đa",
            "Đặt độ sáng màn hình ở mức tối đa (ngoài giới hạn cảm biến ánh sáng).",
            TweakCategory.DISPLAY, Risk.CAUTION, Access.BOTH,
            apply = "settings put system screen_brightness_mode 0; settings put system screen_brightness 255",
            revert = "settings put system screen_brightness_mode 1"
        ),
        t(
            "disp.min_brightness", "Tối gần như tắt",
            "Độ sáng gần như 0 để dùng khi lái xe ban đêm.",
            TweakCategory.DISPLAY, Risk.DANGER, Access.BOTH,
            apply = "settings put system screen_brightness_mode 0; settings put system screen_brightness 1",
            revert = "settings put system screen_brightness_mode 1"
        ),
        t(
            "disp.haptic_off", "Tắt rung phản hồi",
            "Tắt haptic khi chạm, giao diện phản hồi nhanh hơn.",
            TweakCategory.DISPLAY, Risk.SAFE, Access.BOTH,
            apply = "settings put system haptic_feedback_enabled 0",
            revert = "settings put system haptic_feedback_enabled 1"
        ),
        t(
            "disp.vibrate_ring_off", "Tắt rung khi có cuộc gọi",
            "Không rung khi có cuộc gọi đến.",
            TweakCategory.DISPLAY, Risk.SAFE, Access.BOTH,
            apply = "settings put system vibrate_when_ringing 0",
            revert = "settings put system vibrate_when_ringing 1"
        ),
        t(
            "disp.refresh_120", "Ép tần số quét 120Hz",
            "Buộc màn hình luôn chạy ở 120Hz nếu máy hỗ trợ. Tốn pin hơn.",
            TweakCategory.DISPLAY, Risk.CAUTION, Access.BOTH,
            apply = "settings put system peak_refresh_rate 120.0; settings put system min_refresh_rate 120.0",
            revert = "settings put system peak_refresh_rate 0.0; settings put system min_refresh_rate 0.0",
            note = "Chỉ có tác dụng nếu màn hình hỗ trợ 120Hz."
        ),
        t(
            "disp.daltonizer_off", "Tắt bộ lọc màu",
            "Tắt chế độ dành cho người mù màu, màu sẽ chuẩn hơn.",
            TweakCategory.DISPLAY, Risk.SAFE, Access.BOTH,
            apply = "settings put secure daltonizer_enabled 0; settings put secure accessibility_daltonizer_enabled 0",
            revert = "settings put secure daltonizer_enabled 1"
        ),
        t(
            "disp.screen_off_min", "Tắt màn hình sau 15 giây",
            "Tiết kiệm pin tối đa khi để máy ngoài.",
            TweakCategory.DISPLAY, Risk.SAFE, Access.BOTH,
            apply = "settings put system screen_off_timeout 15000",
            revert = "settings put system screen_off_timeout 30000"
        ),
        t(
            "disp.brightness_auto_off", "Tắt tự động cảm biến sáng",
            "Độ sáng không tự thay đổi theo môi trường nữa.",
            TweakCategory.DISPLAY, Risk.CAUTION, Access.BOTH,
            apply = "settings put system screen_brightness_mode 0",
            revert = "settings put system screen_brightness_mode 1"
        ),
        t(
            "disp.force_ms_reflect", "Bật reflection hiệu ứng nước",
            "Hiệu ứng phản chiếu mới trên Android 12+, một số máy sẽ lag nhẹ.",
            TweakCategory.DISPLAY, Risk.CAUTION, Access.ROOT,
            apply = "settings put global enable_display_cutout_protection 1; setprop debug.sf.enable_systrace 0",
            revert = "settings put global enable_display_cutout_protection 0"
        ),

        // ============ MẠNG ============
        t(
            "net.doh_cloudflare", "DNS bảo mật Cloudflare",
            "Dùng DoH của Cloudflare qua Private DNS, chặn DNS lợi dụng.",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "settings put global private_dns_mode hostname; settings put global private_dns_specifier cloudflare-dns.com",
            revert = "settings put global private_dns_mode off"
        ),
        t(
            "net.doh_google", "DNS bảo mật Google",
            "Dùng Private DNS của Google (dns.google).",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "settings put global private_dns_mode hostname; settings put global private_dns_specifier dns.google",
            revert = "settings put global private_dns_mode off"
        ),
        t(
            "net.dns_off", "Tắt Private DNS",
            "Dùng DNS mặc định của nhà mạng. Nhanh hơn nhưng dễ bị chặn quảng cáo.",
            TweakCategory.NETWORK, Risk.CAUTION, Access.BOTH,
            apply = "settings put global private_dns_mode off",
            revert = "settings put global private_dns_mode hostname"
        ),
        t(
            "net.wifi_scan_slow", "Giảm tần quét Wi-Fi",
            "WIFI_SCAN_INTERVAL 5 phút, giảm hao pin do quét kênh.",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "settings put global wifi_scan_interval 300000",
            revert = "settings put global wifi_scan_interval 240000"
        ),
        t(
            "net.wifi_powersave_off", "Tắt tiết kiệm pin Wi-Fi",
            "Giữ kết nối ổn định, hạn chế độ rớt kết nối.",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "settings put global wifi_power_save 0",
            revert = "settings put global wifi_power_save 1"
        ),
        t(
            "net.tcp_fastopen", "Bật TCP Fast Open",
            "Rút ngắn thời gian bắt tay TCP, tải web nhanh hơn.",
            TweakCategory.NETWORK, Risk.CAUTION, Access.ROOT,
            apply = "sysctl -w net.ipv4.tcp_fastopen 3; sysctl -w net.ipv6.tcp_fastopen 3",
            revert = "sysctl -w net.ipv4.tcp_fastopen 1; sysctl -w net.ipv6.tcp_fastopen 1"
        ),
        t(
            "net.rmem_max", "Tăng bộ đệm mạng",
            "Tăng bộ đệm TCP, hữu ích khi tải/nhận dữ liệu lớn.",
            TweakCategory.NETWORK, Risk.CAUTION, Access.ROOT,
            apply = "sysctl -w net.core.rmem_max 16777216; sysctl -w net.core.wmem_max 16777216",
            revert = "sysctl -w net.core.rmem_max 212992; sysctl -w net.core.wmem_max 212992"
        ),
        t(
            "net.netpolicy", "Khởi động dịch vụ quản lý mạng",
            "Nạp lại netpolicy để áp dụng cấu hình mạng mới.",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "cmd netpolicy reload",
            revert = "cmd netpolicy list"
        ),
        t(
            "net.wifi_toggle_5g", "Ưu tiên băng tần 5GHz",
            "Ưu tiên kết nối 5GHz khi router hỗ trợ.",
            TweakCategory.NETWORK, Risk.CAUTION, Access.ROOT,
            apply = "cmd wifi set-wifi-enabled enabled 2>/dev/null || svc wifi enable",
            revert = "svc wifi enable"
        ),
        t(
            "net.data_saver", "Bật tiết kiệm dữ liệu",
            "Hạn chế dữ liệu nền của các app.",
            TweakCategory.NETWORK, Risk.SAFE, Access.BOTH,
            apply = "cmd netpolicy set restrict-background true",
            revert = "cmd netpolicy set restrict-background false"
        ),

        // ============ ÂM THANH ============
        t(
            "aud.vol_boost", "Tăng âm lượng tối đa",
            "Đẩy âm lượng media lên mức tối đa (có thể gây rách âm).",
            TweakCategory.AUDIO, Risk.CAUTION, Access.BOTH,
            apply = "cmd media_session volume --stream 3 --set 15",
            revert = "cmd media_session volume --stream 3 --set 7"
        ),
        t(
            "aud.vol_normal", "Âm lượng về mặc định",
            "Đưa âm lượng media về mức chuẩn 7/15.",
            TweakCategory.AUDIO, Risk.SAFE, Access.BOTH,
            apply = "cmd media_session volume --stream 3 --set 7",
            revert = "cmd media_session volume --stream 3 --set 7"
        ),
        t(
            "aud.dnd_on", "Bật chế độ không làm phiền",
            "Tắt thông báo và chuông, chỉ giữ cuộc gọi quan trọng.",
            TweakCategory.AUDIO, Risk.SAFE, Access.BOTH,
            apply = "cmd notification set_dnd on",
            revert = "cmd notification set_dnd off"
        ),
        t(
            "aud.spatial", "Bật âm thanh không gian",
            "Kích hoạt hiệu ứng âm thanh không gian nếu thiết bị hỗ trợ.",
            TweakCategory.AUDIO, Risk.SAFE, Access.BOTH,
            apply = "settings put global enable_spatial 1",
            revert = "settings put global enable_spatial 0"
        ),
        t(
            "aud.mic_noise", "Giảm nhiễu mic",
            "Bật chế độ khử nhiễu khi gọi điện.",
            TweakCategory.AUDIO, Risk.SAFE, Access.BOTH,
            apply = "settings put secure noise_suppression 1",
            revert = "settings put secure noise_suppression 0"
        ),
        t(
            "aud.alarm_max", "Âm lượng báo thức tối đa",
            "Đặt âm lượng báo thức ở mức cao nhất.",
            TweakCategory.AUDIO, Risk.SAFE, Access.BOTH,
            apply = "cmd media_session volume --stream 4 --set 15",
            revert = "cmd media_session volume --stream 4 --set 6"
        ),

        // ============ PIN & NHIỆT ============
        t(
            "bat.charge_limit_80", "Giới hạn sạc 80%",
            "Giữ pin ở 80% để kéo dài tuổi thọ pin. Chỉ máy hỗ trợ mới có tác dụng.",
            TweakCategory.BATTERY, Risk.CAUTION, Access.ROOT,
            apply = "echo 80 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true",
            revert = "echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true",
            note = "Cần kernel hỗ trợ charge_control_end_threshold."
        ),
        t(
            "bat.charge_limit_70", "Giới hạn sạc 70%",
            "Giữ pin ở 70%, tối đa tuổi thọ pin.",
            TweakCategory.BATTERY, Risk.CAUTION, Access.ROOT,
            apply = "echo 70 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true",
            revert = "echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true"
        ),
        t(
            "bat.charge_full", "Sạc đầy 100%",
            "Gỡ giới hạn sạc, cho phép sạc đầy.",
            TweakCategory.BATTERY, Risk.SAFE, Access.ROOT,
            apply = "echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true",
            revert = "echo 100 > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null || true"
        ),
        t(
            "bat.thermal_override", "Bỏ qua cảnh báo nhiệt",
            "Buộc hệ thống coi như máy luôn mát. CỰC KỲ NGUY HIỂM, có thể cháy máy.",
            TweakCategory.BATTERY, Risk.DANGER, Access.BOTH,
            apply = "dumpsys thermalservice override-status 0",
            revert = "dumpsys thermalservice reset"
        ),
        t(
            "bat.thermal_verbose", "Ghi log nhiệt độ chi tiết",
            "Bật log nhiệt độ để theo dõi nhiệt.",
            TweakCategory.BATTERY, Risk.SAFE, Access.ROOT,
            apply = "setprop persist.sys.thermal.enable 1; setprop persist.vendor.thermal.verbose 1",
            revert = "setprop persist.sys.thermal.enable 0"
        ),
        t(
            "bat.charge_current_max", "Tăng dòng sạc tối đa",
            "Ghi đè giới hạn dòng sạc. Nguy hiểm với pin và mạch sạc.",
            TweakCategory.BATTERY, Risk.DANGER, Access.ROOT,
            apply = "echo 2000000 > /sys/class/power_supply/battery/charge_control_max_current 2>/dev/null || true",
            revert = "echo 0 > /sys/class/power_supply/battery/charge_control_max_current 2>/dev/null || true"
        ),
        t(
            "bat.gc_frozen", "Tạm dừng GC khi app nền",
            "Cho phép app bị đóng băng để giảm nhiệt, có thể gây treo app.",
            TweakCategory.BATTERY, Risk.DANGER, Access.ROOT,
            apply = "setprop dalvik.vm.frozen 1 2>/dev/null || true",
            revert = "setprop dalvik.vm.frozen 0 2>/dev/null || true"
        ),
        t(
            "bat.idle_brightness", "Giảm sáng khi màn hình tắt",
            "Hạ độ sáng nền trong lúc chờ để tiết kiệm pin.",
            TweakCategory.BATTERY, Risk.SAFE, Access.BOTH,
            apply = "settings put system screen_brightness_mode 0; settings put system screen_brightness 26",
            revert = "settings put system screen_brightness_mode 1"
        ),

        // ============ RIÊNG TƯ & BẢO MẬT ============
        t(
            "sec.usage_stats", "Tắt theo dõi sử dụng",
            "Từ chối quyền theo dõi sử dụng để bảo vệ dữ liệu cá nhân.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "cmd appops set com.google.android.apps.nexuslauncher GET_USAGE_STATS ignore 2>/dev/null || true",
            revert = "cmd appops set com.google.android.apps.nexuslauncher GET_USAGE_STATS default 2>/dev/null || true"
        ),
        t(
            "sec.feedback_off", "Tắt báo lỗi người dùng",
            "Vô hiệu hoá module phản hồi lỗi của Google.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "pm disable-user --user 0 com.google.android.feedback",
            revert = "pm enable --user 0 com.google.android.feedback"
        ),
        t(
            "sec.ad_id", "Tắt quảng cáo cá nhân",
            "Yêu cầu hệ thống tắt ID quảng cáo nếu thiết bị hỗ trợ.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "settings put global limit_ad_tracking 1 2>/dev/null || true",
            revert = "settings put global limit_ad_tracking 0 2>/dev/null || true"
        ),
        t(
        "sec.screenshot", "Chặn chụp màn hình",
            "Cấm chụp/screenrecord màn hình trên toàn hệ thống.",
            TweakCategory.PRIVACY, Risk.CAUTION, Access.BOTH,
            apply = "settings put secure screenshot_disabled 1 2>/dev/null || true",
            revert = "settings put secure screenshot_disabled 0 2>/dev/null || true"
        ),
        t(
            "sec.appop_bg", "Chặn app chạy nền",
            "Cấm các app chạy nền để tăng riêng tư và tiết kiệm pin.",
            TweakCategory.PRIVACY, Risk.CAUTION, Access.BOTH,
            apply = "cmd appops set RUN_IN_BACKGROUND ignore 2>/dev/null || cmd appops set RUN_IN_BACKGROUND reject 2>/dev/null || true",
            revert = "cmd appops set RUN_IN_BACKGROUND default 2>/dev/null || true"
        ),
        t(
            "sec.deviceidle_whitelist", "Thêm vào danh sách miễn nhiễm",
            "Cho phép app thường dùng không bị Doze giết.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "dumpsys deviceidle whitelist +com.zenmate.app 2>/dev/null || true",
            revert = "dumpsys deviceidle whitelist -com.zenmate.app 2>/dev/null || true"
        ),
        t(
            "sec.clear_app_cache", "Dọn cache toàn hệ thống",
            "Xoá cache của mọi app, giải phóng dung lượng.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "pm trim-caches 999999999999",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "sec.hide_content", "Ẩn nội dung thông báo",
            "Không hiển thị nội dung thông báo trên màn hình khoá.",
            TweakCategory.PRIVACY, Risk.SAFE, Access.BOTH,
            apply = "settings put secure lock_screen_allow_private_notifications 0",
            revert = "settings put secure lock_screen_allow_private_notifications 1"
        ),

        // ============ DỌN DẸP ============
        t(
            "cln.cache", "Dọn cache app",
            "Dọn cache toàn bộ ứng dụng đã cài.",
            TweakCategory.CLEANUP, Risk.SAFE, Access.BOTH,
            apply = "pm trim-caches 999999999999",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.logs", "Xoá log hệ thống",
            "Xoá file log và dropbox để giải phóng dung lượng.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.ROOT,
            apply = "rm -rf /data/log/* /data/system/dropbox/* /data/anr/* 2>/dev/null || true",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.temp", "Dọn thư mục tạm",
            "Xoá file tạm trong /data/local/tmp.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.ROOT,
            apply = "rm -rf /data/local/tmp/* 2>/dev/null || true",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.kill_bg", "Giết toàn bộ app nền",
            "Dừng tất cả app chạy nền ngay lập tức, RAM trống tức thì.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.BOTH,
            apply = "am kill-all",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.gfx_reset", "Reset đồ hoạ SurfaceFlinger",
            "Xoá bộ nhớ đệm GPU, sửa lỗi vỡ hình/kéo thả app.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.ROOT,
            apply = "dumpsys SurfaceFlinger --latency-clear 2>/dev/null || service call SurfaceFlinger 1013",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.rebuild_dex", "Biên dịch lại toàn bộ dex",
            "Tối ưu lại bytecode cho app, mở nhanh hơn nhưng mất thời gian và pin.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.ROOT,
            apply = "cmd package compile -m speed -f -a",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "cln.reset_dex", "Reset dex tối ưu",
            "Xoá dex tối ưu, app phải biên dịch lại. Có thể làm app chậm lúc đầu.",
            TweakCategory.CLEANUP, Risk.DANGER, Access.ROOT,
            apply = "cmd package compile --reset",
            revert = "cmd package compile -m speed -a"
        ),
        t(
            "cln.meminfo", "Xuất báo cáo bộ nhớ",
            "Ghi log bộ nhớ hệ thống vào logcat để phân tích.",
            TweakCategory.CLEANUP, Risk.SAFE, Access.ROOT,
            apply = "dumpsys meminfo > /data/local/tmp/kenzi_meminfo.txt 2>/dev/null || true",
            revert = "rm -f /data/local/tmp/kenzi_meminfo.txt"
        ),
        t(
            "cln.dalvik_cleanup", "Dọn cache Dalvik",
            "Xoá cache biên dịch Dalvik, giải phóng dung lượng.",
            TweakCategory.CLEANUP, Risk.CAUTION, Access.ROOT,
            apply = "rm -rf /data/dalvik-cache/* 2>/dev/null || true",
            revert = "echo \"\" > /dev/null"
        ),

        // ============ NÂNG CAO / NGUY HIỂM ============
        t(
            "adv.sysui_restart", "Khởi động lại SystemUI",
            "Tắt và mở lại SystemUI để sửa giao diện bị lỗi. Màn hình chớp vài giây.",
            TweakCategory.ADVANCED, Risk.CAUTION, Access.ROOT,
            apply = "am force-stop com.android.systemui; sleep 1; am start -n com.android.systemui/.SystemUIService 2>/dev/null || true",
            revert = "am force-stop com.android.systemui; sleep 1; am start -n com.android.systemui/.SystemUIService 2>/dev/null || true"
        ),
        t(
            "adv.launcher_restart", "Khởi động lại launcher",
            "Khởi động lại màn hình chính, sửa lỗi treo launcher.",
            TweakCategory.ADVANCED, Risk.CAUTION, Access.ROOT,
            apply = "am force-stop com.google.android.apps.nexuslauncher 2>/dev/null || true",
            revert = "am start -a android.intent.action.MAIN -c android.intent.category.HOME"
        ),
        t(
            "adv.disable_app", "Tắt app bất kỳ (nhập package)",
            "Nhập tên package để vô hiệu hoá app, ví dụ com.facebook.ganesa.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.BOTH,
            apply = "pm disable-user --user 0 {pkg}",
            revert = "pm enable --user 0 {pkg}",
            input = InputKind.PACKAGE,
            label = "Nhập package name",
            hint = "Ví dụ: com.facebook.ganesa"
        ),
        t(
            "adv.sysprop", "Đặt system property (nhập key=value)",
            "Ghi đè thuộc tính hệ thống. Sai key có thể gây lỗi hệ thống.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.ROOT,
            apply = "setprop {key}",
            revert = "echo \"\" > /dev/null",
            input = InputKind.SYSPROP,
            label = "Nhập key=value",
            hint = "Ví dụ: ro.debuggable=1"
        ),
        t(
            "adv.raw_shell", "Chạy lệnh shell tuỳ ý",
            "Chạy bất kỳ lệnh nào với quyền root. Cực kỳ nguy hiểm.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.ROOT,
            apply = "{cmd}",
            revert = "echo \"\" > /dev/null",
            input = InputKind.RAW,
            label = "Nhập lệnh shell",
            hint = "Ví dụ: pm list packages -3"
        ),
        t(
            "adv.fake_battery", "Giả lập mức pin",
            "Giả mức pin trong hệ thống, hữu ích khi test app.",
            TweakCategory.ADVANCED, Risk.CAUTION, Access.BOTH,
            apply = "dumpsys battery set level 50; dumpsys battery set status 2",
            revert = "dumpsys battery reset"
        ),
        t(
            "adv.disable_ota", "Tắt kiểm tra cập nhật OTA",
            "Vô hiệu hoá trình cập nhật hệ thống qua mạng.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.BOTH,
            apply = "for p in com.google.android.gms com.android.systemupdater com.android.carrierconfig; do pm disable-user --user 0 \$p 2>/dev/null; done; true",
            revert = "for p in com.google.android.gms com.android.systemupdater com.android.carrierconfig; do pm enable --user 0 \$p 2>/dev/null; done; true"
        ),
        t(
            "adv.ota_stop", "Dừng dịch vụ cập nhật",
            "Tắt updater đang chạy mà không vô hiệu hoá gói cài đặt.",
            TweakCategory.ADVANCED, Risk.CAUTION, Access.ROOT,
            apply = "pkill -f updater 2>/dev/null; pkill -f com.google.android.gms.unstable 2>/dev/null; true",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "adv.reboot", "Khởi động lại máy",
            "Reboot ngay lập tức để áp dụng các thay đổi sâu.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.ROOT,
            apply = "svc power reboot || reboot",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "adv.reboot_recovery", "Khởi động lại vào Recovery",
            "Vào chế độ recovery. Chỉ dùng khi bạn biết chắc mình đang làm gì.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.ROOT,
            apply = "svc power reboot recovery || reboot recovery",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "adv.reboot_bootloader", "Khởi động lại bootloader",
            "Vào bootloader/fastboot. Rất dễ làm brick máy nếu sai thao tác.",
            TweakCategory.ADVANCED, Risk.DANGER, Access.ROOT,
            apply = "svc power reboot bootloader || reboot bootloader",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "adv.gps_reset", "Reset cấu hình GPS",
            "Xoá dữ liệu vị trí đã lưu định vị chính xác hơn.",
            TweakCategory.ADVANCED, Risk.SAFE, Access.BOTH,
            apply = "pm clear com.android.location.fused 2>/dev/null || true",
            revert = "echo \"\" > /dev/null"
        ),
        t(
            "adv.restore_defaults", "Khôi phục mặc định nhà máy",
            "Tắt toàn bộ tweak đang bật và hoàn tác các thay đổi.",
            TweakCategory.ADVANCED, Risk.CAUTION, Access.BOTH,
            apply = "__RESTORE_ALL__",
            revert = "echo \"\" > /dev/null"
        )
    )

    val byId: Map<String, Tweak> = ALL.associateBy { it.id }
}
