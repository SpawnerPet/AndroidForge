package com.kenzi.booster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kenzi.booster.core.UpdateManager
import com.kenzi.booster.ui.components.GlassButton
import com.kenzi.booster.ui.components.GlassButtonRow
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.components.InfoRow
import com.kenzi.booster.ui.components.SectionHeader
import com.kenzi.booster.ui.theme.KenZiPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    darkTheme: Boolean,
    animatedBackground: Boolean,
    update: UpdateManager.UpdateState,
    updateUrl: String,
    appVersion: String,
    versionCode: Int,
    enabledCount: Int,
    lastCheck: Long,
    onToggleDark: (Boolean) -> Unit,
    onToggleAnimated: (Boolean) -> Unit,
    onSaveUpdateUrl: (String) -> Unit,
    onCheckUpdate: () -> Unit,
    onDownloadUpdate: () -> Unit,
    onRestoreDefaults: () -> Unit
) {
    var urlDraft by remember(updateUrl) { mutableStateOf(updateUrl) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassSurface(shape = RoundedCornerShape(28.dp), tintAlpha = 0.13f) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        "Cài đặt",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Giao diện, cập nhật và bảo trì hệ thống",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item { SectionHeader("Giao diện") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SettingSwitch(
                        icon = Icons.Filled.DarkMode,
                        title = "Chế độ tối",
                        subtitle = "Nền tối giúp nhẹ mắt và tiết kiệm pin",
                        checked = darkTheme,
                        accent = KenZiPalette.Violet,
                        onCheckedChange = onToggleDark
                    )
                    Spacer(Modifier.height(12.dp))
                    SettingSwitch(
                        icon = Icons.Filled.Bolt,
                        title = "Nền chuyển màu động",
                        subtitle = "Nền tự chuyển màu tự nhiên qua 4 màu chủ đạo",
                        checked = animatedBackground,
                        accent = KenZiPalette.Aqua,
                        onCheckedChange = onToggleAnimated
                    )
                }
            }
        }

        item { SectionHeader("Cập nhật tự động") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Kiểm tra bản cập nhật và tải thêm tính năng mới (nhẹ và nguy hiểm) từ máy chủ.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = urlDraft,
                        onValueChange = { urlDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("URL manifest cập nhật") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    GlassButtonRow {
                        GlassButton(
                            text = if (update.checking) "Đang kiểm tra..." else "Kiểm tra cập nhật",
                            accent = KenZiPalette.Sky,
                            modifier = Modifier.weight(1f)
                        ) { onCheckUpdate() }
                        GlassButton(
                            text = "Lưu URL",
                            accent = KenZiPalette.Violet,
                            modifier = Modifier.weight(1f)
                        ) { onSaveUpdateUrl(urlDraft) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (update.checking || update.downloading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = KenZiPalette.Aqua
                            )
                            Spacer(Modifier.width(10.dp))
                        }
                        Text(
                            update.message ?: "Chưa kiểm tra cập nhật",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (update.updateAvailable) {
                        Spacer(Modifier.height(12.dp))
                        GlassButton(
                            text = if (update.downloading) "Đang tải..." else "Tải & cài bản cập nhật",
                            accent = KenZiPalette.Aqua,
                            modifier = Modifier.fillMaxWidth()
                        ) { onDownloadUpdate() }
                    }
                    Spacer(Modifier.height(10.dp))
                    InfoRow("Tính năng từ xa", "${update.remoteTweakCount} mục")
                    InfoRow(
                        "Lần kiểm tra cuối",
                        if (lastCheck > 0)
                            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(lastCheck))
                        else "Chưa có"
                    )
                }
            }
        }

        item { SectionHeader("Bảo trì") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.DeleteSweep, contentDescription = null,
                            tint = KenZiPalette.Ember, modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Khôi phục mặc định",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Hoàn tác toàn bộ tweak đang bật ($enabledCount mục)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    GlassButton(
                        text = "Khôi phục mặc định nhà máy",
                        accent = KenZiPalette.Ember,
                        modifier = Modifier.fillMaxWidth()
                    ) { onRestoreDefaults() }
                }
            }
        }

        item { SectionHeader("Thông tin ứng dụng & API") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Info, contentDescription = null,
                            tint = KenZiPalette.Aqua, modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                "KenZi Booster",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Made by KenZi (Tài bá khí)",
                                style = MaterialTheme.typography.labelMedium,
                                color = KenZiPalette.Aqua
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    InfoRow("Phiên bản", appVersion)
                    InfoRow("Version code", "$versionCode")
                    InfoRow("Package", "com.kenzi.booster")
                    InfoRow("API endpoint", "update.manifest")
                    InfoRow("Manifest", updateUrl)
                    InfoRow("Build type", "release")
                    InfoRow("Tính năng tổng", "${enabledCount} đang bật")
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Tất cả thay đổi do tweak thực hiện đều chạy với quyền hệ thống. " +
                                "Hãy dùng tính năng \"Khôi phục mặc định\" nếu gặp vấn đề.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSwitch(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(accent.copy(alpha = 0.14f))
                .border(1.dp, accent.copy(alpha = 0.32f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = accent,
                checkedTrackColor = accent.copy(alpha = 0.35f),
                checkedBorderColor = accent.copy(alpha = 0.8f),
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = Color.Transparent,
                uncheckedBorderColor = MaterialTheme.colorScheme.outline
            )
        )
    }
}
