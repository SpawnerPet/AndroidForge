package com.kenzi.booster.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.kenzi.booster.core.DeviceInfo
import com.kenzi.booster.ui.components.GlassButton
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.components.InfoRow
import com.kenzi.booster.ui.components.SectionHeader
import com.kenzi.booster.ui.components.StatTile
import com.kenzi.booster.ui.theme.KenZiPalette

@Composable
fun DeviceScreen(
    device: DeviceInfo?,
    onRefresh: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassSurface(shape = RoundedCornerShape(28.dp), tintAlpha = 0.13f) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        "Thông tin máy",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        device?.let { "${it.manufacturer} ${it.model}" } ?: "Đang đọc thông tin...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    GlassButton(
                        text = "Làm mới thông tin",
                        accent = KenZiPalette.Aqua,
                        modifier = Modifier.fillMaxWidth()
                    ) { onRefresh() }
                }
            }
        }

        if (device != null) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        "RAM đang dùng",
                        "${device.ramUsedPercent}%",
                        KenZiPalette.Aqua,
                        Modifier.weight(1f)
                    )
                    StatTile(
                        "Dung lượng đã dùng",
                        "${device.storageUsedPercent}%",
                        KenZiPalette.Sky,
                        Modifier.weight(1f)
                    )
                    StatTile(
                        "Pin",
                        "${device.batteryLevel}%",
                        KenZiPalette.Violet,
                        Modifier.weight(1f)
                    )
                }
            }

            item { SectionHeader("Phần cứng") }
            item {
                GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InfoRow("Thương hiệu", device.brand)
                        InfoRow("Model", device.model)
                        InfoRow("Mã thiết bị", device.device)
                        InfoRow("Nhà sản xuất", device.manufacturer)
                        InfoRow("Vi xử lý (SoC)", device.soc)
                        InfoRow("CPU", device.cpuInfo)
                        InfoRow("Số nhân CPU", "${device.cpuCores} nhân")
                        InfoRow("Kiến trúc", device.abi)
                        InfoRow("GPU", device.gpu)
                        InfoRow("Màn hình", device.display)
                        InfoRow("Tần số quét", device.refreshRate)
                    }
                }
            }

            item { SectionHeader("Hệ thống") }
            item {
                GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InfoRow("Android", device.androidVersion)
                        InfoRow("API level", "${device.sdkInt}")
                        InfoRow("Bản vá bảo mật", device.securityPatch)
                        InfoRow("Build ID", device.buildId)
                        InfoRow("Kernel", device.kernel)
                        InfoRow("SELinux", device.selinux)
                        InfoRow("Thời gian chạy", device.uptime)
                    }
                }
            }

            item { SectionHeader("Bộ nhớ & Lưu trữ") }
            item {
                GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InfoRow("Tổng RAM", device.ramTotal)
                        InfoRow("RAM khả dụng", device.ramAvailable)
                        InfoRow("Tổng dung lượng", device.storageTotal)
                        InfoRow("Dung lượng trống", device.storageFree)
                    }
                }
            }

            item { SectionHeader("Pin") }
            item {
                GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InfoRow("Mức pin", "${device.batteryLevel}%")
                        InfoRow("Tình trạng", device.batteryHealth)
                        InfoRow("Nhiệt độ", device.batteryTemp)
                    }
                }
            }
        }
    }
}
