package com.kenzi.booster.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Cơ chế tự cập nhật:
 * 1. Tải manifest.json từ URL cấu hình.
 * 2. Nếu versionCode mới > hiện tại -> tải APK và cài (root/shizuku) hoặc mở trình cài đặt.
 * 3. Nạp thêm danh sách tweak từ xa (nhẹ và nguy hiểm) và ghép vào registry nội bộ.
 */
object UpdateManager {

    data class Manifest(
        val versionCode: Int,
        val versionName: String,
        val changelog: String,
        val apkUrl: String,
        val tweaks: List<Tweak>
    )

    data class UpdateState(
        val checking: Boolean = false,
        val downloading: Boolean = false,
        val updateAvailable: Boolean = false,
        val installed: Boolean = false,
        val message: String? = null,
        val manifest: Manifest? = null,
        val remoteTweakCount: Int = 0
    )

    private fun httpGet(url: String, timeout: Int = 15000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = timeout
        conn.readTimeout = timeout
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "KenZiBooster/1.2.0")
        return try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    suspend fun fetchManifest(url: String): Manifest = withContext(Dispatchers.IO) {
        val raw = httpGet(url)
        val json = JSONObject(raw)
        Manifest(
            versionCode = json.optInt("versionCode", 0),
            versionName = json.optString("versionName", ""),
            changelog = json.optString("changelog", ""),
            apkUrl = json.optString("apkUrl", ""),
            tweaks = parseTweaks(json.optJSONArray("tweaks"))
        )
    }

    private fun parseTweaks(array: JSONArray?): List<Tweak> {
        if (array == null) return emptyList()
        val out = mutableListOf<Tweak>()
        for (i in 0 until array.length()) {
            try {
                val o = array.getJSONObject(i)
                val cat = TweakCategory.entries.firstOrNull { it.name == o.optString("category") }
                    ?: TweakCategory.ADVANCED
                val risk = Risk.entries.firstOrNull { it.name == o.optString("risk") } ?: Risk.CAUTION
                val acc = Access.entries.firstOrNull { it.name == o.optString("access") } ?: Access.BOTH
                out += Tweak(
                    id = o.optString("id", "remote.$i"),
                    name = o.optString("name", "Tweak từ xa"),
                    desc = o.optString("desc", ""),
                    category = cat,
                    risk = risk,
                    access = acc,
                    applyCmd = o.optString("apply", "").ifBlank { null },
                    revertCmd = o.optString("revert", "").ifBlank { null },
                    inputKind = InputKind.entries.firstOrNull { it.name == o.optString("inputKind") },
                    inputLabel = o.optString("inputLabel", "").ifBlank { null },
                    inputHint = o.optString("inputHint", "").ifBlank { null },
                    remote = true,
                    supportNote = o.optString("note", "").ifBlank { null }
                )
            } catch (_: Throwable) {
            }
        }
        return out
    }

    /** Tải APK về máy. Trả về đường dẫn file cục bộ. */
    suspend fun downloadApk(url: String, dest: File): File = withContext(Dispatchers.IO) {
        dest.parentFile?.mkdirs()
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.setRequestProperty("User-Agent", "KenZiBooster/1.2.0")
        try {
            conn.inputStream.use { input ->
                dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
            }
        } finally {
            conn.disconnect()
        }
        dest
    }

    fun sha256(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            while (true) {
                val r = input.read(buf)
                if (r <= 0) break
                digest.update(buf, 0, r)
            }
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Throwable) {
        null
    }

    /** Cài APK đã tải. Ưu tiên root, sau đó Shizuku, cuối cùng mở trình cài đặt hệ thống. */
    suspend fun installApk(context: Context, file: File, priv: Privilege?): Boolean {
        when (priv) {
            Privilege.ROOT, Privilege.SHIZUKU -> {
                val target = File("/data/local/tmp/kenzi_update.apk")
                try {
                    file.copyTo(target, overwrite = true)
                } catch (_: Throwable) {
                }
                val r = ShellRunner.run(
                    "pm install -r -d \"$target\"",
                    priv ?: Privilege.PLAIN,
                    timeoutMs = 120_000
                )
                if (r.ok || r.output.contains("Success")) {
                    try { target.delete() } catch (_: Throwable) {}
                    return true
                }
                return installViaIntent(context, file)
            }
            else -> return installViaIntent(context, file)
        }
    }

    private fun installViaIntent(context: Context, file: File): Boolean = try {
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", file
        )
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (_: Throwable) {
        false
    }

    fun currentVersionCode(context: Context): Int = try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode.toInt() else info.versionCode
    } catch (_: Throwable) {
        0
    }
}
