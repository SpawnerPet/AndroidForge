package com.kenzi.booster.core

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeviceInfo(
    val brand: String,
    val model: String,
    val device: String,
    val manufacturer: String,
    val androidVersion: String,
    val sdkInt: Int,
    val securityPatch: String,
    val kernel: String,
    val abi: String,
    val soc: String,
    val cpuCores: Int,
    val cpuInfo: String,
    val ramTotal: String,
    val ramAvailable: String,
    val ramUsedPercent: Int,
    val storageTotal: String,
    val storageFree: String,
    val storageUsedPercent: Int,
    val batteryLevel: Int,
    val batteryHealth: String,
    val batteryTemp: String,
    val uptime: String,
    val selinux: String,
    val buildId: String,
    val display: String,
    val refreshRate: String,
    val gpu: String
)

object DeviceInfoCollector {

    suspend fun collect(context: Context): DeviceInfo = withContext(Dispatchers.IO) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalRam = memInfo.totalMem
        val availRam = memInfo.availMem
        val ramTotalText = formatBytes(totalRam)
        val ramAvailText = formatBytes(availRam)
        val ramUsed = if (totalRam > 0) (((totalRam - availRam).toDouble() / totalRam) * 100).toInt() else 0

        val stat = StatFs(Environment.getDataDirectory().path)
        val stTotal = stat.totalBytes
        val stFree = stat.availableBytes
        val stUsed = if (stTotal > 0) (((stTotal - stFree).toDouble() / stTotal) * 100).toInt() else 0

        val cpuInfo = runCatching {
            File("/proc/cpuinfo").readText().lines()
                .filter { it.startsWith("Hardware") || it.startsWith("model name") || it.startsWith("Processor") }
                .joinToString(" | ") { it.substringAfter(":").trim() }
                .ifBlank { "Không đọc được" }
        }.getOrDefault("Không đọc được")

        val soc = runCatching {
            File("/sys/devices/soc0/soc_id").readText().trim()
        }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: runCatching { File("/sys/devices/soc0/machine").readText().trim() }.getOrNull()
            ?: Build.HARDWARE

        val kernel = runCatching { File("/proc/version").readText().trim() }.getOrDefault("Không đọc được")

        val selinux = runCatching {
            File("/sys/fs/selinux/enforce").readText().trim()
                .let { if (it == "1") "Enforcing" else "Permissive" }
        }.getOrDefault("Không xác định")

        val battery = batteryInfo(context)

        val displayMetrics = context.resources.displayMetrics
        val refresh = try {
            val dm = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            @Suppress("DEPRECATION")
            dm.defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate }?.let { "${it.toInt()} Hz" } ?: "?"
        } catch (_: Throwable) {
            "?"
        }

        val gpu = runCatching {
            File("/sys/class/kgsl/kgsl-3d0/device/gpu").readText().trim()
        }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: runCatching {
                File("/proc/gpu").readText().trim()
            }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: "Không xác định"

        val uptimeMs = SystemClock.elapsedRealtime()
        val bootTime = System.currentTimeMillis() - uptimeMs

        DeviceInfo(
            brand = Build.BRAND.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            device = Build.DEVICE,
            manufacturer = Build.MANUFACTURER,
            androidVersion = Build.VERSION.RELEASE ?: "?",
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = securityPatch(),
            kernel = kernel,
            abi = Build.SUPPORTED_ABIS.joinToString(", "),
            soc = soc,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            cpuInfo = cpuInfo,
            ramTotal = ramTotalText,
            ramAvailable = ramAvailText,
            ramUsedPercent = ramUsed,
            storageTotal = formatBytes(stTotal),
            storageFree = formatBytes(stFree),
            storageUsedPercent = stUsed,
            batteryLevel = battery.first,
            batteryHealth = battery.second,
            batteryTemp = battery.third,
            uptime = formatDuration(uptimeMs) + " (khởi động " +
                    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(bootTime)) + ")",
            selinux = selinux,
            buildId = Build.ID,
            display = "${displayMetrics.widthPixels}x${displayMetrics.heightPixels} (${displayMetrics.densityDpi}dpi)",
            refreshRate = refresh,
            gpu = gpu
        )
    }

    private fun securityPatch(): String = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Build.VERSION.SECURITY_PATCH ?: "Không rõ"
        else "Không rõ"
    } catch (_: Throwable) {
        "Không rõ"
    }

    private fun batteryInfo(context: Context): Triple<Int, String, String> {
        return try {
            val intent = android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            val b = context.registerReceiver(null, intent) ?: return Triple(-1, "?", "?")
            val level = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale = b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
            val pct = if (scale > 0) (level * 100 / scale) else -1
            val health = when (b.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, -1)) {
                android.os.BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt"
                android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nóng"
                android.os.BatteryManager.BATTERY_HEALTH_DEAD -> "Hỏng"
                android.os.BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp"
                else -> "Khác"
            }
            val temp = b.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            Triple(pct, health, "$temp °C")
        } catch (_: Throwable) {
            Triple(-1, "?", "?")
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var i = 0
        while (value >= 1024 && i < units.lastIndex) {
            value /= 1024
            i++
        }
        return String.format(Locale.US, "%.2f %s", value, units[i])
    }

    fun formatDuration(ms: Long): String {
        val s = ms / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return String.format(Locale.US, "%dd %02d:%02d:%02d", d, h, m, sec)
    }
}
