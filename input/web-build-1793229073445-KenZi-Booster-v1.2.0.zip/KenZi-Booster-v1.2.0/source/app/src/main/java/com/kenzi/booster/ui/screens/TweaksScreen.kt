package com.kenzi.booster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kenzi.booster.core.Privilege
import com.kenzi.booster.core.Risk
import com.kenzi.booster.core.Tweak
import com.kenzi.booster.core.TweakCategory
import com.kenzi.booster.ui.components.GlassButton
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.components.RiskBadge
import com.kenzi.booster.ui.components.TweakRow
import com.kenzi.booster.ui.theme.KenZiPalette

@Composable
fun TweaksScreen(
    tweaks: List<Tweak>,
    enabled: Set<String>,
    busy: Set<String>,
    privilege: Privilege?,
    onToggle: (Tweak, Boolean, String?) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<TweakCategory?>(null) }
    var pending by remember { mutableStateOf<PendingAction?>(null) }

    val filtered = remember(tweaks, query, category) {
        tweaks.filter { t ->
            val matchQuery = query.isBlank() ||
                    t.name.contains(query, true) ||
                    t.desc.contains(query, true) ||
                    t.id.contains(query, true)
            val matchCat = category == null || t.category == category
            matchQuery && matchCat
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { HeaderCard(tweaks, enabled, privilege) }

        item {
            GlassSurface(shape = RoundedCornerShape(18.dp), tintAlpha = 0.08f) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text("Tìm tweak...", style = MaterialTheme.typography.bodyMedium)
                    },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Xoá", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CategoryChip("Tất cả", category == null, KenZiPalette.Aqua) {
                    category = null
                }
                TweakCategory.entries.forEach { c ->
                    CategoryChip(c.title, category == c, categoryColor(c)) {
                        category = if (category == c) null else c
                    }
                }
            }
        }

        items(filtered, key = { it.id }) { t ->
            val locked = !t.allowed(privilege)
            TweakRow(
                name = t.name,
                desc = t.desc + (t.supportNote?.let { "\n• $it" } ?: ""),
                risk = t.risk,
                enabled = enabled.contains(t.id),
                busy = busy.contains(t.id),
                locked = locked,
                remote = t.remote,
                accent = categoryColor(t.category),
                onToggle = { checked ->
                    if (!checked) {
                        pending = PendingAction(t, false, null)
                    } else if (t.inputKind != null) {
                        pending = PendingAction(t, true, "")
                    } else if (t.risk == Risk.DANGER) {
                        pending = PendingAction(t, true, null)
                    } else {
                        onToggle(t, true, null)
                    }
                }
            )
        }

        if (filtered.isEmpty()) {
            item {
                GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.06f) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Không tìm thấy tweak phù hợp",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // Hộp thoại cảnh báo tính năng nguy hiểm
    val danger = pending?.takeIf { it.tweak.risk == Risk.DANGER && it.tweak.inputKind == null }
    if (danger != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(28.dp),
            icon = {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = KenZiPalette.Ember)
            },
            title = { Text("Cảnh báo nguy hiểm") },
            text = {
                Column {
                    Text(
                        "Bạn sắp bật \"${danger.tweak.name}\".",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        danger.tweak.desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RiskBadge(danger.tweak.risk)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Có thể gây hỏng hệ thống, mất dữ liệu hoặc giật máy.",
                            style = MaterialTheme.typography.labelSmall,
                            color = KenZiPalette.Ember
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onToggle(danger.tweak, true, null)
                    pending = null
                }) {
                    Text("Tôi đã hiểu, vẫn bật", color = KenZiPalette.Ember, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) {
                    Text("Huỷ")
                }
            }
        )
    }

    // Hộp thoại nhập giá trị cho tweak tương tác
    val input = pending?.takeIf { it.tweak.inputKind != null }
    if (input != null) {
        val t = input.tweak
        var value by remember(t.id) { mutableStateOf(input.value ?: "") }
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(28.dp),
            title = { Text(t.name) },
            text = {
                Column {
                    Text(
                        t.desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(t.inputLabel ?: "Nhập giá trị") },
                        placeholder = { Text(t.inputHint ?: "") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RiskBadge(t.risk)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Lệnh sẽ chạy với quyền hệ thống.",
                            style = MaterialTheme.typography.labelSmall,
                            color = KenZiPalette.Ember
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = value.isNotBlank(),
                    onClick = {
                        onToggle(t, true, value)
                        pending = null
                    }
                ) { Text("Chạy") }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text("Huỷ") }
            }
        )
    }
}

data class PendingAction(val tweak: Tweak, val enable: Boolean, val value: String?)

@Composable
private fun HeaderCard(tweaks: List<Tweak>, enabled: Set<String>, privilege: Privilege?) {
    GlassSurface(shape = RoundedCornerShape(28.dp), tintAlpha = 0.13f) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "KenZi Booster",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Made by KenZi (Tài bá khí)",
                        style = MaterialTheme.typography.labelMedium,
                        color = KenZiPalette.Aqua
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when (privilege) {
                                Privilege.ROOT -> KenZiPalette.Aqua.copy(alpha = 0.18f)
                                Privilege.SHIZUKU -> KenZiPalette.Sky.copy(alpha = 0.18f)
                                else -> KenZiPalette.Ember.copy(alpha = 0.18f)
                            }
                        )
                        .border(
                            1.dp,
                            when (privilege) {
                                Privilege.ROOT -> KenZiPalette.Aqua.copy(alpha = 0.5f)
                                Privilege.SHIZUKU -> KenZiPalette.Sky.copy(alpha = 0.5f)
                                else -> KenZiPalette.Ember.copy(alpha = 0.5f)
                            },
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        when (privilege) {
                            Privilege.ROOT -> "ROOT"
                            Privilege.SHIZUKU -> "SHIZUKU"
                            else -> "LOCKED"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = when (privilege) {
                            Privilege.ROOT -> KenZiPalette.Aqua
                            Privilege.SHIZUKU -> KenZiPalette.Sky
                            else -> KenZiPalette.Ember
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("Tính năng", tweaks.size.toString(), KenZiPalette.Aqua, Modifier.weight(1f))
                MiniStat("Đang bật", enabled.size.toString(), KenZiPalette.Violet, Modifier.weight(1f))
                MiniStat(
                    "Nguy hiểm",
                    tweaks.count { it.risk == Risk.DANGER }.toString(),
                    KenZiPalette.Ember,
                    Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(accent.copy(alpha = 0.10f))
            .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(16.dp))
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CategoryChip(text: String, selected: Boolean, accent: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) accent.copy(alpha = 0.20f) else androidx.compose.ui.graphics.Color.White.copy(alpha = 0.06f))
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.55f) else androidx.compose.ui.graphics.Color.White.copy(alpha = 0.14f),
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .then(Modifier)
            .clickableNoRipple(onClick)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val interaction = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    return this.then(
        Modifier.clickable(
            interactionSource = interaction,
            indication = null,
            onClick = onClick
        )
    )
}

fun categoryColor(c: TweakCategory): androidx.compose.ui.graphics.Color = when (c) {
    TweakCategory.PERFORMANCE -> KenZiPalette.Aqua
    TweakCategory.SYSTEM -> KenZiPalette.Sky
    TweakCategory.DISPLAY -> KenZiPalette.Violet
    TweakCategory.NETWORK -> KenZiPalette.Aqua
    TweakCategory.AUDIO -> KenZiPalette.Violet
    TweakCategory.BATTERY -> KenZiPalette.Ember
    TweakCategory.PRIVACY -> KenZiPalette.Sky
    TweakCategory.CLEANUP -> KenZiPalette.Aqua
    TweakCategory.ADVANCED -> KenZiPalette.Ember
}
