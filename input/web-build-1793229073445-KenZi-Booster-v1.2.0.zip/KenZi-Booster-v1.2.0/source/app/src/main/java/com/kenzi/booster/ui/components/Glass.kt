package com.kenzi.booster.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.kenzi.booster.ui.theme.KenZiPalette
import com.kenzi.booster.ui.theme.backdropColorAt

/**
 * Nền ứng dụng: màu phẳng chuyển động tự nhiên qua 4 màu chủ đạo.
 * Không gradient, không hiệu ứng nặng nên không gây lag.
 */
@Composable
fun AnimatedBackdrop(
    dark: Boolean,
    animate: Boolean,
    content: @Composable () -> Unit
) {
    val colors = if (dark) KenZiPalette.DarkBackdrop else KenZiPalette.LightBackdrop
    val transition = rememberInfiniteTransition(label = "backdrop")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = colors.size.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "backdropPhase"
    )
    val bg = backdropColorAt(colors, if (animate) phase else 0f)
    Box(modifier = Modifier.fillMaxSize().background(bg)) {
        content()
    }
}

/**
 * Bề mặt "liquid glass": lớp kính trong mờ có viền sáng, bo góc,
 * kèm một vệt sáng mảnh ở phía trên để tạo cảm giác kính lỏng.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(26.dp),
    tintAlpha: Float = 0.13f,
    content: @Composable () -> Unit
) {
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val tint = Color.White
    val borderColor = tint.copy(alpha = if (dark) 0.20f else 0.55f)
    val highlight = tint.copy(alpha = if (dark) 0.10f else 0.45f)

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                if (dark) Color(0xFF0E171B).copy(alpha = tintAlpha + 0.28f)
                else Color.White.copy(alpha = tintAlpha + 0.55f)
            )
            .border(1.dp, borderColor, shape)
    ) {
        // Vệt sáng trên (specular) - tạo chiều sâu cho lớp kính
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .background(highlight)
                .align(Alignment.TopCenter)
        )
        Box(modifier = Modifier.fillMaxSize()) { content() }
    }
}

/** Nút chính dạng kính, bo góc, không gradient. */
@Composable
fun GlassButton(
    text: String,
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val alpha by animateFloatAsState(
        1f,
        tween(200),
        if (enabled) 1f else 0.4f,
        "btnAlpha"
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(accent.copy(alpha = 0.16f * alpha))
            .border(1.dp, accent.copy(alpha = 0.55f * alpha), RoundedCornerShape(18.dp))
            .noRippleClickable(enabled) { onClick() }
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = accent.copy(alpha = alpha)
        )
    }
}

/** Nhóm nút hành động ngang. */
@Composable
fun GlassButtonRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.spacedBy(10.dp),
    content: @Composable () -> Unit
) {
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = horizontalArrangement) {
        content()
    }
}

@Composable
private fun Modifier.noRippleClickable(enabled: Boolean, onClick: () -> Unit): Modifier {
    val interaction = remember { MutableInteractionSource() }
    return this.clickable(
        interactionSource = interaction,
        indication = null,
        enabled = enabled,
        onClick = onClick
    )
}

/** Màu nhấn mượt (chuyển tiếp màu khi trạng thái đổi). */
@Composable
fun animatedAccent(target: Color): Color =
    androidx.compose.animation.animateColorAsState(
        targetValue = target,
        animationSpec = tween(260),
        label = "accent"
    ).value
