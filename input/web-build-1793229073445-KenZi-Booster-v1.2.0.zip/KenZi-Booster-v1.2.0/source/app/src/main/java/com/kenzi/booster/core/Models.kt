package com.kenzi.booster.core

/** Loại đặc quyền dùng để chạy lệnh. */
enum class Privilege { ROOT, SHIZUKU, PLAIN }

/** Mức độ rủi ro của một tweak. */
enum class Risk { SAFE, CAUTION, DANGER }

/** Quyền tối thiểu cần có để chạy tweak. */
enum class Access { ROOT, SHIZUKU, BOTH }

/** Loại dữ liệu cần nhập khi bật tweak tương tác. */
enum class InputKind { PACKAGE, SYSPROP, RAW }

/** Danh mục tweak. */
enum class TweakCategory(val title: String, val icon: String) {
    PERFORMANCE("Hiệu năng", "bolt"),
    SYSTEM("Hệ thống", "tune"),
    DISPLAY("Hiển thị", "display"),
    NETWORK("Mạng", "wifi"),
    AUDIO("Âm thanh", "volume"),
    BATTERY("Pin & Nhiệt", "battery"),
    PRIVACY("Riêng tư & Bảo mật", "shield"),
    CLEANUP("Dọn dẹp", "clean"),
    ADVANCED("Nâng cao", "science")
}

/**
 * Một tính năng (tweak) của ứng dụng.
 * @param applyCmd lệnh áp dụng (chạy qua root/shizuku)
 * @param revertCmd lệnh hoàn tác
 * @param inputKind nếu khác null, ứng dụng sẽ yêu cầu người dùng nhập giá trị trước khi chạy
 * @param remote true nếu tweak được tải về từ máy chủ (tự cập nhật)
 */
data class Tweak(
    val id: String,
    val name: String,
    val desc: String,
    val category: TweakCategory,
    val risk: Risk = Risk.SAFE,
    val access: Access = Access.BOTH,
    val applyCmd: String? = null,
    val revertCmd: String? = null,
    val inputKind: InputKind? = null,
    val inputLabel: String? = null,
    val inputHint: String? = null,
    val remote: Boolean = false,
    val supportNote: String? = null
) {
    fun allowed(priv: Privilege?): Boolean = when (access) {
        Access.ROOT -> priv == Privilege.ROOT
        Access.SHIZUKU -> priv == Privilege.SHIZUKU || priv == Privilege.ROOT
        Access.BOTH -> priv != null && priv != Privilege.PLAIN
    }
}

data class ShellResult(
    val ok: Boolean,
    val output: String,
    val code: Int = 0,
    val error: String? = null
)

enum class RootManager(val label: String) {
    MAGISK("Magisk"),
    KERNELSU("KernelSU"),
    APATCH("APatch"),
    SUPERSU("SuperSU"),
    UNKNOWN("Root khác / Generic")
}
