package com.kenzi.booster.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Bộ chạy lệnh shell.
 * - ROOT: dùng `su -c`
 * - SHIZUKU: dùng Shizuku.newProcess (quyền shell của hệ thống)
 * - PLAIN: dùng process thường của app
 */
object ShellRunner {

    suspend fun run(
        command: String,
        privilege: Privilege,
        timeoutMs: Long = 20_000
    ): ShellResult = withContext(Dispatchers.IO) {
        try {
            when (privilege) {
                Privilege.ROOT -> runRoot(command, timeoutMs)
                Privilege.SHIZUKU -> runShizuku(command, timeoutMs)
                Privilege.PLAIN -> runPlain(command, timeoutMs)
            }
        } catch (t: Throwable) {
            ShellResult(false, "", -1, t.message ?: t.toString())
        }
    }

    private fun readAll(input: java.io.InputStream): String = try {
        BufferedReader(InputStreamReader(input)).use { it.readText() }
    } catch (_: Throwable) {
        ""
    }

    private fun runRoot(command: String, timeoutMs: Long): ShellResult {
        val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val out = readAll(p.inputStream)
        val finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!finished) {
            p.destroy()
            return ShellResult(false, out, -1, "Timeout sau ${timeoutMs}ms")
        }
        val code = p.exitValue()
        return ShellResult(code == 0, out.trim(), code, if (code == 0) null else out.trim())
    }

    private fun runPlain(command: String, timeoutMs: Long): ShellResult {
        val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        val out = readAll(p.inputStream)
        val finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!finished) {
            p.destroy()
            return ShellResult(false, out, -1, "Timeout sau ${timeoutMs}ms")
        }
        val code = p.exitValue()
        return ShellResult(code == 0, out.trim(), code, if (code == 0) null else out.trim())
    }

    private fun runShizuku(command: String, timeoutMs: Long): ShellResult {
        if (!Shizuku.pingBinder()) {
            return ShellResult(false, "", -1, "Shizuku không phản hồi. Hãy mở Shizuku và chạy lại.")
        }
        val proc = newShizukuProcess(command)
            ?: return ShellResult(false, "", -1, "Không khởi tạo được tiến trình qua Shizuku")
        val out = readAll(proc.inputStream)
        val err = try { readAll(proc.errorStream) } catch (_: Throwable) { "" }
        val finished = proc.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!finished) {
            proc.destroy()
            return ShellResult(false, out + err, -1, "Timeout sau ${timeoutMs}ms")
        }
        val code = proc.exitValue()
        val merged = (out + "\n" + err).trim()
        return ShellResult(code == 0, merged, code, if (code == 0) null else merged)
    }

    /**
     * Shizuku ẩn newProcess ở một số phiên bản API nên dùng reflection,
     * thử biến thể String[] trước rồi mới tới biến thể String.
     */
    private fun newShizukuProcess(command: String): rikka.shizuku.ShizukuRemoteProcess? {
        val cls = Shizuku::class.java
        val arrayM = runCatching {
            cls.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
        }.getOrNull()
        if (arrayM != null) {
            runCatching {
                arrayM.isAccessible = true
                return arrayM.invoke(null, arrayOf("sh", "-c", command), null, null)
                        as rikka.shizuku.ShizukuRemoteProcess
            }
        }
        val strM = runCatching {
            cls.getDeclaredMethod(
                "newProcess", String::class.java, Array<String>::class.java, String::class.java
            )
        }.getOrNull()
        if (strM != null) {
            runCatching {
                strM.isAccessible = true
                return strM.invoke(null, "sh -c $command", null, null)
                        as rikka.shizuku.ShizukuRemoteProcess
            }
        }
        return null
    }

    /** Kiểm tra quyền root bằng cách thực thi `id` qua su. */
    suspend fun probeRoot(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
            val out = readAll(p.inputStream).trim()
            p.waitFor(8, TimeUnit.SECONDS)
            val ok = out.contains("uid=0")
            ok to out
        } catch (_: Throwable) {
            false to ""
        }
    }

    /** Kiểm tra Shizuku đã được cấp quyền cho app chưa. */
    fun probeShizuku(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                Shizuku.getUid() >= 0
    } catch (_: Throwable) {
        false
    }
}
