package com.kenzi.booster.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/**
 * 4 màu chủ đạo của KenZi Booster.
 * Không dùng gradient - mọi bề mặt là màu phẳng, bo góc.
 */
object KenZiPalette {
    val Aqua = Color(0xFF7DF9E6)      // chủ đạo 1
    val Sky = Color(0xFF6EA8FF)       // chủ đạo 2
    val Violet = Color(0xFFB48CFF)    // chủ đạo 3
    val Ember = Color(0xFFFF8A6B)     // chủ đạo 4

    val All = listOf(Aqua, Sky, Violet, Ember)

    // Nền nâng cấp (mỗi nền lấy cùng tông với 1 màu chủ đạo)
    val DarkBackdrop = listOf(
        Color(0xFF0A1418),
        Color(0xFF0D1424),
        Color(0xFF141026),
        Color(0xFF1A1210)
    )

    val LightBackdrop = listOf(
        Color(0xFFF1F8F7),
        Color(0xFFEFF3FB),
        Color(0xFFF6F1FC),
        Color(0xFFFCF4EF)
    )
}

private val DarkColors = darkColorScheme(
    primary = KenZiPalette.Aqua,
    onPrimary = Color(0xFF06221E),
    secondary = KenZiPalette.Sky,
    onSecondary = Color(0xFF07152B),
    tertiary = KenZiPalette.Violet,
    onTertiary = Color(0xFF1B0F33),
    error = KenZiPalette.Ember,
    onError = Color(0xFF2E0F06),
    background = KenZiPalette.DarkBackdrop[0],
    onBackground = Color(0xFFE9F1F2),
    surface = Color(0xFF101A1E),
    onSurface = Color(0xFFE9F1F2),
    surfaceVariant = Color(0xFF1A272C),
    onSurfaceVariant = Color(0xFFAFC0C4),
    outline = Color(0xFF2C3C42)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF16A795),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF3C72D8),
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Color(0xFF7A4BD1),
    onTertiary = Color(0xFFFFFFFF),
    error = Color(0xFFD1553A),
    onError = Color(0xFFFFFFFF),
    background = KenZiPalette.LightBackdrop[0],
    onBackground = Color(0xFF0B1418),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B1418),
    surfaceVariant = Color(0xFFE3EAEC),
    onSurfaceVariant = Color(0xFF4A5A5F),
    outline = Color(0xFFCBD7DA)
)

private val KenZiTypography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 26.sp),
        headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 19.sp),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.Medium, fontSize = 16.sp),
        bodyLarge = base.bodyLarge.copy(fontSize = 15.sp),
        bodyMedium = base.bodyMedium.copy(fontSize = 13.5.sp),
        labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Medium)
    )
}

@Composable
fun KenZiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = KenZiTypography,
        content = content
    )
}

/** Nội suy màu nền theo pha động. */
fun backdropColorAt(colors: List<Color>, phase: Float): Color {
    if (colors.isEmpty()) return Color.Black
    val size = colors.size
    val p = phase.coerceIn(0f, size.toFloat())
    val index = p.toInt() % size
    val frac = p - p.toInt()
    val next = (index + 1) % size
    return lerp(colors[index], colors[next], frac)
}
