package com.kenzi.booster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kenzi.booster.core.PrivilegeManager
import com.kenzi.booster.ui.components.GlassButton
import com.kenzi.booster.ui.components.GlassButtonRow
import com.kenzi.booster.ui.components.GlassSurface
import com.kenzi.booster.ui.components.InfoRow
import com.kenzi.booster.ui.components.SectionHeader
import com.kenzi.booster.ui.theme.KenZiPalette

/**
 * Màn hình quyền: trạng thái ROOT / SHIZUKU, các quyền ứng dụng đã được cấp
 * và các quyền hệ thống quan trọng.
 */
@Composable
fun PermissionsScreen(
    state: PrivilegeManager.PrivilegeState,
    permissions: List<Pair<String, String>>,
    onRefresh: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenRootManager: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassSurface(shape = RoundedCornerShape(28.dp), tintAlpha = 0.13f) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        "Quyền & Đặc quyền",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Chi tiết các quyền mà ứng dụng đang được cấp",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(14.dp))

                    StatusRow(
                        title = "Quyền ROOT",
                        subtitle = if (state.rootAvailable)
                            "Đã cấp - mở khoá toàn bộ tính năng (${state.rootManager.label})"
                        else "Chưa cấp - cần cài Magisk/KernelSU và cấp quyền cho ứng dụng",
                        ok = state.rootAvailable,
                        accent = KenZiPalette.Aqua
                    )
                    Spacer(Modifier.height(10.dp))
                    StatusRow(
                        title = "Quyền SHIZUKU",
                        subtitle = if (state.shizukuAvailable)
                            "Đã cấp - mở khoá nhóm tính năng dùng quyền shell"
                        else "Chưa cấp - mở Shizuku và khởi động bằng wireless debugging",
                        ok = state.shizukuAvailable,
                        accent = KenZiPalette.Sky
                    )

                    Spacer(Modifier.height(14.dp))
                    GlassButtonRow {
                        GlassButton(
                            text = "Mở Shizuku",
                            accent = KenZiPalette.Sky,
                            modifier = Modifier.weight(1f)
                        ) { onOpenShizuku() }
                        GlassButton(
                            text = "Mở Root",
                            accent = KenZiPalette.Violet,
                            modifier = Modifier.weight(1f)
                        ) { onOpenRootManager() }
                    }
                    Spacer(Modifier.height(10.dp))
                    GlassButton(
                        text = "Kiểm tra lại",
                        accent = KenZiPalette.Aqua,
                        modifier = Modifier.fillMaxWidth()
                    ) { onRefresh() }
                }
            }
        }

        item { SectionHeader("Quyền của ứng dụng", trailing = "${permissions.size} quyền") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (permissions.isEmpty()) {
                        Text(
                            "Không đọc được danh sách quyền. Hãy thử làm mới.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        permissions.forEach { (perm, status) ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (status == "Đã cấp") Icons.Filled.CheckCircle
                                    else Icons.Filled.ErrorOutline,
                                    contentDescription = null,
                                    tint = if (status == "Đã cấp") KenZiPalette.Aqua
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    perm.removePrefix("android.permission."),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (status == "Đã cấp") KenZiPalette.Aqua
                                    else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        item { SectionHeader("Quyền hệ thống quan trọng") }
        item {
            GlassSurface(shape = RoundedCornerShape(22.dp), tintAlpha = 0.08f) {
                Column(modifier = Modifier.padding(16.dp)) {
                    InfoRow("Ghi cài đặt hệ thống", "Cần cho nhiều tweak")
                    InfoRow("Cài đặt gói ứng dụng", "Dùng cho tắt/cài app")
                    InfoRow("Truy cập mạng", "Dùng cho kiểm tra cập nhật")
                    InfoRow("Cài gói ngoài", "Dùng khi cập nhật tự động")
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Info, contentDescription = null,
                            tint = KenZiPalette.Sky, modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "ROOT cho phép toàn quyền, SHIZUKU chỉ cho quyền shell của hệ thống.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusRow(title: String, subtitle: String, ok: Boolean, accent: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(accent.copy(alpha = 0.08f))
            .border(1.dp, accent.copy(alpha = 0.30f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(if (ok) accent else MaterialTheme.colorScheme.outline)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            if (ok) "ĐÃ CẤP" else "CHƯA CẤP",
            style = MaterialTheme.typography.labelSmall,
            color = if (ok) accent else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold
        )
    }
}
