package com.example.screenai

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.example.screenai.START"
        const val ACTION_STOP = "com.example.screenai.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "screenai_capture"
        private const val NOTIFICATION_ID = 701
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val busy = AtomicBoolean(false)
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var answerView: TextView? = null
    private var intervalSeconds = 20L
    private var lastAnswer = "Đang live. Nhấn Giải để phân tích màn hình hiện tại."
    private var manualRequest = false

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            startForeground(NOTIFICATION_ID, makeNotification())
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_DATA)
            if (data == null || code != Activity.RESULT_OK) { stopCapture(); return START_NOT_STICKY }
            if (projection != null) stopCapture()
            val prefs = getSharedPreferences("screenai", Context.MODE_PRIVATE)
            intervalSeconds = (prefs.getString("interval","20")?.toLongOrNull() ?: 20L).coerceIn(10,300)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, Handler(mainLooper))
            createOverlay()
            beginVirtualDisplay()
            scope.launch {
                while (isActive && projection != null) {
                    delay(intervalSeconds * 1000)
                    if (busy.compareAndSet(false, true)) {
                        try {
                            val bitmap = captureFrame()
                            if (bitmap != null) {
                                val answer = askProvider(bitmap)
                                bitmap.recycle()
                                lastAnswer = answer
                                showAnswer(answer)
                                updateNotification("Đã phân tích màn hình")
                            }
                        } catch (e: Exception) {
                            showAnswer("Lỗi: ${e.message ?: "không rõ"}. Hãy kiểm tra API key, model và mạng.")
                        } finally { busy.set(false) }
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun createOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xEE202124.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply { text = "ScreenAI"; textSize = 17f; setTextColor(-1) },
            LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "×"; setOnClickListener { removeOverlay() } })
        root.addView(header)
        root.addView(Button(this).apply {
            text = "Giải câu hỏi trên màn hình"
            setOnClickListener {
                if (busy.compareAndSet(false, true)) scope.launch {
                    try {
                        val bitmap = captureFrame()
                        if (bitmap == null) showAnswer("Chưa lấy được ảnh. Chờ một chút rồi thử lại.")
                        else {
                            val answer = askProvider(bitmap)
                            bitmap.recycle()
                            lastAnswer = answer
                            showAnswer(answer)
                        }
                    } catch (e: Exception) { showAnswer("Lỗi: ${e.message ?: "không rõ"}") }
                    finally { busy.set(false) }
                } else showAnswer("AI đang xử lý, vui lòng đợi.")
            }
        })
        answerView = TextView(this).apply {
            text = lastAnswer
            textSize = 14f
            setTextColor(-1)
            setPadding(4, 8, 4, 4)
        }
        val scroll = ScrollView(this).apply { addView(answerView) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 360))
        root.addView(Button(this).apply { text = "Dừng live"; setOnClickListener { stopCapture() } })
        overlay = root
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
        try { windowManager?.addView(root, params) } catch (_: Exception) { overlay = null }
    }

    private fun showAnswer(text: String) {
        lastAnswer = text
        Handler(mainLooper).post {
            answerView?.text = text
        }
    }
    private fun removeOverlay() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        overlay = null
        answerView = null
    }
    private fun beginVirtualDisplay() {
        val m = resources.displayMetrics
        val w = m.widthPixels.coerceAtLeast(1)
        val h = m.heightPixels.coerceAtLeast(1)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        virtualDisplay = projection?.createVirtualDisplay("ScreenAI", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }
    private fun captureFrame(): Bitmap? {
        val image = reader?.acquireLatestImage() ?: return null
        image.use {
            val plane = it.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * it.width
            val padded = Bitmap.createBitmap(it.width + rowPadding / pixelStride, it.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, it.width, it.height)
            padded.recycle()
            return cropped
        }
    }

    private fun askProvider(bitmap: Bitmap): String {
        val prefs = getSharedPreferences("screenai", Context.MODE_PRIVATE)
        val key = prefs.getString("api_key", "").orEmpty()
        val endpoint = prefs.getString("endpoint", "https://openrouter.ai/api/v1/chat/completions").orEmpty()
        val model = prefs.getString("model", "openrouter/auto").orEmpty()
        if (key.isBlank()) return "Chưa nhập API key."
        if (!endpoint.startsWith("https://")) return "Endpoint phải dùng HTTPS."
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 60, out)
        val data = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type","text").put("text","Đọc câu hỏi nhìn thấy trong ảnh màn hình. Trả lời bằng tiếng Việt, giải thích ngắn gọn và rõ ràng. Nếu không có câu hỏi rõ ràng, hãy nói vậy; không đoán phần bị che."))
            .put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:image/jpeg;base64,$data")))
        val body = JSONObject().put("model",model)
            .put("messages",JSONArray().put(JSONObject().put("role","user").put("content",content)))
            .put("max_tokens",800)
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Authorization","Bearer $key")
            conn.setRequestProperty("Content-Type","application/json")
            conn.setRequestProperty("X-Title","ScreenAI Android")
            if (endpoint.contains("openrouter.ai")) conn.setRequestProperty("HTTP-Referer","https://localhost")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(raw)
            if (status !in 200..299) return "API HTTP $status: ${json.optJSONObject("error")?.optString("message") ?: raw.take(200)}"
            val result = json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").opt("content")
            return when(result) {
                is String -> result
                is JSONArray -> (0 until result.length()).joinToString("\n") { result.optJSONObject(it)?.optString("text").orEmpty() }
                else -> result?.toString() ?: "Không có câu trả lời."
            }
        } finally { conn.disconnect() }
    }

    private fun makeNotification(message: String = "Live màn hình đang hoạt động"): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL,"ScreenAI live",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(this, 2, Intent(this,CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ScreenAI").setContentText(message).setOngoing(true)
            .addAction(0,"Dừng",stop).build()
    }
    private fun updateNotification(s: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID,makeNotification(s)) }
    private fun stopCapture() {
        scope.coroutineContext.cancelChildren()
        removeOverlay()
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onDestroy() { stopCapture(); scope.cancel(); super.onDestroy() }
}
