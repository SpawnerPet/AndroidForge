package com.example.screenai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("screenai", Context.MODE_PRIVATE) }
    private lateinit var provider: Spinner
    private lateinit var apiKey: EditText
    private lateinit var endpoint: EditText
    private lateinit var model: EditText
    private lateinit var interval: EditText
    private lateinit var status: TextView
    private var waitingForOverlay = false

    private val overlayPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(this)) {
            status.text = "Đã cấp quyền cửa sổ nổi."
            if (waitingForOverlay) { waitingForOverlay = false; requestCapturePermission() }
        } else status.text = "Bạn chưa cấp quyền cửa sổ nổi."
    }
    private val captureConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val i = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, i)
            status.text = "Đang live màn hình. Dùng nút Giải trong cửa sổ nổi."
        } else status.text = "Bạn đã hủy quyền chia sẻ màn hình."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,24) }
        layout.addView(TextView(this).apply { text = "ScreenAI V2"; textSize = 26f })
        layout.addView(TextView(this).apply {
            text = "Khi bấm Chạy, ứng dụng sẽ xin quyền cửa sổ nổi và chia sẻ màn hình. Nút Giải nằm trong cửa sổ nổi."
            textSize = 14f
        })
        provider = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("OpenRouter", "Gemini (OpenAI-compatible)", "API tùy chỉnh (OpenAI-compatible)"))
            setSelection(prefs.getInt("provider", 0))
        }
        layout.addView(label("Nhà cung cấp API")); layout.addView(provider)
        apiKey = EditText(this).apply { hint = "API key"; inputType = 129; setText(prefs.getString("api_key","")) }
        layout.addView(apiKey)
        endpoint = EditText(this).apply { hint = "Endpoint API"; setText(prefs.getString("endpoint","https://openrouter.ai/api/v1/chat/completions")) }
        layout.addView(endpoint)
        model = EditText(this).apply { hint = "Tên model hỗ trợ ảnh"; setText(prefs.getString("model","openrouter/auto")) }
        layout.addView(model)
        interval = EditText(this).apply { hint = "Chu kỳ live (giây, 10–300)"; inputType = 2; setText(prefs.getString("interval","20")) }
        layout.addView(interval)
        provider.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val defaults = when(position) {
                    0 -> "https://openrouter.ai/api/v1/chat/completions"
                    1 -> "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
                    else -> ""
                }
                if (endpoint.text.isNullOrBlank() || endpoint.text.toString() in listOf(
                    "https://openrouter.ai/api/v1/chat/completions",
                    "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions")) endpoint.setText(defaults)
                if (position == 0 && model.text.toString().isBlank()) model.setText("openrouter/auto")
                if (position == 1 && (model.text.toString().isBlank() || model.text.toString()=="openrouter/auto")) model.setText("gemini-2.5-flash")
            }
        }
        layout.addView(Button(this).apply { text = "Lưu cài đặt API"; setOnClickListener { saveSettings(); status.text = "Đã lưu cài đặt." } })
        layout.addView(Button(this).apply {
            text = "CHẠY LIVE + CỬA SỔ NỔI"
            setOnClickListener {
                saveSettings()
                if (apiKey.text.toString().isBlank()) { status.text = "Hãy nhập API key."; return@setOnClickListener }
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    waitingForOverlay = true
                    overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else requestCapturePermission()
            }
        })
        layout.addView(Button(this).apply { text = "Dừng live"; setOnClickListener {
            startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            status.text = "Đã gửi yêu cầu dừng."
        } })
        status = TextView(this).apply { text = "Chưa chạy."; textSize = 16f }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 14f }
    private fun saveSettings() {
        prefs.edit().putInt("provider", provider.selectedItemPosition)
            .putString("api_key", apiKey.text.toString().trim())
            .putString("endpoint", endpoint.text.toString().trim())
            .putString("model", model.text.toString().trim())
            .putString("interval", interval.text.toString().trim()).apply()
    }
    private fun requestCapturePermission() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureConsent.launch(manager.createScreenCaptureIntent())
    }
}
