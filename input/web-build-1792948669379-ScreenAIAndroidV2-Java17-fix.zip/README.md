# ScreenAI Android V2 — source project

Android source prototype with:
- Explicit MediaProjection permission requested when user taps Start inside the app.
- Overlay permission request for floating panel.
- Floating panel with a **Giải** button. It captures the current screen, sends it to a configured AI provider, then shows the answer in the floating panel.
- Continuous live capture session with a configurable interval, plus manual analysis button.
- API settings for OpenRouter, Gemini, or a custom OpenAI-compatible endpoint.
- Foreground notification with Stop action.

## Important limitations
This is source code, not a compiled/tested APK. Build with Android Studio + Android SDK.
Screen capture requires the user's system consent. Overlay permission is separately granted in Android Settings.
Use only on screens you are authorized to share. Screenshots are transmitted to the chosen AI service. Avoid passwords, private chats, banking screens, and exams where AI assistance is prohibited.
API keys are stored in app-private SharedPreferences in this prototype, not encrypted with Android Keystore. Do not distribute a build containing your personal key.
For custom providers, endpoint and model must match an OpenAI-compatible chat-completions API and support image_url content.
On Android 14+, each capture session requires fresh MediaProjection consent; this app asks again when Start is tapped.
The foreground notification has a Stop action. Stop from the app or notification.
## Build
Open this directory in Android Studio. Install SDK Platform 35 if prompted, Sync Gradle, then Build > Build APK(s). Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
