# KenZi RootLab
**Made by KenZi (Tài bá khí)**

Android native starter project for an offline-first root/Shizuku utility dashboard. Build APK online using the included GitHub Actions workflow.

## Build on an Android phone (no PC)
1. Create a GitHub repository and upload the contents of this ZIP (not the ZIP itself) to the repository root.
2. Open **Actions** and allow workflows if GitHub asks.
3. Run **Build KenZi RootLab APK** (or push to `main`).
4. Download the `KenZiRootLab-debug-apk` artifact from the completed workflow.
5. Install the APK. If Android blocks installation, enable “Allow from this source” for the browser/file manager you used.

## What is implemented
- Native Kotlin + Jetpack Compose dashboard with a dark, four-color palette and no gradients.
- Root and Shizuku status checks. The main dashboard is locked until Root or Shizuku permission is detected. Root shell uses `su`; Shizuku access is detected through the official provider API. Shizuku-only shell execution is intentionally not faked: unsupported operations remain unavailable.
- 60 tweak catalog entries across performance, memory, display, gaming, battery, network, cleanup and diagnostics.
- Risk labels, confirmation for risky operations, command preview, audit log, device/system information.
- Safe-by-default actions: read-only diagnostics and reversible settings only where explicitly supported. Unsupported or device-specific tweaks are shown as unavailable instead of running speculative commands.
- No boot image, vbmeta, system partition, kernel, governor, voltage, thermal limit, or SELinux enforcement changes.

## Important limitations
This is a starter utility, not a magic performance booster. Android/OEM firmware may ignore settings; root access does not make every sysfs/property writable. Some entries are catalog/diagnostic-only until a device-specific implementation is added. Never run a tweak unless you understand the effect. Root and Shizuku can grant powerful access.

## Compatibility
- `minSdk 26`, `targetSdk 35`
- Intended to compile with Android Gradle Plugin 8.7.3 / Kotlin 2.0.21.
- Shizuku integration uses `rikka.shizuku:api` and `rikka.shizuku:provider`.


## Build fix (AndroidForge)
The Shizuku Maven coordinates must include the `dev.` group prefix:
- `dev.rikka.shizuku:api:13.1.5`
- `dev.rikka.shizuku:provider:13.1.5`

The earlier `rikka.shizuku:*` coordinates were incorrect and caused dependency resolution to fail.
