package com.kenzi.rootlab

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

private val Bg = Color(0xFF0B0F14)
private val Panel = Color(0xFF151C24)
private val Panel2 = Color(0xFF1C2631)
private val Cyan = Color(0xFF53D6D0)
private val Blue = Color(0xFF75A7FF)
private val Violet = Color(0xFFB9A0FF)
private val Amber = Color(0xFFFFC66D)
private val Muted = Color(0xFF9BA9B8)
private val White = Color(0xFFF0F5FA)

data class Tweak(val name:String, val group:String, val description:String, val risk:String, val mode:String, val command:String = "")
data class AccessState(val root:Boolean=false, val shizuku:Boolean=false, val shizukuGranted:Boolean=false, val message:String="Đang kiểm tra quyền…")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RootLabApp(this) }
    }
}

private val tweaks = listOf(
    Tweak("Kiểm tra root shell","Chẩn đoán","Kiểm tra su và UID thực tế.","An toàn","Root","id"),
    Tweak("Kiểm tra SELinux","Chẩn đoán","Chỉ đọc trạng thái SELinux, không thay đổi enforcement.","An toàn","Cả hai","getenforce"),
    Tweak("Thông tin kernel","Chẩn đoán","Đọc phiên bản kernel hiện tại.","An toàn","Cả hai","uname -a"),
    Tweak("Thông tin uptime","Chẩn đoán","Đọc thời gian chạy từ lần khởi động gần nhất.","An toàn","Cả hai","cat /proc/uptime"),
    Tweak("Tải CPU","Chẩn đoán","Đọc tải hệ thống hiện tại.","An toàn","Cả hai","cat /proc/loadavg"),
    Tweak("Thông tin bộ nhớ","RAM","Đọc MemTotal/MemAvailable.","An toàn","Cả hai","cat /proc/meminfo"),
    Tweak("Thông tin pin","Pin","Đọc thông tin pin qua Android API.","An toàn","Cả hai"),
    Tweak("Thông tin nhiệt độ","Nhiệt","Hiển thị nhiệt độ cảm biến nếu Android cho phép.","An toàn","Cả hai"),
    Tweak("Danh sách tiến trình","RAM","Chẩn đoán tiến trình; không tự kill ứng dụng.","Thận trọng","Root","ps -A"),
    Tweak("Dung lượng lưu trữ","Dọn dẹp","Đọc dung lượng phân vùng người dùng.","An toàn","Cả hai","df -h /data"),
    Tweak("Thông tin CPU","CPU","Đọc thông tin CPU từ /proc/cpuinfo.","An toàn","Cả hai","cat /proc/cpuinfo"),
    Tweak("Thông tin GPU","Đồ họa","Đọc renderer qua thông tin hệ thống khi có sẵn.","An toàn","Cả hai","getprop ro.hardware.egl"),
    Tweak("Tần số màn hình","Hiển thị","Đọc mức refresh rate hệ thống.","An toàn","Cả hai"),
    Tweak("Độ phân giải màn hình","Hiển thị","Đọc kích thước màn hình thực tế.","An toàn","Cả hai"),
    Tweak("Phiên bản Android","Thiết bị","Hiển thị phiên bản Android và SDK.","An toàn","Cả hai"),
    Tweak("Build fingerprint","Thiết bị","Đọc fingerprint bản ROM hiện tại.","An toàn","Cả hai"),
    Tweak("Kiểm tra trạng thái boot","Bảo mật","Chỉ đọc một số thuộc tính boot có sẵn.","An toàn","Root","getprop ro.boot.verifiedbootstate"),
    Tweak("Kiểm tra governor CPU","CPU","Đọc governor nếu sysfs cho phép.","Thận trọng","Root","cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"),
    Tweak("Đọc tần số CPU","CPU","Đọc tần số hiện tại nếu kernel công bố.","An toàn","Root","cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"),
    Tweak("Đọc giới hạn CPU","CPU","Đọc giới hạn tần số, không sửa giá trị.","An toàn","Root","cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq"),
    Tweak("Trạng thái zRAM","RAM","Đọc thông tin swap hiện tại.","An toàn","Root","cat /proc/swaps"),
    Tweak("Trạng thái LMK","RAM","Chỉ đọc thông tin low memory killer nếu có.","Thận trọng","Root","getprop ro.lmk.enable"),
    Tweak("Đọc vm.swappiness","RAM","Đọc giá trị kernel hiện tại; không tự ghi.","An toàn","Root","cat /proc/sys/vm/swappiness"),
    Tweak("Đọc TCP congestion","Mạng","Đọc thuật toán TCP hiện tại.","An toàn","Root","cat /proc/sys/net/ipv4/tcp_congestion_control"),
    Tweak("Đọc DNS hệ thống","Mạng","Đọc DNS do Android công bố.","An toàn","Cả hai","getprop | grep -i dns"),
    Tweak("Đọc trạng thái Wi-Fi","Mạng","Mở trang cài đặt Wi-Fi Android.","An toàn","Cả hai"),
    Tweak("Mở cài đặt ứng dụng","Hệ thống","Đi tới phần quản lý ứng dụng của Android.","An toàn","Cả hai"),
    Tweak("Mở cài đặt pin","Pin","Đi tới cài đặt pin do hệ thống cung cấp.","An toàn","Cả hai"),
    Tweak("Mở cài đặt hiển thị","Hiển thị","Đi tới cài đặt màn hình Android.","An toàn","Cả hai"),
    Tweak("Mở tùy chọn nhà phát triển","Hệ thống","Mở trang cài đặt nhà phát triển nếu được hỗ trợ.","Thận trọng","Cả hai"),
    Tweak("Đọc app standby","Pin","Đọc thông tin standby nếu có quyền.","Thận trọng","Root","am get-standby-bucket com.dts.freefireth"),
    Tweak("Đọc danh sách package","Hệ thống","Liệt kê package cài đặt, không gỡ ứng dụng.","An toàn","Cả hai","pm list packages"),
    Tweak("Đọc thuộc tính build","Thiết bị","Đọc thuộc tính build cơ bản.","An toàn","Root","getprop ro.build.version.release"),
    Tweak("Đọc trạng thái thermal","Nhiệt","Đọc trạng thái thermal do Android cung cấp.","An toàn","Cả hai"),
    Tweak("Đọc trạng thái game mode","Game","Chẩn đoán trạng thái game mode nếu API hỗ trợ.","An toàn","Cả hai"),
    Tweak("Đọc FPS hỗ trợ","Game","Hiển thị các chế độ refresh do hệ thống báo cáo.","An toàn","Cả hai"),
    Tweak("Đọc thông tin audio","Thiết bị","Chẩn đoán thông tin âm thanh cơ bản.","An toàn","Cả hai"),
    Tweak("Đọc danh sách module","Root","Liệt kê module KernelSU/Magisk nếu đường dẫn cho phép.","Thận trọng","Root","ls -la /data/adb/modules"),
    Tweak("Kiểm tra Shizuku","Quyền","Kiểm tra dịch vụ và quyền Shizuku.","An toàn","Shizuku"),
    Tweak("Mở trang Shizuku","Quyền","Mở ứng dụng Shizuku nếu đã cài.","An toàn","Cả hai"),
    Tweak("Làm mới trạng thái quyền","Quyền","Đọc lại trạng thái root/Shizuku.","An toàn","Cả hai"),
    Tweak("Xuất nhật ký phiên","Nhật ký","Hiển thị nhật ký thao tác trong ứng dụng.","An toàn","Cả hai"),
    Tweak("Kiểm tra API Android","Thiết bị","Đọc SDK_INT và bản phát hành.","An toàn","Cả hai"),
    Tweak("Kiểm tra ABI","Thiết bị","Đọc ABI thiết bị.","An toàn","Cả hai"),
    Tweak("Kiểm tra RAM khả dụng","RAM","Đọc dung lượng RAM khả dụng.","An toàn","Cả hai"),
    Tweak("Kiểm tra nhiệt pin","Nhiệt","Đọc nhiệt độ pin qua Android API.","An toàn","Cả hai"),
    Tweak("Dọn cache ứng dụng","Dọn dẹp","Mở trang cài đặt để người dùng tự quản lý cache.","An toàn","Cả hai"),
    Tweak("Tắt animation hệ thống","Hiển thị","Chỉ mở cài đặt nhà phát triển; không ghi secure settings tự động.","Thận trọng","Cả hai"),
    Tweak("Tối ưu game thủ công","Game","Mở trang thông tin ứng dụng game để người dùng tự chỉnh.","An toàn","Cả hai"),
    Tweak("Kiểm tra pin đang sạc","Pin","Đọc trạng thái sạc hiện tại.","An toàn","Cả hai"),
    Tweak("Kiểm tra mạng đang dùng","Mạng","Mở cài đặt mạng; không chỉnh TCP/DNS tự động.","An toàn","Cả hai"),
    Tweak("Kiểm tra quyền app","Quyền","Mở trang chi tiết quyền ứng dụng.","An toàn","Cả hai"),
    Tweak("Đọc SELinux context","Bảo mật","Đọc context tiến trình hiện tại.","Thận trọng","Root","id"),
    Tweak("Kiểm tra bộ nhớ swap","RAM","Đọc dung lượng swap đang dùng.","An toàn","Root","cat /proc/meminfo"),
    Tweak("Đọc trạng thái CPU online","CPU","Đọc danh sách lõi CPU online.","An toàn","Root","cat /sys/devices/system/cpu/online"),
    Tweak("Đọc I/O scheduler","Lưu trữ","Đọc scheduler nếu kernel công bố.","Thận trọng","Root","cat /sys/block/sda/queue/scheduler"),
    Tweak("Đọc trạng thái Doze","Pin","Đọc trạng thái idle qua dumpsys khi được phép.","Thận trọng","Root","dumpsys deviceidle"),
    Tweak("Đọc tiến trình game","Game","Kiểm tra package game có đang chạy không.","An toàn","Root","pidof com.dts.freefireth"),
    Tweak("Đọc trạng thái thermal service","Nhiệt","Chẩn đoán dịch vụ thermal Android.","Thận trọng","Root","dumpsys thermalservice"),
    Tweak("Khôi phục mặc định tweak","Khôi phục","Bản mẫu chưa ghi thay đổi hệ thống tự động; không có gì để khôi phục.","An toàn","Cả hai"),
    Tweak("Kiểm tra nhật ký lỗi","Chẩn đoán","Hiển thị thông báo thao tác gần đây, không thu thập logcat nền.","An toàn","Cả hai")
)

@Composable
fun RootLabApp(activity: Activity) {
    var access by remember { mutableStateOf(AccessState()) }
    var selectedTab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("Tất cả") }
    var selected by remember { mutableStateOf<Tweak?>(null) }
    var output by remember { mutableStateOf("Chưa chạy lệnh nào. Chọn một mục để xem chi tiết.") }
    var log by remember { mutableStateOf(listOf("Khởi tạo KenZi RootLab.")) }
    var busy by remember { mutableStateOf(false) }

    suspend fun refresh() {
        val root = withContext(Dispatchers.IO) { runShell("id").contains("uid=0") }
        val service = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        val granted = try { service && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        access = AccessState(root, service, granted, when { root -> "Root đã sẵn sàng"; granted -> "Shizuku đã cấp quyền"; service -> "Shizuku đang chạy, chưa cấp quyền"; else -> "Chưa có Root hoặc Shizuku khả dụng" })
    }
    LaunchedEffect(Unit) { refresh() }

    MaterialTheme(colorScheme = darkColorScheme(primary=Cyan, secondary=Blue, background=Bg, surface=Panel, onBackground=White, onSurface=White)) {
        Scaffold(containerColor=Bg, bottomBar={
            NavigationBar(containerColor=Panel) {
                NavigationBarItem(selectedTab==0,{selectedTab=0},icon={Icon(Icons.Default.Speed,"")},label={Text("Tổng quan")})
                NavigationBarItem(selectedTab==1,{selectedTab=1},icon={Icon(Icons.Default.Tune,"")},label={Text("Tweak")})
                NavigationBarItem(selectedTab==2,{selectedTab=2},icon={Icon(Icons.Default.Memory,"")},label={Text("Thiết bị")})
                NavigationBarItem(selectedTab==3,{selectedTab=3},icon={Icon(Icons.Default.Security,"")},label={Text("Quyền")})
            }
        }) { padding ->
            if (!access.root && !access.shizukuGranted) {
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(24.dp),
                    verticalArrangement=Arrangement.Center,
                    horizontalAlignment=Alignment.CenterHorizontally
                ) {
                    Header()
                    Spacer(Modifier.height(28.dp))
                    Icon(Icons.Default.Lock, null, tint=Amber, modifier=Modifier.size(54.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Cần quyền truy cập", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("KenZi RootLab yêu cầu Root hoặc Shizuku đã cấp quyền. Chưa có quyền thì các chức năng chính sẽ bị khóa.", color=Muted)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick={ busy=true }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp)) { Text("Kiểm tra lại quyền") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick={ openPackageOrStore(activity, "moe.shizuku.privileged.api") }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp)) { Text("Mở / cài Shizuku") }
                    Spacer(Modifier.height(14.dp))
                    Text("Nếu đã cài Shizuku, hãy khởi động dịch vụ và cấp quyền cho KenZi RootLab trong Shizuku.", color=Muted, fontSize=12.sp)
                }
            } else LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(top=18.dp,bottom=22.dp)) {
                item { Header() }
                item { AccessBanner(access) { busy=true } }
                when(selectedTab) {
                    0 -> {
                        item { Text("Bảng điều khiển", fontSize=22.sp, fontWeight=FontWeight.Bold, color=White) }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            StatCard("Android", Build.VERSION.RELEASE, "API ${Build.VERSION.SDK_INT}", Cyan, Modifier.weight(1f))
                            StatCard("CPU ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "Không rõ", Build.HARDWARE, Blue, Modifier.weight(1f))
                        } }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            StatCard("Danh mục", "${tweaks.size}", "công cụ & chẩn đoán", Violet, Modifier.weight(1f))
                            StatCard("Chính sách", "Safe-first", "không sửa phân vùng", Amber, Modifier.weight(1f))
                        } }
                        item { SectionTitle("Truy cập nhanh") }
                        item { QuickAction("Kiểm tra quyền", "Đọc lại Root / Shizuku", Icons.Default.Security) { busy=true } }
                        item { QuickAction("Thông tin thiết bị", "Android, kernel, ABI và bộ nhớ", Icons.Default.PhoneAndroid) { selectedTab=2 } }
                        item { QuickAction("Danh mục tweak", "Tìm công cụ theo nhóm và mức rủi ro", Icons.Default.Tune) { selectedTab=1 } }
                        item { Text("Lưu ý: các tweak phụ thuộc kernel/ROM. App không hứa tăng FPS cố định; chỉ áp dụng thay đổi khi quyền, hỗ trợ và khả năng khôi phục đã được xác minh.", color=Muted, fontSize=12.sp) }
                    }
                    1 -> {
                        item { Text("Tweak & công cụ", fontSize=22.sp, fontWeight=FontWeight.Bold) }
                        item { OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Tìm chức năng")},singleLine=true,shape=RoundedCornerShape(16.dp)) }
                        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            listOf("Tất cả","CPU","RAM","Game","Pin","Mạng","Hiển thị","Chẩn đoán").forEach { g ->
                                FilterChip(selected=group==g,onClick={group=g},label={Text(g)})
                            }
                        } }
                        items(tweaks.filter { (group=="Tất cả" || it.group==group) && (it.name.contains(query,true) || it.description.contains(query,true) || it.group.contains(query,true)) }) { tweak ->
                            TweakCard(tweak) { selected=tweak }
                        }
                    }
                    2 -> {
                        item { Text("Thông tin thiết bị", fontSize=22.sp, fontWeight=FontWeight.Bold) }
                        item { InfoCard("Thiết bị", listOf("Model" to "${Build.MANUFACTURER} ${Build.MODEL}", "Brand" to Build.BRAND, "Device" to Build.DEVICE, "Product" to Build.PRODUCT, "Fingerprint" to Build.FINGERPRINT)) }
                        item { InfoCard("Android", listOf("Release" to Build.VERSION.RELEASE, "SDK / API" to Build.VERSION.SDK_INT.toString(), "Security patch" to (if (Build.VERSION.SDK_INT>=23) Build.VERSION.SECURITY_PATCH else "N/A"), "Build ID" to Build.ID, "ABI" to Build.SUPPORTED_ABIS.joinToString())) }
                        item { InfoCard("Runtime", listOf("Kernel" to System.getProperty("os.version").orEmpty(), "Java VM" to System.getProperty("java.vm.name").orEmpty(), "App UID" to Process.myUid().toString(), "Package" to activity.packageName, "Display" to "${activity.resources.displayMetrics.widthPixels} × ${activity.resources.displayMetrics.heightPixels} px")) }
                        item { QuickAction("Mở cài đặt pin", "Xem mức dùng pin và chế độ tiết kiệm", Icons.Default.BatteryChargingFull) { openSettings(activity, "android.settings.BATTERY_SAVER_SETTINGS") } }
                        item { QuickAction("Mở cài đặt hiển thị", "Tự chọn tần số quét / độ sáng", Icons.Default.DisplaySettings) { openSettings(activity, "android.settings.DISPLAY_SETTINGS") } }
                    }
                    else -> {
                        item { Text("Quyền & bảo mật", fontSize=22.sp, fontWeight=FontWeight.Bold) }
                        item { InfoCard("Trạng thái truy cập", listOf("Root shell" to if(access.root) "Đã xác minh UID 0" else "Không khả dụng", "Shizuku service" to if(access.shizuku) "Đang chạy" else "Không phát hiện", "Shizuku permission" to if(access.shizukuGranted) "Đã cấp" else "Chưa cấp", "SELinux" to "Đọc bằng công cụ chẩn đoán", "App UID" to Process.myUid().toString(), "App PID" to Process.myPid().toString())) }
                        item { Text(access.message, color=Muted) }
                        item { Button(onClick={ busy=true }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp)) { Icon(Icons.Default.Refresh,null); Spacer(Modifier.width(8.dp)); Text("Kiểm tra lại quyền") } }
                        item { QuickAction("Mở Shizuku", "Khởi động dịch vụ và cấp quyền từ ứng dụng Shizuku", Icons.Default.OpenInNew) { openPackageOrStore(activity,"moe.shizuku.privileged.api") } }
                        item { Text("Root chỉ được dùng qua su khi người dùng chấp thuận trong trình quản lý root. Shizuku chỉ cho phép các API/lệnh ADB được hỗ trợ; không phải quyền root.", color=Muted, fontSize=12.sp) }
                    }
                }
            }
        }
    }
    if (busy) {
        LaunchedEffect(busy) { refresh(); busy=false; log=(log + access.message).takeLast(20) }
    }
    selected?.let { tweak ->
        AlertDialog(
            onDismissRequest={selected=null},
            containerColor=Panel,
            title={ Text(tweak.name, color=White, fontWeight=FontWeight.Bold) },
            text={
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text(tweak.description, color=Muted)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        RiskChip(tweak.risk)
                        AssistChip(onClick={},label={Text(tweak.mode)})
                    }
                    Text("Quyền cần có: ${tweak.mode}", color=White)
                    Text("Lệnh đọc/kiểm tra: ${if(tweak.command.isBlank()) "Không cần lệnh shell" else tweak.command}", color=Cyan, fontSize=12.sp)
                    if(tweak.risk!="An toàn") Text("Cảnh báo: mục này có thể phụ thuộc ROM/kernel. Bản starter chỉ chạy lệnh chẩn đoán đã định nghĩa; không tự sửa tần số CPU, thermal, SELinux hoặc phân vùng hệ thống.", color=Amber, fontSize=12.sp)
                    Text(output, color=Muted, fontSize=12.sp)
                }
            },
            confirmButton={
                TextButton(onClick={
                    selected=null
                    busy=true
                    // Safe implementation: only run explicit read-only commands. Never execute catalog text as arbitrary shell.
                    val chosen=tweak
                    kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
                        val result = if (access.root && chosen.command.isNotBlank() && chosen.risk=="An toàn") runShell(chosen.command)
                            else if (access.shizukuGranted && !access.root) "Shizuku đã cấp quyền. Mục này chưa có bộ thực thi Shizuku tương ứng trong bản starter nên không chạy shell root. Dùng mục thông tin Android hoặc mở cài đặt hệ thống."
                            else "Chưa thực thi: thao tác này là chẩn đoán có giới hạn hoặc chỉ dẫn thủ công trong bản starter."
                        withContext(Dispatchers.Main) {
                            output = result.take(3500)
                            log = (log + "${chosen.name}: ${if(result.startsWith("Chưa thực thi")) "chưa chạy" else "đã đọc"}").takeLast(20)
                        }
                    }
                }) { Text("Kiểm tra / xem hướng dẫn") }
            },
            dismissButton={ TextButton(onClick={selected=null}) { Text("Đóng") } }
        )
    }
}

private fun runShell(command: String): String {
    return try {
        val process = Runtime.getRuntime().exec(arrayOf("su","-c",command))
        val out = BufferedReader(InputStreamReader(process.inputStream)).readText()
        val err = BufferedReader(InputStreamReader(process.errorStream)).readText()
        val code = process.waitFor()
        (out.ifBlank { err.ifBlank { "Không có đầu ra (exit=$code)." } }).take(5000)
    } catch (e: Throwable) { "Không chạy được lệnh: ${e.javaClass.simpleName}: ${e.message ?: "quyền bị từ chối"}" }
}

private fun openSettings(context: Context, action: String) {
    try { context.startActivity(android.content.Intent(action).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
}
private fun openPackageOrStore(context: Context, packageName: String) {
    try {
        val launch=context.packageManager.getLaunchIntentForPackage(packageName)
        if(launch!=null) context.startActivity(launch)
        else context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
    } catch (_: Throwable) {}
}

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Cyan.copy(alpha=.14f),RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center) {
            Icon(Icons.Default.Bolt,null,tint=Cyan,modifier=Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("KenZi RootLab",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=White)
            Text("Made by KenZi (Tài bá khí)",fontSize=12.sp,color=Muted)
        }
        Box(Modifier.background(Panel2,RoundedCornerShape(12.dp)).padding(horizontal=10.dp, vertical=7.dp)) {
            Text("v1.0",fontSize=11.sp,color=Cyan,fontWeight=FontWeight.Bold)
        }
    }
}
@Composable private fun AccessBanner(access:AccessState,onRefresh:()->Unit) {
    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(20.dp)).padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
        Icon(if(access.root) Icons.Default.VerifiedUser else if(access.shizukuGranted) Icons.Default.Security else Icons.Default.Lock,null,tint=if(access.root) Cyan else if(access.shizukuGranted) Blue else Amber,modifier=Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(if(access.root) "ROOT ACTIVE" else if(access.shizukuGranted) "SHIZUKU ACTIVE" else "ACCESS STATUS",fontWeight=FontWeight.Bold,color=White,fontSize=13.sp)
            Text(access.message,fontSize=11.sp,color=Muted)
        }
        IconButton(onClick=onRefresh) { Icon(Icons.Default.Refresh,null,tint=Cyan) }
    }
}
@Composable private fun StatCard(title:String,value:String,subtitle:String,color:Color,modifier:Modifier=Modifier) {
    Column(modifier.background(Panel,RoundedCornerShape(20.dp)).padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Text(title,color=Muted,fontSize=11.sp)
        Text(value,color=color,fontSize=18.sp,fontWeight=FontWeight.Bold,maxLines=1)
        Text(subtitle,color=Muted,fontSize=10.sp,maxLines=2)
    }
}
@Composable private fun SectionTitle(text:String) { Text(text,fontSize=17.sp,fontWeight=FontWeight.Bold,color=White) }
@Composable private fun QuickAction(title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(18.dp)).clickable(onClick=onClick).padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Panel2,RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center) { Icon(icon,null,tint=Cyan) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.SemiBold,color=White); Text(subtitle,fontSize=11.sp,color=Muted) }
        Icon(Icons.Default.ChevronRight,null,tint=Muted)
    }
}
@Composable private fun TweakCard(t:Tweak,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(18.dp)).clickable(onClick=onClick).padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Panel2,RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center) { Icon(when(t.group){"CPU"->Icons.Default.Memory;"RAM"->Icons.Default.Storage;"Mạng"->Icons.Default.Wifi;"Pin"->Icons.Default.BatteryChargingFull;"Game"->Icons.Default.SportsEsports;"Hiển thị"->Icons.Default.DisplaySettings;else->Icons.Default.Tune},null,tint=Blue) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(t.name,fontWeight=FontWeight.SemiBold,color=White)
            Text(t.description,fontSize=11.sp,color=Muted,maxLines=2)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { RiskChip(t.risk); Text(t.mode,fontSize=10.sp,color=Muted) }
        }
        Icon(Icons.Default.ChevronRight,null,tint=Muted)
    }
}
@Composable private fun RiskChip(risk:String) {
    val color=when(risk){"An toàn"->Cyan;"Thận trọng"->Amber;else->Color(0xFFFF7B86)}
    Text(risk,color=color,fontSize=10.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.background(color.copy(alpha=.12f),RoundedCornerShape(7.dp)).padding(horizontal=7.dp,vertical=4.dp))
}
@Composable private fun InfoCard(title:String,rows:List<Pair<String,String>>) {
    Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(18.dp)).padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        Text(title,fontWeight=FontWeight.Bold,color=Cyan)
        rows.forEach { (k,v) ->
            Row(verticalAlignment=Alignment.Top) {
                Text(k,color=Muted,fontSize=12.sp,modifier=Modifier.width(105.dp))
                Text(v,color=White,fontSize=12.sp,modifier=Modifier.weight(1f))
            }
        }
    }
}
