KenZi Typer v4 - keyboard InputConnection update

What's changed:
- Added KenZi Keyboard as an Android InputMethodService.
- AutoTypeService tries to send each character through the active KenZi Keyboard InputConnection first.
- If KenZi Keyboard is not active or no focused editor connection is available, the previous Accessibility-based method remains as fallback.
- Auto-send remains disabled; the user decides when to submit text.
- The floating panel can still be hidden manually while typing continues.
- This build does not set FLAG_SECURE to conceal the overlay from screen capture.

How to test on Android:
1. Build/install the APK.
2. Open KenZi Typer and tap “THIẾT LẬP KENZI KEYBOARD”.
3. In Android settings, enable KenZi Keyboard and select it as the current keyboard.
4. Open MT Manager, tap the intended text field and confirm the cursor is visible.
5. Start KenZi Typer's floating controller and begin typing.
6. If MT Manager still doesn't accept text, stop the task and test with a simple text field first; app-specific editors can restrict input.

Note: the ZIP was structurally/XML validated, but no Android SDK/Gradle executable was available here to compile or test the APK. Use the included GitHub Actions workflow to build it and inspect build logs.
