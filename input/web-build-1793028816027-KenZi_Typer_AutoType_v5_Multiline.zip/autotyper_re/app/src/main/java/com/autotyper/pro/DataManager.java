package com.autotyper.pro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DataManager {

    private static final List<String> lines = Collections.synchronizedList(new ArrayList<String>());
    private static int currentIndex = 0;

    public static synchronized void setLinesFromText(String text) {
        lines.clear();
        if (text == null || text.trim().isEmpty()) {
            return;
        }
        // Preserve explicit line breaks and blank lines from the text editor.
        String[] split = text.split("\\n", -1);
        for (String line : split) {
            // Remove a Windows carriage return only; preserve spaces and empty lines.
            lines.add(line.endsWith("\r") ? line.substring(0, line.length() - 1) : line);
        }
        currentIndex = 0;
    }

    public static synchronized void setLines(List<String> newLines) {
        lines.clear();
        if (newLines != null) {
            for (String line : newLines) {
                if (line != null) {
                    lines.add(line);
                }
            }
        }
        currentIndex = 0;
    }

    public static synchronized List<String> getLines() {
        return new ArrayList<String>(lines);
    }

    public static synchronized int getLineCount() {
        return lines.size();
    }

    public static synchronized int getCurrentIndex() {
        return currentIndex;
    }

    public static synchronized void setCurrentIndex(int index) {
        if (lines.isEmpty()) {
            currentIndex = 0;
            return;
        }
        if (index < 0) {
            currentIndex = 0;
        } else if (index >= lines.size()) {
            currentIndex = lines.size() - 1;
        } else {
            currentIndex = index;
        }
    }

    public static synchronized String getCurrentLine() {
        if (lines.isEmpty()) {
            return null;
        }
        if (currentIndex < 0 || currentIndex >= lines.size()) {
            currentIndex = 0;
        }
        return lines.get(currentIndex);
    }

    public static synchronized void nextLine() {
        if (lines.isEmpty()) {
            return;
        }
        currentIndex++;
        if (currentIndex >= lines.size()) {
            if (AppConfig.infiniteLoop) {
                currentIndex = 0;
            } else {
                currentIndex = lines.size() - 1;
            }
        }
    }

    public static synchronized void prevLine() {
        if (lines.isEmpty()) {
            return;
        }
        currentIndex--;
        if (currentIndex < 0) {
            currentIndex = lines.size() - 1;
        }
    }

    public static synchronized void resetIndex() {
        currentIndex = 0;
    }

    public static synchronized void loadSampleDictionary() {
        lines.clear();
        lines.add("Chào bạn nhé, hôm nay bạn thế nào?");
        lines.add("Test tính năng tự động gõ ngôn siêu mượt");
        lines.add("Auto chat chuẩn người thật gõ bàn phím");
        lines.add("Tốc độ delay cực kỳ mượt mà và an toàn");
        lines.add("Độ trễ tự nhiên không bị chặn tài khoản");
        lines.add("Hệ thống tự động nhận diện khung chat thành công!");
        lines.add("Chuyển dòng tiếp theo mượt mà...");
        lines.add("KenZi Typer — văn bản mẫu");
        currentIndex = 0;
    }
}
