package com.autotyper.pro;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.util.TypedValue;

/** A small user-selectable Android IME. Text is committed through the focused editor's InputConnection. */
public class KenZiKeyboardService extends InputMethodService {
    public static volatile KenZiKeyboardService instance;
    private boolean shifted = false;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(5), dp(6), dp(5), dp(8));
        root.setBackgroundColor(Color.rgb(15, 23, 42));

        TextView title = new TextView(this);
        title.setText("KenZi Keyboard  •  Nhập qua bàn phím Android");
        title.setTextColor(Color.rgb(56, 189, 248));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(5));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(26)));

        addRow(root, "qwertyuiop", 0);
        addRow(root, "asdfghjkl", 1);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        addSpecialKey(row, "⇧", 0.9f, new Runnable() { public void run() { shifted = !shifted; setInputView(onCreateInputView()); } });
        addRowLetters(row, "zxcvbnm");
        addSpecialKey(row, "⌫", 1.1f, new Runnable() { public void run() { InputConnection ic = getCurrentInputConnection(); if (ic != null) ic.deleteSurroundingText(1, 0); } });
        root.addView(row, new LinearLayout.LayoutParams(-1, dp(45)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        addSpecialKey(bottom, "123", 1.0f, new Runnable() { public void run() { shifted = !shifted; setInputView(onCreateInputView()); } });
        addSpecialKey(bottom, ",", 0.65f, new Runnable() { public void run() { type(","); } });
        addSpecialKey(bottom, "Tiếng Việt / Space", 4.0f, new Runnable() { public void run() { type(" "); } });
        addSpecialKey(bottom, ".", 0.65f, new Runnable() { public void run() { type("."); } });
        addSpecialKey(bottom, "↵", 1.0f, new Runnable() { public void run() { InputConnection ic = getCurrentInputConnection(); if (ic != null) ic.commitText("\n", 1); } });
        root.addView(bottom, new LinearLayout.LayoutParams(-1, dp(45)));
        return root;
    }

    private void addRow(LinearLayout root, String letters, int rowIndex) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        addRowLetters(row, letters);
        root.addView(row, new LinearLayout.LayoutParams(-1, dp(45)));
    }

    private void addRowLetters(LinearLayout row, String letters) {
        for (int i = 0; i < letters.length(); i++) {
            final String value = String.valueOf(shifted ? Character.toUpperCase(letters.charAt(i)) : letters.charAt(i));
            Button b = keyButton(value);
            b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { type(value); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(39), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            row.addView(b, lp);
        }
    }

    private void addSpecialKey(LinearLayout row, String label, float weight, final Runnable action) {
        Button b = keyButton(label);
        b.setTextSize(label.length() > 5 ? 10 : 13);
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { action.run(); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(39), weight);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(b, lp);
    }

    private Button keyButton(String label) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(30, 41, 59));
        bg.setCornerRadius(dp(7));
        bg.setStroke(dp(1), Color.rgb(51, 65, 85));
        b.setBackground(bg);
        return b;
    }

    private void type(String value) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(value, 1);
    }

    public static boolean commitCharacter(char c) {
        return commitText(String.valueOf(c));
    }

    /** Commit text (including a line break) to the currently focused editor. */
    public static boolean commitText(String text) {
        KenZiKeyboardService service = instance;
        if (service == null) return false;
        InputConnection ic = service.getCurrentInputConnection();
        if (ic == null) return false;
        return ic.commitText(text, 1);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
