package com.autotyper.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingControlService extends Service implements AppConfig.StatusListener {

    private static final String CHANNEL_ID = "autotyper_channel";

    private WindowManager windowManager;
    private View panelView;
    private View bubbleView;
    private View invisibleTriggerView;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams triggerParams;
    private View keyPopupView;
    private TextView tvPopupKey;
    private WindowManager.LayoutParams keyPopupParams;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable hidePopupRunnable;
    private TextView tvStatus;
    private TextView tvCounter;
    private Button btnToggle;
    private Button btnPrev;
    private Button btnNext;
    private Button btnReset;
    private Button btnMinimize;
    private Button btnClose;
    private Button btnHideStealth;
    private Vibrator vibrator;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            startForegroundNotification();
        } catch (Exception ignored) {
        }
        try {
            vibrator = (Vibrator) getSystemService("vibrator");
            windowManager = (WindowManager) getSystemService("window");
            AppConfig.setStatusListener(this);
            initViews();
            initKeyPopupView();
            if (AppConfig.stealthMode) {
                enableStealthMode();
            } else {
                showPanel();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Lỗi: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "KenZi Typer Service",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Dịch vụ điều khiển tự động gõ ngôn");
            NotificationManager nm = (NotificationManager) getSystemService("notification");
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
            Notification notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("KenZi Typer")
                    .setContentText("Menu điều khiển đang hoạt động")
                    .setSmallIcon(android.R.drawable.sym_def_app_icon)
                    .build();
            startForeground(1001, notification);
        }
    }

    private int getOverlayType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void initViews() {
        LayoutInflater inflater = LayoutInflater.from(this);
        panelView = inflater.inflate(R.layout.floating_panel, null);
        tvStatus = (TextView) panelView.findViewById(R.id.tvFloatStatus);
        tvCounter = (TextView) panelView.findViewById(R.id.tvFloatCounter);
        btnToggle = (Button) panelView.findViewById(R.id.btnFloatToggle);
        btnPrev = (Button) panelView.findViewById(R.id.btnFloatPrev);
        btnNext = (Button) panelView.findViewById(R.id.btnFloatNext);
        btnReset = (Button) panelView.findViewById(R.id.btnFloatReset);
        btnMinimize = (Button) panelView.findViewById(R.id.btnFloatMinimize);
        btnClose = (Button) panelView.findViewById(R.id.btnFloatClose);
        btnHideStealth = (Button) panelView.findViewById(R.id.btnFloatHideStealth);

        // Keep the overlay visible to normal system capture; the user can hide it manually.
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                flags,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = 40;
        panelParams.y = 180;

        bubbleView = inflater.inflate(R.layout.floating_bubble, null);
        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                flags,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = 40;
        bubbleParams.y = 180;

        invisibleTriggerView = new View(this);
        invisibleTriggerView.setBackgroundColor(0);
        triggerParams = new WindowManager.LayoutParams(
                45,
                45,
                getOverlayType(),
                flags,
                PixelFormat.TRANSLUCENT);
        triggerParams.gravity = Gravity.TOP | Gravity.START;
        triggerParams.x = 0;
        triggerParams.y = 0;
        invisibleTriggerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibrateClick();
                disableStealthMode();
            }
        });

        float alpha = Math.max(0.2f, AppConfig.floatingAlphaPercent / 100.0f);
        panelView.setAlpha(alpha);
        bubbleView.setAlpha(alpha);

        View dragHeader = panelView.findViewById(R.id.layoutDragHeader);
        setupDragTouchListener(dragHeader, panelParams, panelView);
        setupBubbleTouchListener();
        setupButtonClicks();
        updateCounterDisplay();
    }

    private void initKeyPopupView() {
        LayoutInflater inflater = LayoutInflater.from(this);
        keyPopupView = inflater.inflate(R.layout.key_popup, null);
        tvPopupKey = (TextView) keyPopupView.findViewById(R.id.tvPopupKey);
        keyPopupParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        keyPopupParams.gravity = Gravity.TOP | Gravity.START;
        keyPopupParams.x = -500;
        keyPopupParams.y = -500;
    }

    private void setupDragTouchListener(View dragHandle, final WindowManager.LayoutParams params, final View root) {
        if (dragHandle == null) {
            return;
        }
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                try {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x;
                            initialY = params.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            windowManager.updateViewLayout(root, params);
                            return true;
                        case MotionEvent.ACTION_UP:
                            return true;
                        default:
                            return false;
                    }
                } catch (Exception e) {
                    return false;
                }
            }
        });
    }

    private void setupBubbleTouchListener() {
        if (bubbleView == null) {
            return;
        }
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                try {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            touchStartTime = System.currentTimeMillis();
                            initialX = bubbleParams.x;
                            initialY = bubbleParams.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            bubbleParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                            bubbleParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                            windowManager.updateViewLayout(bubbleView, bubbleParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                            long elapsed = System.currentTimeMillis() - touchStartTime;
                            float dx = Math.abs(event.getRawX() - initialTouchX);
                            float dy = Math.abs(event.getRawY() - initialTouchY);
                            if (elapsed < 250 && dx < 10.0f && dy < 10.0f) {
                                vibrateClick();
                                showPanel();
                            }
                            return true;
                        default:
                            return false;
                    }
                } catch (Exception e) {
                    return false;
                }
            }
        });
    }

    private void setupButtonClicks() {
        if (btnToggle != null) {
            btnToggle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    if (AutoTypeService.instance == null) {
                        Toast.makeText(
                                FloatingControlService.this,
                                "Vui lòng BẬT Trợ năng trong Cài đặt trước!",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (AutoTypeService.instance.isTypingRunning()) {
                        AutoTypeService.instance.stopTyping();
                    } else {
                        AutoTypeService.instance.startTyping();
                    }
                }
            });
        }
        if (btnPrev != null) {
            btnPrev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    DataManager.prevLine();
                    updateCounterDisplay();
                    String line = DataManager.getCurrentLine();
                    if (tvStatus != null) {
                        tvStatus.setText("Xem trước: " + (line != null ? line : ""));
                    }
                }
            });
        }
        if (btnNext != null) {
            btnNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    DataManager.nextLine();
                    updateCounterDisplay();
                    String line = DataManager.getCurrentLine();
                    if (tvStatus != null) {
                        tvStatus.setText("Xem trước: " + (line != null ? line : ""));
                    }
                }
            });
        }
        if (btnReset != null) {
            btnReset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    DataManager.resetIndex();
                    updateCounterDisplay();
                    Toast.makeText(FloatingControlService.this, "Đã về câu đầu", Toast.LENGTH_SHORT).show();
                }
            });
        }
        if (btnMinimize != null) {
            btnMinimize.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    showBubble();
                }
            });
        }
        if (btnHideStealth != null) {
            btnHideStealth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    enableStealthMode();
                    Toast.makeText(
                            FloatingControlService.this,
                            "Đã ẩn bảng điều khiển. Tác vụ gõ đang chạy vẫn tiếp tục; dùng phím âm lượng để điều khiển.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
        if (btnClose != null) {
            btnClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    vibrateClick();
                    if (AutoTypeService.instance != null) {
                        AutoTypeService.instance.stopTyping();
                    }
                    stopSelf();
                }
            });
        }
    }

    private void showPanel() {
        try {
            if (bubbleView != null && bubbleView.getParent() != null) {
                windowManager.removeView(bubbleView);
            }
            if (panelView != null && panelView.getParent() == null) {
                windowManager.addView(panelView, panelParams);
            }
        } catch (Exception ignored) {
        }
    }

    private void showBubble() {
        try {
            if (panelView != null && panelView.getParent() != null) {
                windowManager.removeView(panelView);
            }
            if (bubbleView != null && bubbleView.getParent() == null) {
                bubbleParams.x = panelParams.x;
                bubbleParams.y = panelParams.y;
                windowManager.addView(bubbleView, bubbleParams);
            }
        } catch (Exception ignored) {
        }
    }

    public void enableStealthMode() {
        AppConfig.stealthMode = true;
        try {
            if (panelView != null && panelView.getParent() != null) {
                windowManager.removeView(panelView);
            }
            if (bubbleView != null && bubbleView.getParent() != null) {
                windowManager.removeView(bubbleView);
            }
            if (invisibleTriggerView != null && invisibleTriggerView.getParent() == null) {
                windowManager.addView(invisibleTriggerView, triggerParams);
            }
        } catch (Exception ignored) {
        }
    }

    public void disableStealthMode() {
        AppConfig.stealthMode = false;
        try {
            if (invisibleTriggerView != null && invisibleTriggerView.getParent() != null) {
                windowManager.removeView(invisibleTriggerView);
            }
        } catch (Exception ignored) {
        }
        showPanel();
    }

    private void updateCounterDisplay() {
        if (tvCounter == null) {
            return;
        }
        int total = DataManager.getLineCount();
        int current = total > 0 ? DataManager.getCurrentIndex() + 1 : 0;
        tvCounter.setText("[" + current + "/" + total + "]");
    }

    @Override
    public void onStatusChanged(String status, int current, int total, boolean isRunning) {
        if (tvStatus != null) {
            tvStatus.setText(status);
        }
        if (tvCounter != null) {
            int displayIndex = total > 0 ? current + 1 : 0;
            tvCounter.setText("[" + displayIndex + "/" + total + "]");
        }
        if (btnToggle != null) {
            if (isRunning) {
                btnToggle.setText("DỪNG");
                btnToggle.setBackgroundResource(R.drawable.btn_danger);
            } else {
                btnToggle.setText("BẮT ĐẦU");
                btnToggle.setBackgroundResource(R.drawable.btn_primary);
            }
        }
    }

    @Override
    public void onStealthModeChanged(boolean isStealth) {
        if (isStealth) {
            enableStealthMode();
        } else {
            disableStealthMode();
        }
    }

    @Override
    public void onTriggerKeyPopup(final char c) {
        if (!AppConfig.showKeyPopupAnimation || keyPopupView == null || windowManager == null) {
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (AutoTypeService.instance == null) {
                        return;
                    }
                    Point pt = AutoTypeService.instance.getKeyCoordinate(c);
                    if (pt == null) {
                        return;
                    }
                    tvPopupKey.setText(String.valueOf(c));
                    keyPopupParams.x = pt.x - 23;
                    keyPopupParams.y = pt.y - 70;
                    if (keyPopupView.getParent() == null) {
                        windowManager.addView(keyPopupView, keyPopupParams);
                    } else {
                        windowManager.updateViewLayout(keyPopupView, keyPopupParams);
                    }
                    if (hidePopupRunnable != null) {
                        mainHandler.removeCallbacks(hidePopupRunnable);
                    }
                    hidePopupRunnable = new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (keyPopupView.getParent() != null) {
                                    windowManager.removeView(keyPopupView);
                                }
                            } catch (Exception ignored) {
                            }
                        }
                    };
                    mainHandler.postDelayed(hidePopupRunnable, 90);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void vibrateClick() {
        try {
            if (vibrator != null) {
                vibrator.vibrate(25);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        AppConfig.setStatusListener(null);
        try {
            if (panelView != null && panelView.getParent() != null) {
                windowManager.removeView(panelView);
            }
            if (bubbleView != null && bubbleView.getParent() != null) {
                windowManager.removeView(bubbleView);
            }
            if (invisibleTriggerView != null && invisibleTriggerView.getParent() != null) {
                windowManager.removeView(invisibleTriggerView);
            }
            if (keyPopupView != null && keyPopupView.getParent() != null) {
                windowManager.removeView(keyPopupView);
            }
        } catch (Exception ignored) {
        }
    }
}
