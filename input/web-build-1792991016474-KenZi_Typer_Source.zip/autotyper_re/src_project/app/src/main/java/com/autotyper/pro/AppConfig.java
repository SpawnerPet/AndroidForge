package com.autotyper.pro;

public class AppConfig {

    public interface StatusListener {
        void onStatusChanged(String status, int current, int total, boolean isRunning);

        void onStealthModeChanged(boolean isStealth);

        void onTriggerKeyPopup(char c);
    }

    public static int sendDelayMs = 1000;
    public static int charSpeedMs = 50;
    public static boolean humanJitter = true;
    public static boolean autoSend = true;
    public static boolean infiniteLoop = true;
    public static boolean hideFromScreenRecording = true;
    public static boolean useVolumeKeyTrigger = true;
    public static boolean stealthMode = false;
    public static int floatingAlphaPercent = 90;
    public static boolean showKeyPopupAnimation = true;
    public static boolean smartHumanCadence = true;

    private static StatusListener listener;

    public static void setStatusListener(StatusListener statusListener) {
        listener = statusListener;
    }

    public static void notifyStatus(String status, int current, int total, boolean isRunning) {
        if (listener != null) {
            listener.onStatusChanged(status, current, total, isRunning);
        }
    }

    public static void notifyStealth(boolean isStealth) {
        if (listener != null) {
            listener.onStealthModeChanged(isStealth);
        }
    }

    public static void notifyKeyPopup(char c) {
        if (listener != null) {
            listener.onTriggerKeyPopup(c);
        }
    }
}
