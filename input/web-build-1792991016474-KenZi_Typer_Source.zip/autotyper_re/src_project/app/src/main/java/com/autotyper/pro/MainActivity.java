package com.autotyper.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY_PERM = 1001;
    private static final int REQ_PICK_TXT_FILE = 1002;

    private TextView tvOverlayStatus;
    private TextView tvAccessibilityStatus;
    private TextView tvLineCount;
    private Button btnGrantOverlay;
    private Button btnGrantAccessibility;
    private Button btnLoadFile;
    private Button btnLoadSample;
    private Button btnLaunchFloating;
    private EditText edtSendDelay;
    private EditText edtCharSpeed;
    private EditText edtTextContent;
    private CheckBox cbHumanJitter;
    private CheckBox cbAutoSend;
    private CheckBox cbInfiniteLoop;
    private CheckBox cbVolumeTrigger;
    private CheckBox cbKeyPopup;
    private CheckBox cbHideRecording;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, final Throwable throwable) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(
                                MainActivity.this,
                                "Lỗi: " + throwable.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        try {
            setContentView(R.layout.activity_main);
            bindViews();
            setupListeners();
            if (DataManager.getLineCount() == 0) {
                DataManager.loadSampleDictionary();
                updateEditorWithLines(DataManager.getLines());
            } else {
                updateEditorWithLines(DataManager.getLines());
            }
        } catch (Exception e) {
            Toast.makeText(this, "Lỗi: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            checkAndRefreshPermissions();
        } catch (Exception ignored) {
        }
    }

    private void bindViews() {
        tvOverlayStatus = (TextView) findViewById(R.id.tvOverlayStatus);
        tvAccessibilityStatus = (TextView) findViewById(R.id.tvAccessibilityStatus);
        tvLineCount = (TextView) findViewById(R.id.tvLineCount);
        btnGrantOverlay = (Button) findViewById(R.id.btnGrantOverlay);
        btnGrantAccessibility = (Button) findViewById(R.id.btnGrantAccessibility);
        btnLoadFile = (Button) findViewById(R.id.btnLoadFile);
        btnLoadSample = (Button) findViewById(R.id.btnLoadSample);
        btnLaunchFloating = (Button) findViewById(R.id.btnLaunchFloating);
        edtSendDelay = (EditText) findViewById(R.id.edtSendDelay);
        edtCharSpeed = (EditText) findViewById(R.id.edtCharSpeed);
        edtTextContent = (EditText) findViewById(R.id.edtTextContent);
        cbHumanJitter = (CheckBox) findViewById(R.id.cbHumanJitter);
        cbAutoSend = (CheckBox) findViewById(R.id.cbAutoSend);
        cbInfiniteLoop = (CheckBox) findViewById(R.id.cbInfiniteLoop);
        cbVolumeTrigger = (CheckBox) findViewById(R.id.cbVolumeTrigger);
        cbKeyPopup = (CheckBox) findViewById(R.id.cbKeyPopup);
        cbHideRecording = (CheckBox) findViewById(R.id.cbHideRecording);
    }

    private void setupListeners() {
        if (btnGrantOverlay != null) {
            btnGrantOverlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (!Settings.canDrawOverlays(MainActivity.this)) {
                                Intent intent = new Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + getPackageName()));
                                startActivityForResult(intent, REQ_OVERLAY_PERM);
                            } else {
                                Toast.makeText(
                                        MainActivity.this,
                                        "Đã có quyền cửa sổ nổi!",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    } catch (Exception e) {
                        Toast.makeText(
                                MainActivity.this,
                                "Cài đặt quyền nổi: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        if (btnGrantAccessibility != null) {
            btnGrantAccessibility.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                        startActivity(intent);
                        Toast.makeText(
                                MainActivity.this,
                                "Tìm 'KenZi Typer' trong danh sách và bật dịch vụ nếu bạn đồng ý.",
                                Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(
                                MainActivity.this,
                                "Cài đặt trợ năng: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        if (btnLoadFile != null) {
            btnLoadFile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("text/plain");
                        startActivityForResult(
                                Intent.createChooser(intent, "Chọn file ngon.txt"),
                                REQ_PICK_TXT_FILE);
                    } catch (Exception e) {
                        Toast.makeText(
                                MainActivity.this,
                                "Bộ chọn file: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        if (btnLoadSample != null) {
            btnLoadSample.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DataManager.loadSampleDictionary();
                    updateEditorWithLines(DataManager.getLines());
                    Toast.makeText(
                            MainActivity.this,
                            "Đã nạp bộ ngôn mẫu " + DataManager.getLineCount() + " câu!",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (edtTextContent != null) {
            edtTextContent.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    updateLineCountUI();
                }
            });
        }

        if (btnLaunchFloating != null) {
            btnLaunchFloating.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveConfigAndLaunch();
                }
            });
        }
    }

    private void checkAndRefreshPermissions() {
        boolean hasOverlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        if (tvOverlayStatus != null) {
            if (hasOverlay) {
                tvOverlayStatus.setText("• Cửa sổ nổi: ĐÃ CẤP ✓");
                tvOverlayStatus.setTextColor(Color.parseColor("#10B981"));
                if (btnGrantOverlay != null) {
                    btnGrantOverlay.setEnabled(false);
                    btnGrantOverlay.setText("ĐÃ CẤP");
                }
            } else {
                tvOverlayStatus.setText("• Cửa sổ nổi: CHƯA CẤP ✗");
                tvOverlayStatus.setTextColor(Color.parseColor("#EF4444"));
                if (btnGrantOverlay != null) {
                    btnGrantOverlay.setEnabled(true);
                    btnGrantOverlay.setText("CẤP QUYỀN");
                }
            }
        }

        boolean hasA11y = isAccessibilityServiceEnabled();
        if (tvAccessibilityStatus != null) {
            if (hasA11y) {
                tvAccessibilityStatus.setText("• Trợ năng: ĐÃ BẬT ✓");
                tvAccessibilityStatus.setTextColor(Color.parseColor("#10B981"));
                if (btnGrantAccessibility != null) {
                    btnGrantAccessibility.setEnabled(false);
                    btnGrantAccessibility.setText("ĐÃ BẬT");
                }
            } else {
                tvAccessibilityStatus.setText("• Trợ năng: CHƯA BẬT ✗");
                tvAccessibilityStatus.setTextColor(Color.parseColor("#EF4444"));
                if (btnGrantAccessibility != null) {
                    btnGrantAccessibility.setEnabled(true);
                    btnGrantAccessibility.setText("BẬT DỊCH VỤ");
                }
            }
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        if (AutoTypeService.instance != null) {
            return true;
        }
        try {
            Object manager = getSystemService("accessibility");
            if (manager == null) {
                return false;
            }
            String enabledServices = Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabledServices != null) {
                String expected = getPackageName() + "/" + AutoTypeService.class.getName();
                return enabledServices.contains(expected)
                        || enabledServices.contains(getPackageName());
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_TXT_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                readFileFromUri(uri);
            }
        }
    }

    private void readFileFromUri(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) {
                return;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            List<String> loaded = new ArrayList<String>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    loaded.add(line.trim());
                }
            }
            reader.close();
            DataManager.setLines(loaded);
            updateEditorWithLines(loaded);
            Toast.makeText(
                    this,
                    "Đã nạp " + loaded.size() + " câu từ file!",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Lỗi đọc file: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void updateEditorWithLines(List<String> lines) {
        if (edtTextContent == null || lines == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append("\n");
        }
        edtTextContent.setText(sb.toString());
        updateLineCountUI();
    }

    private void updateLineCountUI() {
        if (edtTextContent == null || tvLineCount == null) {
            return;
        }
        String content = edtTextContent.getText().toString();
        int count = 0;
        if (!content.trim().isEmpty()) {
            String[] split = content.split("\n");
            for (String s : split) {
                if (!s.trim().isEmpty()) {
                    count++;
                }
            }
        }
        tvLineCount.setText(count + " câu");
    }

    private void saveConfigAndLaunch() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                    this,
                    "Bạn cần CẤP QUYỀN Cửa Sổ Nổi trước!",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int delaySec = Integer.parseInt(edtSendDelay.getText().toString().trim());
            AppConfig.sendDelayMs = Math.max(100, delaySec * 1000);
        } catch (Exception e) {
            AppConfig.sendDelayMs = 1000;
        }

        try {
            int speedMs = Integer.parseInt(edtCharSpeed.getText().toString().trim());
            AppConfig.charSpeedMs = Math.max(10, speedMs);
        } catch (Exception e) {
            AppConfig.charSpeedMs = 45;
        }

        if (cbHumanJitter != null) {
            AppConfig.humanJitter = cbHumanJitter.isChecked();
        }
        if (cbAutoSend != null) {
            AppConfig.autoSend = cbAutoSend.isChecked();
        }
        if (cbInfiniteLoop != null) {
            AppConfig.infiniteLoop = cbInfiniteLoop.isChecked();
        }
        if (cbVolumeTrigger != null) {
            AppConfig.useVolumeKeyTrigger = cbVolumeTrigger.isChecked();
        }
        if (cbKeyPopup != null) {
            AppConfig.showKeyPopupAnimation = cbKeyPopup.isChecked();
        }
        if (cbHideRecording != null) {
            AppConfig.hideFromScreenRecording = cbHideRecording.isChecked();
        }
        if (edtTextContent != null) {
            DataManager.setLinesFromText(edtTextContent.getText().toString());
        }

        if (DataManager.getLineCount() == 0) {
            Toast.makeText(
                    this,
                    "Danh sách ngôn đang trống! Hãy nhập hoặc nạp file.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Intent serviceIntent = new Intent(this, FloatingControlService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            Toast.makeText(
                    this,
                    "Đã mở Menu nổi! Chế độ gõ chuẩn người thật đã BẬT.",
                    Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Lỗi chạy dịch vụ: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            try {
                moveTaskToBack(true);
            } catch (Exception ignored) {
            }
        }
    }
}
